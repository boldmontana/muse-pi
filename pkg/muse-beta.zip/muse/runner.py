"""Persistent job queue.

SQLite-backed so a crash never loses queued work, with attempts, exponential backoff and a
claim protocol that is safe for more than one worker. Handlers live in `muse.jobs`.
"""

from __future__ import annotations

import builtins
import json
import os
import time

STATUSES = ("queued", "running", "done", "failed", "cancelled")


class Queue:
    def __init__(self, path: str = "state/jobs.db"):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        self.db = _connect(path)
        self.db.execute("""CREATE TABLE IF NOT EXISTS jobs(
            id INTEGER PRIMARY KEY, kind TEXT, payload TEXT, status TEXT DEFAULT 'queued',
            attempts INTEGER DEFAULT 0, max_attempts INTEGER DEFAULT 3, priority INTEGER DEFAULT 5,
            run_after REAL DEFAULT 0, created REAL, started REAL, finished REAL,
            result TEXT, error TEXT, schedule_id INTEGER)""")
        self.db.commit()

    def add(self, kind: str, payload: dict | None = None, run_after: float = 0.0,
            priority: int = 5, max_attempts: int = 3, schedule_id: int | None = None) -> int:
        if not 1 <= priority <= 9:
            raise ValueError("priority 1-9")
        cursor = self.db.execute(
            """INSERT INTO jobs(kind, payload, run_after, priority, max_attempts, created, schedule_id)
               VALUES(?,?,?,?,?,?,?)""",
            (kind, json.dumps(payload or {}), time.time() + run_after, priority,
             max_attempts, time.time(), schedule_id))
        self.db.commit()
        return int(cursor.lastrowid)

    def claim(self) -> dict | None:
        """Take the next due job. The status guard makes the take safe across workers."""
        now = time.time()
        self.db.execute("DELETE FROM jobs WHERE status='done' AND finished < ?", (now - 7 * 86400,))
        for _ in range(5):
            row = self.db.execute(
                """SELECT id, kind, payload, attempts, max_attempts FROM jobs
                   WHERE status='queued' AND run_after <= ?
                   ORDER BY priority ASC, run_after ASC, id ASC LIMIT 1""", (now,)).fetchone()
            if not row:
                self.db.commit()
                return None
            cursor = self.db.execute(
                "UPDATE jobs SET status='running', started=?, attempts=attempts+1 "
                "WHERE id=? AND status='queued'", (now, row[0]))
            self.db.commit()
            if cursor.rowcount:
                return {"id": row[0], "kind": row[1], "payload": json.loads(row[2] or "{}"),
                        "attempts": row[3] + 1, "max_attempts": row[4], "started": now}
        return None

    def finish(self, job_id: int, ok: bool, result: dict | None = None,
               error: str = "", retry_after: float = 0.0) -> str:
        if ok:
            self.db.execute("UPDATE jobs SET status='done', finished=?, result=? WHERE id=?",
                            (time.time(), json.dumps(result or {}), job_id))
            self.db.commit()
            return "done"
        job = self.db.execute("SELECT attempts, max_attempts FROM jobs WHERE id=?", (job_id,)).fetchone()
        if job and job[0] < job[1]:
            delay = retry_after or min(30 * 2 ** (job[0] - 1), 1800)
            self.db.execute("UPDATE jobs SET status='queued', run_after=?, error=? WHERE id=?",
                            (time.time() + delay, error, job_id))
            self.db.commit()
            return "retry"
        self.db.execute("UPDATE jobs SET status='failed', finished=?, error=? WHERE id=?",
                        (time.time(), error, job_id))
        self.db.commit()
        return "failed"

    def fail_final(self, job_id: int, error: str) -> str:
        """Mark failed without consuming remaining attempts (permanent errors)."""
        self.db.execute("UPDATE jobs SET status='failed', finished=?, error=? WHERE id=?",
                        (time.time(), error, job_id))
        self.db.commit()
        return "failed"

    def cancel(self, job_id: int) -> bool:
        cursor = self.db.execute("UPDATE jobs SET status='cancelled', finished=? WHERE id=? AND status='queued'",
                                 (time.time(), job_id))
        self.db.commit()
        return cursor.rowcount > 0

    def list(self, status: str | None = None, limit: int = 20) -> builtins.list[dict]:
        sql = "SELECT id, kind, status, attempts, priority, created, error FROM jobs"
        params: tuple = ()
        if status:
            sql += " WHERE status=?"
            params = (status,)
        sql += " ORDER BY id DESC LIMIT ?"
        rows = self.db.execute(sql, (*params, limit)).fetchall()
        return [{"id": r[0], "kind": r[1], "status": r[2], "attempts": r[3],
                 "priority": r[4], "created": r[5], "error": r[6]} for r in rows]

    def stats(self) -> dict:
        rows = self.db.execute("SELECT status, COUNT(*) FROM jobs GROUP BY status").fetchall()
        return {status: 0 for status in STATUSES} | dict(rows)

    def recover(self) -> int:
        """Requeue jobs left running by a killed worker."""
        cursor = self.db.execute("UPDATE jobs SET status='queued', run_after=? WHERE status='running'",
                                 (time.time(),))
        self.db.commit()
        return cursor.rowcount

    def close(self) -> None:
        self.db.close()


def _connect(path: str):
    import sqlite3
    db = sqlite3.connect(path, timeout=15)
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA busy_timeout=15000")
    return db
