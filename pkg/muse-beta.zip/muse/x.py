"""Multi-account X (Twitter) driver.

Cookie-authenticated v1.1 calls: verify, resolve, follow, like, reply. Accounts
are pooled, every action is deduplicated through a SQLite ledger, and each
account paces itself from the provider's own rate-limit headers.

Auth material is a browser session, not OAuth: `auth_token` + `ct0` cookies.
"""

from __future__ import annotations

import json
import os
import random
import sqlite3
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Iterable
from dataclasses import dataclass, field

BEARER = ("AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs"
          "%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA")
API = "https://api.x.com/1.1"
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")


class XError(RuntimeError):
    def __init__(self, message: str, code: int = 0, payload: dict | None = None):
        super().__init__(message)
        self.code = code
        self.payload = payload or {}


class RateLimited(XError):
    def __init__(self, retry_after: float, payload: dict | None = None):
        super().__init__(f"rate limited, retry in {retry_after:.0f}s", 429, payload)
        self.retry_after = retry_after


@dataclass
class Account:
    handle: str
    auth_token: str
    ct0: str
    proxy: str = ""
    _next_at: float = field(default=0.0, repr=False)
    _cooldown: float = field(default=0.0, repr=False)

    @property
    def key(self) -> str:
        return self.handle.lstrip("@").lower()

    def ready_in(self) -> float:
        return max(0.0, self._next_at - time.time()) + self._cooldown


class Pool:
    def __init__(self, accounts: list[Account], min_gap: float = 3.0, max_gap: float = 9.0):
        self.accounts = accounts
        self.min_gap = min_gap
        self.max_gap = max_gap
        self._cursor = 0

    @classmethod
    def load(cls, path: str, **kwargs) -> Pool:
        with open(path, encoding="utf-8") as handle:
            raw = json.load(handle)
        entries = raw.get("accounts", raw) if isinstance(raw, dict) else raw
        accounts = [Account(handle=e["handle"], auth_token=e["auth_token"], ct0=e["ct0"],
                            proxy=e.get("proxy", "")) for e in entries]
        return cls(accounts, **kwargs)

    def save(self, path: str) -> None:
        body = {"accounts": [{"handle": a.handle, "auth_token": a.auth_token,
                              "ct0": a.ct0, "proxy": a.proxy} for a in self.accounts]}
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(body, handle, indent=2)

    def next(self) -> Account:
        """Least-recently-used account that is ready, else the soonest to free up."""
        candidates = sorted(self.accounts, key=lambda a: a.ready_in())
        for account in candidates:
            if account.ready_in() <= 0:
                self._cursor += 1
                return account
        wait_for = candidates[0].ready_in()
        time.sleep(min(wait_for, 60))
        return candidates[0]

    def pace(self, account: Account) -> None:
        account._next_at = time.time() + random.uniform(self.min_gap, self.max_gap)


class Ledger:
    """Action dedupe + audit trail. One row per (action, account, target)."""

    def __init__(self, path: str = "state/actions.db"):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.execute("""CREATE TABLE IF NOT EXISTS actions(
            action TEXT, account TEXT, target_id TEXT, target TEXT, detail TEXT,
            ok INTEGER, ts REAL, PRIMARY KEY(action, account, target_id))""")
        self.db.commit()

    def seen(self, action: str, account: str, target_id: str) -> bool:
        row = self.db.execute(
            "SELECT 1 FROM actions WHERE action=? AND account=? AND target_id=?",
            (action, account, target_id)).fetchone()
        return row is not None

    def record(self, action: str, account: str, target_id: str, target: str = "",
               detail: str = "", ok: bool = True) -> None:
        self.db.execute(
            "INSERT OR REPLACE INTO actions VALUES(?,?,?,?,?,?,?)",
            (action, account, target_id, target, detail, int(ok), time.time()))
        self.db.commit()

    def count_today(self, action: str, account: str | None = None) -> int:
        start = time.time() - (time.time() % 86400)
        if account:
            row = self.db.execute("SELECT COUNT(*) FROM actions WHERE action=? AND account=? AND ts>=?",
                                  (action, account, start)).fetchone()
        else:
            row = self.db.execute("SELECT COUNT(*) FROM actions WHERE action=? AND ts>=?",
                                  (action, start)).fetchone()
        return int(row[0])

    def history(self, limit: int = 30) -> list[tuple]:
        return self.db.execute(
            "SELECT action, account, target, ok, datetime(ts,'unixepoch','localtime') "
            "FROM actions ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()


class Session:
    """One cookie-authenticated X session."""

    def __init__(self, account: Account, timeout: float = 25.0):
        self.account = account
        self.timeout = timeout
        self.limits: dict[str, int] = {}

    def _headers(self) -> dict:
        return {
            "authorization": f"Bearer {BEARER}",
            "x-csrf-token": self.account.ct0,
            "cookie": f"auth_token={self.account.auth_token}; ct0={self.account.ct0}",
            "user-agent": UA,
            "content-type": "application/x-www-form-urlencoded",
            "x-twitter-active-user": "yes",
            "x-twitter-auth-type": "OAuth2Session",
            "x-twitter-client-language": "en",
            "referer": "https://x.com/",
            "accept": "*/*",
        }

    def request(self, method: str, path: str, params: dict | None = None,
                body: dict | None = None, retries: int = 2) -> dict:
        url = f"{API}/{path.lstrip('/')}"
        if params:
            url += "?" + urllib.parse.urlencode(params)
        data = urllib.parse.urlencode(body).encode() if body is not None else None
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({"https": self.account.proxy}) if self.account.proxy
            else urllib.request.ProxyHandler({}))
        for attempt in range(retries + 1):
            request = urllib.request.Request(url, data=data, method=method, headers=self._headers())
            try:
                with opener.open(request, timeout=self.timeout) as response:
                    self._note_limits(response.headers)
                    return json.loads(response.read().decode() or "{}")
            except urllib.error.HTTPError as exc:
                payload = {}
                try:
                    payload = json.loads(exc.read().decode() or "{}")
                except ValueError:
                    pass
                if exc.code == 429:
                    reset = float(exc.headers.get("x-rate-limit-reset") or 0)
                    wait = max(5.0, reset - time.time()) if reset else 60.0
                    self.account._cooldown = min(wait, 900)
                    if attempt < retries:
                        time.sleep(min(wait, 20.0))
                        continue
                    raise RateLimited(wait, payload) from None
                if exc.code in (500, 502, 503, 504) and attempt < retries:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                raise XError(_message(payload) or f"HTTP {exc.code}", exc.code, payload) from None
            except (urllib.error.URLError, TimeoutError) as exc:
                if attempt == retries:
                    raise XError(f"network: {exc}") from None
                time.sleep(1.5 * (attempt + 1))
        raise XError("unreachable")

    def _note_limits(self, headers) -> None:
        remaining = headers.get("x-rate-limit-remaining")
        if remaining is not None:
            self.account._cooldown = 0.0

    # -- calls -------------------------------------------------------------
    def me(self) -> dict:
        return self.request("GET", "account/verify_credentials.json", {"skip_status": "true"})

    def user(self, screen_name: str) -> dict:
        return self.request("GET", "users/show.json", {"screen_name": screen_name.lstrip("@")})

    def follow(self, user_id: str) -> dict:
        return self.request("POST", "friendships/create.json", body={"user_id": user_id, "follow": "true"})

    def unfollow(self, user_id: str) -> dict:
        return self.request("POST", "friendships/destroy.json", body={"user_id": user_id})

    def like(self, tweet_id: str) -> dict:
        return self.request("POST", "favorites/create.json", body={"id": tweet_id})

    def reply(self, text: str, tweet_id: str) -> dict:
        return self.request("POST", "statuses/update.json",
                            body={"status": text, "in_reply_to_status_id": tweet_id,
                                  "auto_populate_reply_metadata": "true"})

    def timeline(self, screen_name: str, count: int = 20) -> list[dict]:
        data = self.request("GET", "statuses/user_timeline.json", {
            "screen_name": screen_name.lstrip("@"), "count": str(min(count, 100)),
            "tweet_mode": "extended", "exclude_replies": "true", "include_rts": "false",
        })
        return data if isinstance(data, list) else []


def _message(payload: dict) -> str:
    errors = payload.get("errors") or []
    if errors and isinstance(errors, list):
        first = errors[0] or {}
        return f"{first.get('message', '')} [{first.get('code', '')}]"
    return ""


# --------------------------------------------------------------------------
# Operations
# --------------------------------------------------------------------------


@dataclass
class Report:
    acted: int = 0
    skipped: int = 0
    failed: int = 0
    lines: list[str] = field(default_factory=list)

    def add(self, bucket: str, line: str) -> None:
        setattr(self, bucket, getattr(self, bucket) + 1)
        self.lines.append(line)

    def render(self) -> str:
        head = f"acted={self.acted} skipped={self.skipped} failed={self.failed}"
        return "\n".join([head] + self.lines)


def _target_id(session: Session, target: str, cache: dict[str, dict]) -> str | None:
    key = target.lstrip("@").lower()
    if key not in cache:
        try:
            cache[key] = session.user(key)
        except XError as exc:
            if exc.code == 404:
                cache[key] = {}
            else:
                raise
    return (cache[key] or {}).get("id_str")


def follow_targets(pool: Pool, ledger: Ledger, targets: Iterable[str], per_account_cap: int = 40,
                   dry_run: bool = False, pause: bool = True) -> Report:
    report = Report()
    cache: dict[str, dict] = {}
    for target in targets:
        target = target.strip()
        if not target:
            continue
        account = pool.next()
        session = Session(account)
        try:
            user = cache.get(target.lstrip("@").lower()) or session.user(target)
            cache[target.lstrip("@").lower()] = user
        except XError as exc:
            report.add("failed", f"resolve @{target.lstrip('@')}: {exc}")
            continue
        user_id = user.get("id_str")
        name = user.get("screen_name", target)
        if not user_id:
            report.add("failed", f"resolve @{name}: unknown user")
            continue
        if ledger.seen("follow", account.key, user_id):
            report.add("skipped", f"@{name}: already followed by @{account.handle}")
            continue
        if ledger.count_today("follow", account.key) >= per_account_cap:
            report.add("skipped", f"@{name}: @{account.handle} hit daily cap {per_account_cap}")
            continue
        if dry_run:
            report.add("acted", f"DRY follow @{name} as @{account.handle}")
            continue
        try:
            session.follow(user_id)
            ledger.record("follow", account.key, user_id, name)
            report.add("acted", f"follow @{name} as @{account.handle}")
        except RateLimited as exc:
            report.add("skipped", f"@{name}: rate limited {exc.retry_after:.0f}s")
        except XError as exc:
            ledger.record("follow", account.key, user_id, name, str(exc), ok=False)
            report.add("failed", f"@{name}: {exc}")
        if pause:
            pool.pace(account)
    return report


def like_recent(pool: Pool, ledger: Ledger, target: str, count: int = 3, min_length: int = 60,
                keywords: list[str] | None = None, dry_run: bool = False) -> Report:
    report = Report()
    account = pool.next()
    session = Session(account)
    try:
        tweets = session.timeline(target, count=max(count * 6, 20))
    except XError as exc:
        report.add("failed", f"timeline @{target}: {exc}")
        return report
    words = [w.lower() for w in (keywords or [])]
    picked = 0
    for tweet in tweets:
        if picked >= count:
            break
        text = tweet.get("full_text") or tweet.get("text") or ""
        tweet_id = tweet.get("id_str")
        if not tweet_id or len(text) < min_length:
            continue
        if tweet.get("favorited") or tweet.get("retweeted"):
            continue
        if words and not any(word in text.lower() for word in words):
            continue
        if ledger.seen("like", account.key, tweet_id):
            continue
        if dry_run:
            report.add("acted", f"DRY like {tweet_id} (@{target})")
        else:
            try:
                session.like(tweet_id)
                ledger.record("like", account.key, tweet_id, target, text[:120])
                report.add("acted", f"like {tweet_id} (@{target})")
            except RateLimited as exc:
                report.add("skipped", f"like {tweet_id}: rate limited {exc.retry_after:.0f}s")
                break
            except XError as exc:
                report.add("failed", f"like {tweet_id}: {exc}")
                continue
        picked += 1
        pool.pace(account)
    return report


def comment(pool: Pool, ledger: Ledger, target: str, templates: list[str], count: int = 2,
            dry_run: bool = False, offset: int = 0) -> Report:
    """Reply to fresh tweets with rotating templates. `{author}` is substituted."""
    report = Report()
    account = pool.next()
    session = Session(account)
    try:
        tweets = session.timeline(target, count=max(count * 5, 10))
    except XError as exc:
        report.add("failed", f"timeline @{target}: {exc}")
        return report
    made = 0
    for index, tweet in enumerate(tweets):
        if made >= count:
            break
        tweet_id = tweet.get("id_str")
        if not tweet_id or tweet.get("in_reply_to_status_id_str"):
            continue
        if ledger.seen("comment", account.key, tweet_id):
            continue
        template = templates[(offset + index) % len(templates)]
        text = template.format(author=tweet.get("user", {}).get("screen_name", target))
        if dry_run:
            report.add("acted", f"DRY reply {tweet_id}: {text}")
        else:
            try:
                session.reply(text, tweet_id)
                ledger.record("comment", account.key, tweet_id, target, text)
                report.add("acted", f"reply {tweet_id}: {text}")
            except RateLimited as exc:
                report.add("skipped", f"reply {tweet_id}: rate limited {exc.retry_after:.0f}s")
                break
            except XError as exc:
                report.add("failed", f"reply {tweet_id}: {exc}")
                continue
        made += 1
        pool.pace(account)
    return report


def audit(pool: Pool, ledger: Ledger) -> list[str]:
    lines = []
    for account in pool.accounts:
        session = Session(account)
        try:
            me = session.me()
            lines.append(f"@{account.handle}: ok id={me.get('id_str')} "
                         f"followers={me.get('followers_count', '?')}")
        except XError as exc:
            lines.append(f"@{account.handle}: FAIL {exc}")
    for action, account, target, ok, ts in ledger.history(10):
        lines.append(f"  {ts} {action} {target or '-'} @{account} {'ok' if ok else 'fail'}")
    return lines
