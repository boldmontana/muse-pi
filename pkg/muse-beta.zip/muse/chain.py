"""Chain registry and JSON-RPC transport.

The transport treats every provider as hostile: it validates hex quantities,
retries transient failures with jittered backoff, and never trusts a provider's
`eth_chainId` without comparing it against the registry entry.
"""

from __future__ import annotations

import json
import os
import random
import time
import urllib.error
import urllib.request
from typing import Any

from . import core

DEFAULT_CHAINS = {
    "ethereum": {
        "chain_id": 1, "symbol": "ETH", "decimals": 18,
        "rpc": ["https://ethereum-rpc.publicnode.com", "https://cloudflare-eth.com"],
        "explorer": "https://etherscan.io",
    },
    "base": {
        "chain_id": 8453, "symbol": "ETH", "decimals": 18,
        "rpc": ["https://mainnet.base.org", "https://base-rpc.publicnode.com"],
        "explorer": "https://basescan.org",
    },
    "arbitrum": {
        "chain_id": 42161, "symbol": "ETH", "decimals": 18,
        "rpc": ["https://arb1.arbitrum.io/rpc", "https://arbitrum-one-rpc.publicnode.com"],
        "explorer": "https://arbiscan.io",
    },
    "optimism": {
        "chain_id": 10, "symbol": "ETH", "decimals": 18,
        "rpc": ["https://mainnet.optimism.io", "https://optimism-rpc.publicnode.com"],
        "explorer": "https://optimistic.etherscan.io",
    },
    "polygon": {
        "chain_id": 137, "symbol": "POL", "decimals": 18,
        "rpc": ["https://polygon-bor-rpc.publicnode.com", "https://polygon-rpc.com"],
        "explorer": "https://polygonscan.com",
    },
    "bsc": {
        "chain_id": 56, "symbol": "BNB", "decimals": 18,
        "rpc": ["https://bsc-dataseed.binance.org", "https://bsc-rpc.publicnode.com"],
        "explorer": "https://bscscan.com",
    },
    "sepolia": {
        "chain_id": 11155111, "symbol": "ETH", "decimals": 18,
        "rpc": ["https://ethereum-sepolia-rpc.publicnode.com", "https://rpc.sepolia.org"],
        "explorer": "https://sepolia.etherscan.io",
    },
}

SEL_BALANCE_OF = "0x70a08231"
SEL_DECIMALS = "0x313ce567"
SEL_SYMBOL = "0x95d89b41"
SEL_TRANSFER = "0xa9059cbb"
SEL_ALLOWANCE = "0xdd62ed3e"


class RpcError(RuntimeError):
    def __init__(self, message: str, code: int = 0, data: Any = None):
        super().__init__(message)
        self.code = code
        self.data = data


class Chain:
    def __init__(self, key: str, spec: dict, rpc_override: list[str] | None = None):
        self.key = key
        self.chain_id = int(spec["chain_id"])
        self.symbol = spec.get("symbol", "ETH")
        self.decimals = int(spec.get("decimals", 18))
        self.explorer = spec.get("explorer", "")
        self._urls = rpc_override or list(spec.get("rpc", []))
        if not self._urls:
            raise ValueError(f"no RPC endpoint configured for {key}")
        self._preferred = 0

    # -- transport ---------------------------------------------------------
    def _post(self, url: str, payload: dict, timeout: float) -> dict:
        body = json.dumps(payload).encode()
        request = urllib.request.Request(url, data=body, method="POST", headers={
            "content-type": "application/json",
            "user-agent": "muse/1.0.0",
        })
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode())

    def call(self, method: str, params: list | None = None, timeout: float = 20.0,
             retries: int = 3) -> Any:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or []}
        last: Exception | None = None
        for attempt in range(retries + 1):
            url = self._urls[self._preferred % len(self._urls)]
            try:
                reply = self._post(url, payload, timeout)
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
                last = exc
                self._preferred += 1
                time.sleep(min(2 ** attempt * 0.4, 4.0) * (0.8 + random.random() * 0.4))
                continue
            if "error" in reply:
                err = reply["error"] or {}
                raise RpcError(err.get("message", "rpc error"), int(err.get("code", 0) or 0), err.get("data"))
            return reply.get("result")
        raise RpcError(f"{self.key}: all RPC endpoints failed ({last})")

    # -- quantities --------------------------------------------------------
    @staticmethod
    def quantity(value: int) -> str:
        return hex(value)

    @staticmethod
    def to_int(value: Any) -> int:
        if value is None:
            return 0
        if isinstance(value, int):
            return value
        return int(str(value), 16)

    @staticmethod
    def data_address(address: str) -> str:
        return core.normalize_address(address)[2:].rjust(64, "0")

    # -- reads -------------------------------------------------------------
    def verify_chain_id(self) -> int:
        remote = self.to_int(self.call("eth_chainId"))
        if remote != self.chain_id:
            raise RpcError(f"{self.key}: provider reports chain {remote}, expected {self.chain_id}")
        return remote

    def block_number(self) -> int:
        return self.to_int(self.call("eth_blockNumber"))

    def balance(self, address: str) -> int:
        return self.to_int(self.call("eth_getBalance", [core.normalize_address(address), "latest"]))

    def nonce(self, address: str) -> int:
        return self.to_int(self.call("eth_getTransactionCount", [core.normalize_address(address), "pending"]))

    def gas_price(self) -> int:
        return self.to_int(self.call("eth_gasPrice"))

    def priority_fee(self) -> int:
        try:
            return self.to_int(self.call("eth_maxPriorityFeePerGas"))
        except RpcError:
            return max(self.gas_price() // 10, 1)

    def base_fee(self) -> int:
        block = self.call("eth_getBlockByNumber", ["latest", False]) or {}
        return self.to_int(block.get("baseFeePerGas"))

    def estimate_gas(self, tx: dict) -> int:
        return self.to_int(self.call("eth_estimateGas", [tx]))

    def eth_call(self, to: str, data: str) -> bytes:
        result = self.call("eth_call", [{"to": core.normalize_address(to), "data": data}, "latest"])
        return bytes.fromhex(str(result)[2:]) if result and result != "0x" else b""

    def receipt(self, tx_hash: str) -> dict | None:
        return self.call("eth_getTransactionReceipt", [tx_hash])

    def confirmations(self, tx_hash: str) -> int:
        receipt = self.receipt(tx_hash)
        if not receipt:
            return 0
        return max(self.block_number() - self.to_int(receipt.get("blockNumber")), 0) + 1

    # -- ERC-20 ------------------------------------------------------------
    def token_balance(self, token: str, owner: str) -> int:
        raw = self.eth_call(token, SEL_BALANCE_OF + self.data_address(owner))
        return int.from_bytes(raw[:32], "big") if raw else 0

    def token_meta(self, token: str) -> dict:
        try:
            decimals = int.from_bytes(self.eth_call(token, SEL_DECIMALS)[:32], "big")
        except (RpcError, ValueError):
            decimals = 18
        symbol = self.symbol
        try:
            raw = self.eth_call(token, SEL_SYMBOL)
            if len(raw) >= 64:
                length = int.from_bytes(raw[32:64], "big")
                symbol = raw[64:64 + length].decode("utf-8", "replace")
        except (RpcError, ValueError):
            pass
        return {"decimals": decimals, "symbol": symbol}

    # -- writes ------------------------------------------------------------
    def send_raw(self, raw: bytes) -> str:
        return str(self.call("eth_sendRawTransaction", [core.hex0x(raw)], retries=1))

    def format(self, wei: int, decimals: int | None = None) -> str:
        decimals = self.decimals if decimals is None else decimals
        whole, frac = divmod(wei, 10 ** decimals)
        if not frac:
            return f"{whole}"
        return f"{whole}.{str(frac).rjust(decimals, '0').rstrip('0')}"

    def parse(self, amount: str, decimals: int | None = None) -> int:
        decimals = self.decimals if decimals is None else decimals
        text = amount.strip().replace("_", "")
        if text.startswith("-"):
            raise ValueError("negative amount")
        whole, _, frac = text.partition(".")
        if len(frac) > decimals:
            raise ValueError(f"{self.symbol} supports {decimals} decimals, got {len(frac)}")
        return int(whole or 0) * 10 ** decimals + int((frac or "0").ljust(decimals, "0"))

    def explorer_tx(self, tx_hash: str) -> str:
        return f"{self.explorer}/tx/{tx_hash}" if self.explorer else ""


def load_registry(path: str | None = None, overrides: dict | None = None) -> dict:
    spec = json.loads(json.dumps(DEFAULT_CHAINS))
    if path and os.path.exists(path):
        with open(path, encoding="utf-8") as handle:
            user = json.load(handle)
        for key, value in (user.get("chains") or {}).items():
            spec.setdefault(key, {}).update(value)
    for key, value in (overrides or {}).items():
        spec.setdefault(key, {}).update(value)
    return spec


def resolve(registry: dict, key: str, rpc_override: list[str] | None = None) -> Chain:
    if key not in registry:
        raise KeyError(f"unknown chain {key!r}; known: {', '.join(sorted(registry))}")
    return Chain(key, registry[key], rpc_override)
