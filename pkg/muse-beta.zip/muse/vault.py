"""Encrypted on-disk vault.

File format (JSON, 0600):

    {"version": 1,
     "kdf": {"name": "scrypt", "n": 32768, "r": 8, "p": 1, "salt": "<hex>"},
     "nonce": "<hex>", "ciphertext": "<hex>", "tag": "<hex>"}

Encryption is HMAC-SHA256 in counter mode over a scrypt-derived key, with a
separate MAC key (encrypt-then-MAC). No third-party crypto library is needed,
and the payload never touches disk in plaintext.

Payload:

    {"mnemonic": "<bip39>", "passphrase": "<bip39 passphrase>",
     "next_index": {"ethereum": 3, ...}, "notes": {...}}
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import tempfile

from . import core

VERSION = 1
MIN_PASSPHRASE = 8
SCRYPT_N = 1 << 15
PBKDF2_ROUNDS = 600_000


def _kdf(passphrase: str, salt: bytes, params: dict) -> bytes:
    if params["name"] == "scrypt":
        # OpenSSL's default 32 MiB cap is below 128*N*r for these params.
        maxmem = 128 * params["n"] * params["r"] * params["p"] + (1 << 20)
        return hashlib.scrypt(passphrase.encode(), salt=salt, n=params["n"], r=params["r"],
                              p=params["p"], dklen=64, maxmem=maxmem)
    if params["name"] == "pbkdf2-sha256":
        return hashlib.pbkdf2_hmac("sha256", passphrase.encode(), salt, params["rounds"], 64)
    raise ValueError(f"unknown kdf {params['name']!r}")


def _new_params() -> dict:
    if hasattr(hashlib, "scrypt"):
        return {"name": "scrypt", "n": SCRYPT_N, "r": 8, "p": 1}
    return {"name": "pbkdf2-sha256", "rounds": PBKDF2_ROUNDS}


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    out = bytearray()
    counter = 0
    while len(out) < length:
        out += hmac.new(key, nonce + counter.to_bytes(4, "big"), hashlib.sha256).digest()
        counter += 1
    return bytes(out[:length])


def _seal(plaintext: bytes, passphrase: str) -> dict:
    params = _new_params()
    salt = secrets.token_bytes(16)
    nonce = secrets.token_bytes(16)
    material = _kdf(passphrase, salt, params)
    enc_key, mac_key = material[:32], material[32:]
    ciphertext = bytes(a ^ b for a, b in zip(plaintext, _keystream(enc_key, nonce, len(plaintext))))
    tag = hmac.new(mac_key, nonce + ciphertext, hashlib.sha256).digest()
    params["salt"] = salt.hex()
    return {
        "version": VERSION,
        "kdf": params,
        "nonce": nonce.hex(),
        "ciphertext": base64.b64encode(ciphertext).decode(),
        "tag": tag.hex(),
    }


def _open(blob: dict, passphrase: str) -> bytes:
    if blob.get("version") != VERSION:
        raise ValueError("unsupported vault version")
    params = dict(blob["kdf"])
    salt = bytes.fromhex(params.pop("salt"))
    nonce = bytes.fromhex(blob["nonce"])
    ciphertext = base64.b64decode(blob["ciphertext"])
    material = _kdf(passphrase, salt, params)
    enc_key, mac_key = material[:32], material[32:]
    expected = hmac.new(mac_key, nonce + ciphertext, hashlib.sha256).digest()
    if not hmac.compare_digest(expected, bytes.fromhex(blob["tag"])):
        raise ValueError("wrong passphrase or corrupted vault")
    return bytes(a ^ b for a, b in zip(ciphertext, _keystream(enc_key, nonce, len(ciphertext))))


class Vault:
    """A vault bound to one path. Call :meth:`unlock` before use."""

    def __init__(self, path: str):
        self.path = os.path.abspath(path)
        self.data: dict = {}
        self._passphrase: str = ""

    # -- lifecycle ---------------------------------------------------------
    @classmethod
    def create(cls, path: str, passphrase: str, mnemonic: str = "", bip39_passphrase: str = "") -> Vault:
        if len(passphrase) < MIN_PASSPHRASE:
            raise ValueError(f"passphrase needs at least {MIN_PASSPHRASE} characters")
        phrase = mnemonic or core.generate_mnemonic(128)
        if not core.mnemonic_valid(phrase):
            raise ValueError("invalid BIP-39 mnemonic")
        vault = cls(path)
        vault.data = {"mnemonic": " ".join(phrase.split()), "passphrase": bip39_passphrase,
                      "next_index": {}, "notes": {}}
        vault._passphrase = passphrase
        vault.save()
        return vault

    def exists(self) -> bool:
        return os.path.exists(self.path)

    def unlock(self, passphrase: str) -> Vault:
        with open(self.path, encoding="utf-8") as handle:
            blob = json.load(handle)
        self.data = json.loads(_open(blob, passphrase).decode())
        self._passphrase = passphrase
        return self

    def save(self) -> None:
        blob = _seal(json.dumps(self.data, separators=(",", ":")).encode(), self._passphrase)
        directory = os.path.dirname(self.path) or "."
        os.makedirs(directory, exist_ok=True)
        handle, tmp = tempfile.mkstemp(dir=directory, prefix=".vault-", suffix=".tmp")
        try:
            with os.fdopen(handle, "w", encoding="utf-8") as fh:
                json.dump(blob, fh, indent=2)
            os.chmod(tmp, 0o600)
            os.replace(tmp, self.path)
        finally:
            if os.path.exists(tmp):
                os.unlink(tmp)

    # -- accounts ----------------------------------------------------------
    def next_index(self, chain: str) -> int:
        return int(self.data.setdefault("next_index", {}).get(chain, 0))

    def derive(self, chain: str, index: int | None = None) -> tuple:
        """Derive (address, private_key). Defaults to the next unused index."""
        bump = index is None
        index = self.next_index(chain) if bump else int(index)
        address, priv = core.derive_account(self.data["mnemonic"], index, self.data.get("passphrase", ""))
        if bump:
            self.data["next_index"][chain] = index + 1
            self.save()
        return address, priv

    def accounts(self, count_by_chain: dict) -> list[dict]:
        out = []
        for chain, count in count_by_chain.items():
            for index in range(count):
                address, _ = core.derive_account(self.data["mnemonic"], index, self.data.get("passphrase", ""))
                out.append({"chain": chain, "index": index, "address": address,
                            "path": f"m/44'/60'/0'/0/{index}"})
        return out


def write_recovery(vault: Vault, path: str) -> None:
    """Plain mnemonic card for offline storage (0600)."""
    body = [
        "MUSE BETA 1.0 RECOVERY CARD",
        "keep offline, never in a repo",
        "",
        "mnemonic: " + vault.data["mnemonic"],
        "bip39 passphrase: " + (vault.data.get("passphrase") or "(none)"),
        "",
    ]
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write("\n".join(body))
