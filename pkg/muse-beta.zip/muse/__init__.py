"""MUSE BETA 1.0 — local-first multi-chain wallet, multi-account X operator, operator layer."""

__version__ = "1.0.0"

from . import chain, cli, core, tx, vault, x  # noqa: F401
