"""Transaction construction, signing and broadcast.

Only self-custody paths: keys never leave the process, and every transaction is
signed locally after optional `eth_call` simulation.
"""

from __future__ import annotations

import time

from . import core
from .chain import Chain, RpcError

SPEED = {
    # multiplier on the priority fee, plus a base-fee headroom multiplier
    "slow": (0.8, 1.15),
    "normal": (1.0, 1.35),
    "fast": (1.6, 1.6),
    "ape": (3.0, 2.2),
}


def _fees(chain: Chain, speed: str) -> tuple[int, int]:
    if speed not in SPEED:
        raise ValueError(f"speed must be one of {', '.join(SPEED)}")
    priority_mult, base_mult = SPEED[speed]
    priority = max(int(chain.priority_fee() * priority_mult), 1)
    base = chain.base_fee() or chain.gas_price()
    max_fee = int(base * base_mult) + priority
    return priority, max_fee


SEL_TRANSFER = "0xa9059cbb"


def erc20_transfer_data(to: str, amount: int) -> str:
    return "0x" + SEL_TRANSFER[2:] + chain_pad(to) + hex(amount)[2:].rjust(64, "0")


def chain_pad(address: str) -> str:
    return core.normalize_address(address)[2:].rjust(64, "0")


def build_1559(chain: Chain, nonce: int, to: str, value: int, data: str, gas: int,
               priority: int, max_fee: int) -> list:
    return [chain.chain_id, nonce, priority, max_fee, gas,
            bytes.fromhex(core.normalize_address(to)[2:]), value,
            bytes.fromhex(data[2:]) if data and data != "0x" else b"", []]


def sign_1559(fields: list, priv: int) -> bytes:
    payload = b"\x02" + core.rlp_encode(fields)
    digest = core.keccak256(payload)
    r, s, parity = core.sign_digest(priv, digest)
    if not core.verify_digest(core.private_to_public(priv), digest, r, s):
        raise RuntimeError("signature failed self-check")
    return payload + core.rlp_encode(fields + [parity, r, s])


def build_legacy(chain: Chain, nonce: int, to: str, value: int, data: str, gas: int, gas_price: int) -> list:
    return [nonce, gas_price, gas, bytes.fromhex(core.normalize_address(to)[2:]), value,
            bytes.fromhex(data[2:]) if data and data != "0x" else b""]


def sign_legacy(fields: list, priv: int, chain_id: int) -> bytes:
    digest = core.keccak256(core.rlp_encode(fields + [chain_id, 0, 0]))
    r, s, parity = core.sign_digest(priv, digest)
    if not core.verify_digest(core.private_to_public(priv), digest, r, s):
        raise RuntimeError("signature failed self-check")
    return core.rlp_encode(fields + [parity + 35 + chain_id * 2, r, s])


def simulate(chain: Chain, sender: str, to: str, value: int, data: str) -> tuple[bool, str]:
    """Dry-run through eth_call; reports revert reason instead of burning gas."""
    call = {"from": core.normalize_address(sender), "to": core.normalize_address(to), "value": hex(value)}
    if data and data != "0x":
        call["data"] = data
    try:
        chain.call("eth_call", [call, "latest"])
        return True, ""
    except RpcError as exc:
        return False, str(exc)


def prepare_and_send(chain: Chain, address: str, priv: int, to: str, amount: int,
                     speed: str = "normal", data: str = "0x", gas_limit: int | None = None,
                     dry_run: bool = False) -> dict:
    """Full send path. Returns a report dict; `dry_run` stops before broadcast."""
    address = core.normalize_address(address)
    to = core.normalize_address(to)
    balance = chain.balance(address)
    nonce = chain.nonce(address)

    priority, max_fee = _fees(chain, speed)
    if gas_limit is None:
        try:
            gas_limit = int(chain.estimate_gas({"from": address, "to": to, "value": hex(amount), "data": data}) * 1.2)
        except RpcError as exc:
            raise RpcError(f"gas estimation failed: {exc}") from None

    cost = amount + gas_limit * max_fee
    report = {
        "chain": chain.key, "from": address, "to": to, "value": chain.format(amount),
        "gas_limit": gas_limit, "max_fee_gwei": round(max_fee / 1e9, 6),
        "priority_gwei": round(priority / 1e9, 6),
        "nonce": nonce, "balance": chain.format(balance),
    }
    if cost > balance:
        raise RuntimeError(f"insufficient funds: need {chain.format(cost)} {chain.symbol}, have {chain.format(balance)}")

    ok, reason = simulate(chain, address, to, amount, data)
    report["simulation"] = "ok" if ok else f"revert: {reason}"
    if not ok:
        raise RuntimeError(f"simulation reverted: {reason}")

    fields = build_1559(chain, nonce, to, amount, data, gas_limit, priority, max_fee)
    raw = sign_1559(fields, priv)
    report["raw_size"] = len(raw)
    if dry_run:
        report["tx_hash"] = core.hex0x(core.keccak256(raw))
        report["broadcast"] = False
        return report

    tx_hash = chain.send_raw(raw)
    report["tx_hash"] = tx_hash
    report["explorer"] = chain.explorer_tx(tx_hash)
    report["broadcast"] = True
    return report


def wait(chain: Chain, tx_hash: str, timeout: float = 180.0, poll: float = 4.0) -> dict:
    deadline = time.time() + timeout
    while time.time() < deadline:
        receipt = chain.receipt(tx_hash)
        if receipt:
            return {
                "status": "success" if chain.to_int(receipt.get("status")) == 1 else "reverted",
                "block": chain.to_int(receipt.get("blockNumber")),
                "gas_used": chain.to_int(receipt.get("gasUsed")),
                "explorer": chain.explorer_tx(tx_hash),
            }
        time.sleep(poll)
    return {"status": "pending", "explorer": chain.explorer_tx(tx_hash)}
