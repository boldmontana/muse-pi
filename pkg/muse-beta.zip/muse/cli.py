"""Command line interface: `python -m muse ...`."""

from __future__ import annotations

import argparse
import getpass
import json
import os
import sys

from . import chain as chain_mod
from . import core, health, jobs, memory, runner, schedule, tx
from . import fetch as fetch_mod
from . import pack as pack_mod
from . import vault as vault_mod
from . import x as x_mod

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DEFAULT_HOME = os.environ.get("MUSE_HOME", os.path.join(".", "state"))


def _path(name: str, cli_value: str | None) -> str:
    return cli_value or os.path.join(DEFAULT_HOME, name)


def _passphrase(confirm: bool = False) -> str:
    env = os.environ.get("MUSE_PASSPHRASE")
    if env:
        return env
    first = getpass.getpass("vault passphrase: ")
    if confirm:
        if first != getpass.getpass("repeat passphrase: "):
            raise SystemExit("passphrases differ")
    return first


def _open_vault(args) -> vault_mod.Vault:
    vault = vault_mod.Vault(_path("vault.json", args.vault))
    if not vault.exists():
        raise SystemExit(f"no vault at {vault.path}; run `muse new` first")
    return vault.unlock(_passphrase())


def _chains(args) -> dict:
    return chain_mod.load_registry(args.chains_config)


def _resolve(args, key: str) -> chain_mod.Chain:
    return chain_mod.resolve(_chains(args), key)


# --------------------------------------------------------------------------
# wallet commands
# --------------------------------------------------------------------------


def cmd_new(args) -> int:
    path = _path("vault.json", args.vault)
    passphrase = _passphrase(confirm=True)
    vault = vault_mod.Vault.create(path, passphrase, args.mnemonic, args.bip39_passphrase)
    vault_mod.write_recovery(vault, _path("recovery.txt", args.recovery))
    print(f"vault   {path}")
    print(f"address {core.derive_account(vault.data['mnemonic'], 0)[0]}")
    print(f"recovery {_path('recovery.txt', args.recovery)}")
    if args.show_words:
        print("\n" + vault.data["mnemonic"])
    return 0


def cmd_import(args) -> int:
    path = _path("vault.json", args.vault)
    if os.path.exists(path) and not args.force:
        raise SystemExit(f"{path} exists; pass --force to replace")
    passphrase = _passphrase(confirm=True)
    vault_mod.Vault.create(path, passphrase, args.mnemonic, args.bip39_passphrase)
    print(f"imported into {path}")
    return 0


def cmd_address(args) -> int:
    vault = _open_vault(args)
    known = _chains(args)
    chains = list(dict.fromkeys(args.chain))
    for chain_key in chains:
        if chain_key not in known:
            raise KeyError(f"unknown chain {chain_key!r}; known: {', '.join(sorted(known))}")
    rows = []
    for chain_key in chains:
        if args.index is None:
            for _ in range(args.count):
                address, _ = vault.derive(chain_key)
                rows.append((chain_key, vault.next_index(chain_key) - 1, address))
        else:
            for delta in range(args.count):
                address, _ = vault.derive(chain_key, args.index + delta)
                rows.append((chain_key, args.index + delta, address))
    width = max((len(r[0]) for r in rows), default=0)
    for chain_key, index, address in rows:
        print(f"{chain_key.ljust(width)}  #{index:<4} {address}")
    if args.json:
        print(json.dumps([{"chain": c, "index": i, "address": a} for c, i, a in rows]))
    return 0


def cmd_balances(args) -> int:
    vault = _open_vault(args)
    total = {}
    for chain_key in args.chain:
        resolver = _resolve(args, chain_key)
        resolver.verify_chain_id()
        for index in range(args.count):
            address, _ = vault.derive(chain_key, index)
            wei = resolver.balance(address)
            token_line = ""
            if args.token:
                raw = resolver.token_balance(args.token, address)
                meta = resolver.token_meta(args.token)
                token_line = f"  {resolver.format(raw, meta['decimals'])} {meta['symbol']}"
            total[chain_key] = total.get(chain_key, 0) + wei
            print(f"{chain_key:10} #{index:<3} {address}  {resolver.format(wei)} {resolver.symbol}{token_line}")
    print("\ntotals")
    for chain_key, wei in total.items():
        resolver = _resolve(args, chain_key)
        print(f"{chain_key:10} {resolver.format(wei)} {resolver.symbol}")
    return 0


def cmd_show_keys(args) -> int:
    vault = _open_vault(args)
    for chain_key in args.chain:
        for index in range(args.count):
            address, priv = vault.derive(chain_key, index)
            print(f"{chain_key:10} #{index:<3} {address}  0x{priv:064x}")
    return 0


def cmd_send(args) -> int:
    vault = _open_vault(args)
    resolver = _resolve(args, args.chain)
    resolver.verify_chain_id()
    address, priv = vault.derive(args.chain, args.index)
    amount = resolver.parse(args.amount)
    data, to = "0x", args.to
    if args.token:
        meta = resolver.token_meta(args.token)
        amount = resolver.parse(args.amount, meta["decimals"])
        data = tx.erc20_transfer_data(args.to, amount)
        to = args.token
    report = tx.prepare_and_send(resolver, address, priv, to, amount, args.speed,
                                 data=data, gas_limit=args.gas, dry_run=args.dry_run)
    for key, value in report.items():
        print(f"{key}: {value}")
    if report.get("broadcast") and args.wait:
        print(json.dumps(tx.wait(resolver, report["tx_hash"])))
    return 0


def cmd_sweep(args) -> int:
    vault = _open_vault(args)
    destination = core.normalize_address(args.to)
    resolver = _resolve(args, args.chain)
    resolver.verify_chain_id()
    plan = []
    for index in range(args.count):
        address, _ = vault.derive(args.chain, index)
        if core.normalize_address(address) == destination:
            continue
        wei = resolver.balance(address)
        if wei <= 0:
            continue
        plan.append((index, address, wei))
    if not plan:
        print("nothing to sweep")
        return 0
    for index, address, wei in plan:
        print(f"#{index} {address} {resolver.format(wei)} {resolver.symbol}")
    if args.dry_run or not args.yes:
        answer = "y" if args.yes else input("sweep? [y/N] ")
        if answer.lower() != "y":
            return 1
    for index, address, wei in plan:
        _, priv = vault.derive(args.chain, index)
        priority, max_fee = tx._fees(resolver, args.speed)
        gas = 21000
        amount = wei - int(gas * max_fee * 1.2)
        if amount <= 0:
            print(f"#{index}: dust, skipped")
            continue
        try:
            report = tx.prepare_and_send(resolver, address, priv, destination, amount,
                                         args.speed, dry_run=args.dry_run)
        except (chain_mod.RpcError, RuntimeError) as exc:
            print(f"#{index}: {exc}")
            continue
        print(f"#{index} {report.get('tx_hash')}")
    return 0


# --------------------------------------------------------------------------
# X commands
# --------------------------------------------------------------------------


def _pool(args) -> x_mod.Pool:
    return x_mod.Pool.load(_path("x-accounts.json", args.accounts))


def _ledger(args) -> x_mod.Ledger:
    return x_mod.Ledger(_path("actions.db", args.state))


def cmd_x_accounts(args) -> int:
    pool = _pool(args)
    for account in pool.accounts:
        state = "ready" if account.ready_in() <= 0 else f"cooling {account.ready_in():.0f}s"
        print(f"@{account.handle:20} {state}{' proxy' if account.proxy else ''}")
    return 0


def cmd_x_add(args) -> int:
    try:
        pool = _pool(args)
    except (FileNotFoundError, ValueError):
        pool = x_mod.Pool([])
    pool.accounts.append(x_mod.Account(args.handle, args.auth_token, args.ct0, args.proxy or ""))
    pool.save(_path("x-accounts.json", args.accounts))
    print(f"added @{args.handle.lstrip('@')}")
    return 0


def cmd_x_check(args) -> int:
    pool = _pool(args)
    rc = 0
    for account in pool.accounts:
        try:
            me = x_mod.Session(account).me()
            print(f"@{account.handle}: ok id={me.get('id_str')} followers={me.get('followers_count', '?')}")
        except x_mod.XError as exc:
            rc = 1
            print(f"@{account.handle}: FAIL {exc}")
    return rc


def _targets(args) -> list[str]:
    if args.targets:
        return args.targets
    if args.file:
        with open(args.file, encoding="utf-8") as handle:
            return [line.strip() for line in handle if line.strip() and not line.startswith("#")]
    raise SystemExit("pass targets or --file")


def cmd_x_follow(args) -> int:
    report = x_mod.follow_targets(_pool(args), _ledger(args), _targets(args),
                                  per_account_cap=args.cap, dry_run=args.dry_run)
    print(report.render())
    return 1 if report.failed and not report.acted else 0


def cmd_x_like(args) -> int:
    report = x_mod.like_recent(_pool(args), _ledger(args), args.target, args.count,
                               min_length=args.min_length, keywords=args.keyword, dry_run=args.dry_run)
    print(report.render())
    return 1 if report.failed and not report.acted else 0


def cmd_x_comment(args) -> int:
    templates = args.templates or [
        "this is sharp, {author}. the framing in the second half lands.",
        "good thread, {author}. saving this one.",
        "agree with most of this. the part about constraints is underrated.",
    ]
    report = x_mod.comment(_pool(args), _ledger(args), args.target, templates, args.count,
                           dry_run=args.dry_run, offset=args.offset)
    print(report.render())
    return 1 if report.failed and not report.acted else 0


def cmd_x_audit(args) -> int:
    for line in x_mod.audit(_pool(args), _ledger(args)):
        print(line)
    return 0


def cmd_ledger(args) -> int:
    ledger = _ledger(args)
    for action, account, target, ok, ts in ledger.history(args.limit):
        print(f"{ts}  {action:8} {target or '-':24} @{account} {'ok' if ok else 'fail'}")
    for action in ("follow", "like", "comment"):
        print(f"today {action}: {ledger.count_today(action)}")
    return 0


def cmd_doctor(args) -> int:
    from . import __version__

    print(f"muse {__version__}  python {sys.version.split()[0]}  platform {sys.platform}")
    print(f"scrypt: {'yes' if hasattr(__import__('hashlib'), 'scrypt') else 'no (pbkdf2 fallback)'}")
    print(f"vault: {'present' if os.path.exists(_path('vault.json', args.vault)) else 'absent'}")
    print(f"home:  {os.path.abspath(DEFAULT_HOME)}")
    ok = True
    for key in ("ethereum", "base"):
        try:
            resolver = _resolve(args, key)
            print(f"rpc {key}: chain {resolver.verify_chain_id()} block {resolver.block_number()}")
        except Exception as exc:  # noqa: BLE001 - doctor reports, never raises
            ok = False
            print(f"rpc {key}: FAIL {exc}")
    try:
        pool = _pool(args)
        print(f"x accounts: {len(pool.accounts)}")
    except Exception as exc:  # noqa: BLE001
        print(f"x accounts: none ({exc})")
    return 0 if ok else 1



# --------------------------------------------------------------------------
# operations: health, memory, queue, schedule, fetch, pack
# --------------------------------------------------------------------------


def _ctx(args) -> dict:
    home = os.path.abspath(DEFAULT_HOME)
    os.makedirs(home, exist_ok=True)
    return {"root": ROOT, "home": home}


def _memory(args) -> memory.Memory:
    return memory.Memory(_path("memory.db", None))


def cmd_health(args) -> int:
    ctx = _ctx(args)
    if args.repin:
        digest = health.repin(ctx["root"], ctx["home"])
        print(digest or "no SOUL.md to pin")
    checks = health.run_checks(ctx["root"], ctx["home"], network=not args.fast)
    print(health.render(checks))
    if args.json:
        print(json.dumps(checks, indent=2))
    return 1 if args.strict and health.summarize(checks)["fail"] else 0


def cmd_note_add(args) -> int:
    body = args.body
    if body == "-":
        body = sys.stdin.read()
    note_id = _memory(args).add(args.title, body, args.kind, args.tags, args.ref or "")
    print(f"note {note_id}")
    return 0


def cmd_note_search(args) -> int:
    rows = _memory(args).search(args.query, args.limit)
    for row in rows:
        print(f"#{row['id']:<4} {row['kind']:<8} {row['title']}  [{row['tags']}]")
    return 0 if rows else 1


def cmd_note_list(args) -> int:
    for row in _memory(args).recent(args.limit, args.kind):
        print(f"#{row['id']:<4} {row['kind']:<8} {row['title']}")
    return 0


def cmd_note_show(args) -> int:
    note = _memory(args).get(args.id)
    if not note:
        print("not found")
        return 1
    print(f"#{note['id']} {note['kind']} {note['title']}")
    if note["tags"]:
        print(f"tags: {note['tags']}")
    if note["ref"]:
        print(f"ref: {note['ref']}")
    print()
    print(note["body"])
    return 0


def cmd_note_rm(args) -> int:
    print("removed" if _memory(args).delete(args.id) else "not found")
    return 0


def _queue(args) -> runner.Queue:
    return runner.Queue(_path("jobs.db", None))


def cmd_job_add(args) -> int:
    payload = json.loads(args.payload or "{}")
    if args.kind not in jobs.HANDLERS:
        print(f"warning: unknown kind {args.kind!r}; known: {', '.join(sorted(jobs.HANDLERS))}", file=sys.stderr)
    job_id = _queue(args).add(args.kind, payload, run_after=args.after, priority=args.priority)
    print(f"job {job_id} queued")
    return 0


def cmd_job_list(args) -> int:
    for job in _queue(args).list(args.status, args.limit):
        print(f"#{job['id']:<4} {job['status']:<9} {job['kind']:<10} try {job['attempts']}  {job['error'] or ''}")
    return 0


def cmd_job_run(args) -> int:
    queue = _queue(args)
    results = jobs.drain(queue, _ctx(args), limit=args.limit)
    for result in results:
        print(json.dumps(result))
    return 0 if all(r["state"] in ("done", "retry") for r in results) else 1


def cmd_job_work(args) -> int:
    queue = _queue(args)
    recovered = queue.recover()
    if recovered:
        print(f"requeued {recovered} interrupted job(s)")
    jobs.worker(queue, _ctx(args), idle=args.idle, stop_after=args.limit or None)
    return 0


def cmd_job_cancel(args) -> int:
    print("cancelled" if _queue(args).cancel(args.id) else "not cancellable")
    return 0


def cmd_job_tick(args) -> int:
    store = schedule.Store(_path("schedules.db", None))
    queue = _queue(args)
    fired = store.tick()
    for item in fired:
        queue.add(item["kind"], item["payload"], schedule_id=item["id"])
        print(f"queued {item['kind']} from schedule {item['id']}")
    store.close()
    return 0 if fired else 1


def cmd_schedule_add(args) -> int:
    store = schedule.Store(_path("schedules.db", None))
    try:
        schedule_id = store.add(args.expression, args.kind, json.loads(args.payload or "{}"))
    except schedule.CronError as exc:
        print(f"bad cron: {exc}", file=sys.stderr)
        return 1
    finally:
        store.close()
    print(f"schedule {schedule_id}: {args.expression}")
    return 0


def cmd_schedule_list(args) -> int:
    store = schedule.Store(_path("schedules.db", None))
    for item in store.list():
        state = "on" if item["enabled"] else "off"
        print(f"#{item['id']:<3} {state}  {item['expression']:<20} {item['kind']} {json.dumps(item['payload'])}")
    store.close()
    return 0


def cmd_schedule_rm(args) -> int:
    store = schedule.Store(_path("schedules.db", None))
    print("removed" if store.remove(args.id) else "not found")
    store.close()
    return 0


def cmd_fetch(args) -> int:
    try:
        result = fetch_mod.fetch(args.url, _path("fetch", None), ttl=args.ttl, raw=args.raw)
    except fetch_mod.FetchError as exc:
        print(f"fetch failed: {exc}", file=sys.stderr)
        return 1
    if args.out:
        os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
        with open(args.out, "w", encoding="utf-8") as handle:
            handle.write(result.get("text") or "")
        print(args.out)
        return 0
    print(f"{result['status']} {result['content_type']} {result['bytes']}b -> {result['cache_path']}")
    if args.raw:
        print("raw bytes cached; use --out to write them")
    else:
        print()
        print((result.get("text") or "")[: args.chars])
    return 0


def cmd_pack(args) -> int:
    from . import __version__
    out = args.out or os.path.join(ROOT, "dist", f"muse-beta-{__version__}.zip")
    info = pack_mod.build(ROOT, out, __version__)
    print(f"{info['path']}  {info['files']} files  {info['bytes']} bytes")
    print(f"sha256 {info['sha256']}")
    return 0


# --------------------------------------------------------------------------
# parser
# --------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="muse", description="local-first multi-chain wallet and X operator")
    parser.add_argument("--vault", help="vault path (default state/vault.json)")
    parser.add_argument("--recovery", help="recovery card path")
    parser.add_argument("--accounts", help="X account file")
    parser.add_argument("--state", help="state directory: vault, ledgers, caches")
    parser.add_argument("--chains-config", help="chain registry overrides")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("doctor", help="check environment, RPC and sessions")
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser("new", help="create a vault")
    p.add_argument("--mnemonic", default="")
    p.add_argument("--bip39-passphrase", default="")
    p.add_argument("--show-words", action="store_true")
    p.set_defaults(func=cmd_new)

    p = sub.add_parser("import", help="import an existing mnemonic")
    p.add_argument("mnemonic")
    p.add_argument("--bip39-passphrase", default="")
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_import)

    p = sub.add_parser("address", help="derive receive addresses")
    p.add_argument("--chain", action="append", required=True)
    p.add_argument("--count", type=int, default=1)
    p.add_argument("--index", type=int)
    p.add_argument("--json", action="store_true")
    p.set_defaults(func=cmd_address)

    p = sub.add_parser("balances", help="read balances")
    p.add_argument("--chain", action="append", required=True)
    p.add_argument("--count", type=int, default=1)
    p.add_argument("--token")
    p.set_defaults(func=cmd_balances)

    p = sub.add_parser("keys", help="print private keys")
    p.add_argument("--chain", action="append", default=["ethereum"])
    p.add_argument("--count", type=int, default=1)
    p.set_defaults(func=cmd_show_keys)

    p = sub.add_parser("send", help="send native or ERC-20")
    p.add_argument("--chain", required=True)
    p.add_argument("--to", required=True)
    p.add_argument("--amount", required=True)
    p.add_argument("--index", type=int, default=0)
    p.add_argument("--token")
    p.add_argument("--speed", default="normal", choices=list(tx.SPEED))
    p.add_argument("--gas", type=int)
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--wait", action="store_true")
    p.set_defaults(func=cmd_send)

    p = sub.add_parser("sweep", help="consolidate derived addresses")
    p.add_argument("--chain", required=True)
    p.add_argument("--to", required=True)
    p.add_argument("--count", type=int, default=10)
    p.add_argument("--speed", default="normal", choices=list(tx.SPEED))
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--yes", action="store_true")
    p.set_defaults(func=cmd_sweep)

    xp = sub.add_parser("x", help="X account operations")
    xsub = xp.add_subparsers(dest="x_command", required=True)

    p = xsub.add_parser("accounts")
    p.set_defaults(func=cmd_x_accounts)

    p = xsub.add_parser("add")
    p.add_argument("handle")
    p.add_argument("auth_token")
    p.add_argument("ct0")
    p.add_argument("--proxy", default="")
    p.set_defaults(func=cmd_x_add)

    p = xsub.add_parser("check")
    p.set_defaults(func=cmd_x_check)

    p = xsub.add_parser("follow")
    p.add_argument("targets", nargs="*")
    p.add_argument("--file")
    p.add_argument("--cap", type=int, default=40)
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=cmd_x_follow)

    p = xsub.add_parser("like")
    p.add_argument("target")
    p.add_argument("--count", type=int, default=3)
    p.add_argument("--min-length", type=int, default=60)
    p.add_argument("--keyword", action="append")
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=cmd_x_like)

    p = xsub.add_parser("comment")
    p.add_argument("target")
    p.add_argument("--count", type=int, default=2)
    p.add_argument("--templates", action="append")
    p.add_argument("--offset", type=int, default=0)
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(func=cmd_x_comment)

    p = xsub.add_parser("audit")
    p.set_defaults(func=cmd_x_audit)

    p = sub.add_parser("ledger", help="recent actions")
    p.add_argument("--limit", type=int, default=30)
    p.set_defaults(func=cmd_ledger)

    p = sub.add_parser("health", help="readiness checks and charter pin")
    p.add_argument("--fast", action="store_true", help="skip network checks")
    p.add_argument("--strict", action="store_true", help="exit 1 on any failure")
    p.add_argument("--json", action="store_true")
    p.add_argument("--repin", action="store_true", help="accept the current SOUL.md hash")
    p.set_defaults(func=cmd_health)

    np = sub.add_parser("note", help="searchable memory")
    nsub = np.add_subparsers(dest="note_command", required=True)
    p = nsub.add_parser("add")
    p.add_argument("title")
    p.add_argument("--body", default="-", help="note body, `-` reads stdin")
    p.add_argument("--kind", default="note", choices=list(memory.KINDS))
    p.add_argument("--tags", default="")
    p.add_argument("--ref", default="")
    p.set_defaults(func=cmd_note_add)
    p = nsub.add_parser("search")
    p.add_argument("query")
    p.add_argument("--limit", type=int, default=20)
    p.set_defaults(func=cmd_note_search)
    p = nsub.add_parser("list")
    p.add_argument("--kind")
    p.add_argument("--limit", type=int, default=20)
    p.set_defaults(func=cmd_note_list)
    p = nsub.add_parser("show")
    p.add_argument("id", type=int)
    p.set_defaults(func=cmd_note_show)
    p = nsub.add_parser("rm")
    p.add_argument("id", type=int)
    p.set_defaults(func=cmd_note_rm)

    jp = sub.add_parser("job", help="durable job queue")
    jsub = jp.add_subparsers(dest="job_command", required=True)
    p = jsub.add_parser("add")
    p.add_argument("kind")
    p.add_argument("--payload", default="{}")
    p.add_argument("--after", type=float, default=0.0)
    p.add_argument("--priority", type=int, default=5)
    p.set_defaults(func=cmd_job_add)
    p = jsub.add_parser("list")
    p.add_argument("--status", choices=list(runner.STATUSES))
    p.add_argument("--limit", type=int, default=20)
    p.set_defaults(func=cmd_job_list)
    p = jsub.add_parser("run")
    p.add_argument("--limit", type=int, default=50)
    p.set_defaults(func=cmd_job_run)
    p = jsub.add_parser("work")
    p.add_argument("--limit", type=int, default=0)
    p.add_argument("--idle", type=float, default=2.0)
    p.set_defaults(func=cmd_job_work)
    p = jsub.add_parser("cancel")
    p.add_argument("id", type=int)
    p.set_defaults(func=cmd_job_cancel)
    p = jsub.add_parser("tick")
    p.set_defaults(func=cmd_job_tick)

    sp = sub.add_parser("schedule", help="cron entries that enqueue jobs")
    ssub = sp.add_subparsers(dest="schedule_command", required=True)
    p = ssub.add_parser("add")
    p.add_argument("expression")
    p.add_argument("kind")
    p.add_argument("--payload", default="{}")
    p.set_defaults(func=cmd_schedule_add)
    p = ssub.add_parser("list")
    p.set_defaults(func=cmd_schedule_list)
    p = ssub.add_parser("rm")
    p.add_argument("id", type=int)
    p.set_defaults(func=cmd_schedule_rm)

    p = sub.add_parser("fetch", help="polite cached HTTP fetch")
    p.add_argument("url")
    p.add_argument("--ttl", type=float, default=900.0)
    p.add_argument("--raw", action="store_true")
    p.add_argument("--out")
    p.add_argument("--chars", type=int, default=2000)
    p.set_defaults(func=cmd_fetch)

    p = sub.add_parser("pack", help="deterministic zip of the stack")
    p.add_argument("--out")
    p.set_defaults(func=cmd_pack)

    return parser


def main(argv: list[str] | None = None) -> int:
    global DEFAULT_HOME
    parser = build_parser()
    args = parser.parse_args(argv)
    if args.state:
        DEFAULT_HOME = args.state
    if args.command == "x" and args.x_command == "add" and not args.accounts:
        args.accounts = None
    try:
        return int(args.func(args) or 0)
    except (ValueError, RuntimeError, KeyError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
