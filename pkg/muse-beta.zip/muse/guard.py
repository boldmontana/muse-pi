"""Secrets, paths and confirmation.

Every log line, JSON dump and report goes through :func:`redact` before it leaves the
process. Path writes go through :func:`assert_inside` so a relative traversal cannot
escape the workspace.
"""

from __future__ import annotations

import os
import re
from collections.abc import Iterable

_REDACTIONS = (
    # 32-byte private keys first: the address rule would otherwise eat them partially
    (re.compile(r"\b0x[0-9a-fA-F]{64}\b"), lambda m: m.group(0)[:8] + "…" + m.group(0)[-6:]),
    (re.compile(r"\b0x[0-9a-fA-F]{40}\b"), lambda m: m.group(0)[:6] + "…" + m.group(0)[-4:]),
    (re.compile(r"(auth_token=)[^;\s\"']+"), lambda m: m.group(1) + m.group(0).split("=", 1)[1][:6] + "…"),
    (re.compile(r"(ct0=)[^;\s\"']+"), lambda m: m.group(1) + m.group(0).split("=", 1)[1][:6] + "…"),
    (re.compile(r"(?i)([?&](?:api[_-]?key|key|apikey|token)=)[^&\s\"']+"), lambda m: m.group(1) + "…"),
    (re.compile(r"(?i)(bearer\s+)\S+"), lambda m: m.group(1) + "…"),
    (re.compile(r"\b([\w.+-])[\w.+-]*@([\w-]+\.[\w.-]+)\b"), lambda m: m.group(1) + "***@" + m.group(2)),
    (re.compile(r"(?i)\b(api[_-]?key|secret|token)\b(\s*[:=]\s*)['\"]?([A-Za-z0-9_\-/+]{12,})"),
     lambda m: m.group(1) + m.group(2) + m.group(3)[:6] + "…"),
)

SENSITIVE_NAME = re.compile(r"(vault\.json|recovery\.txt|\.env|x-accounts\.json|\.pem|\.key)$")


def redact(text: str) -> str:
    out = text
    for pattern, repl in _REDACTIONS:
        out = pattern.sub(repl, out)
    return out


def assert_inside(path: str, root: str) -> str:
    """Return the real path, or raise if it escapes `root`."""
    real_root = os.path.realpath(root)
    real = os.path.realpath(path)
    if os.path.commonpath([real_root, real]) != real_root:
        raise ValueError(f"{path} escapes {root}")
    return real


def is_sensitive(path: str) -> bool:
    return bool(SENSITIVE_NAME.search(path))


def redact_lines(lines: Iterable[str]) -> list[str]:
    return [redact(line) for line in lines]


def confirm(prompt: str, assume_yes: bool = False) -> bool:
    if assume_yes:
        return True
    return input(f"{prompt} [y/N] ").strip().lower() == "y"
