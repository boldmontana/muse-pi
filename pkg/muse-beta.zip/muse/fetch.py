"""Polite HTTP fetch with an on-disk cache.

One request per host at a time, minimum gap per host, size cap, content-type allowlist.
HTML is reduced to text for reading; `raw` keeps the bytes.
"""

from __future__ import annotations

import gzip
import hashlib
import html
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import zlib

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
MAX_BYTES = 4 * 1024 * 1024
TEXT_TYPES = ("text/", "application/json", "application/xml", "application/xhtml", "application/rss")
_SKIP = re.compile(r"<(script|style|noscript|svg)\b.*?</\1>", re.S | re.I)
_TAG = re.compile(r"<[^>]+>")
_WS = re.compile(r"\n{3,}")
_last_hit: dict[str, float] = {}


class FetchError(RuntimeError):
    pass


def _cache_paths(cache_dir: str, url: str) -> tuple[str, str]:
    digest = hashlib.sha256(url.encode()).hexdigest()[:24]
    return os.path.join(cache_dir, digest + ".bin"), os.path.join(cache_dir, digest + ".json")


def to_text(raw: str) -> str:
    text = _SKIP.sub(" ", raw)
    text = _TAG.sub(" ", text)
    text = html.unescape(text)
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = _WS.sub("\n\n", text)
    return text.strip()


def fetch(url: str, cache_dir: str = "state/fetch", ttl: float = 900.0, raw: bool = False,
          timeout: float = 20.0) -> dict:
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in ("http", "https"):
        raise FetchError(f"unsupported scheme {parsed.scheme!r}")
    os.makedirs(cache_dir, exist_ok=True)
    bin_path, meta_path = _cache_paths(cache_dir, url)

    if os.path.exists(meta_path) and time.time() - os.path.getmtime(meta_path) < ttl:
        meta = json.loads(open(meta_path).read())
        meta["cached"] = True
        if not raw and os.path.exists(bin_path):
            meta["text"] = open(bin_path, encoding="utf-8", errors="replace").read()
        return meta

    host = parsed.netloc
    gap = 1.2 - (time.time() - _last_hit.get(host, 0))
    if gap > 0:
        time.sleep(gap)

    request = urllib.request.Request(url, headers={"user-agent": UA, "accept": "*/*",
                                                   "accept-encoding": "gzip, deflate"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read(MAX_BYTES + 1)
            content_type = response.headers.get("content-type", "")
            encoding = response.headers.get("content-encoding", "")
            status = response.status
            final = response.geturl()
    except urllib.error.HTTPError as exc:
        raise FetchError(f"HTTP {exc.code} for {url}") from None
    except (urllib.error.URLError, TimeoutError) as exc:
        raise FetchError(f"network: {exc}") from None
    finally:
        _last_hit[host] = time.time()

    if len(body) > MAX_BYTES:
        body = body[:MAX_BYTES]
    if encoding == "gzip":
        body = gzip.decompress(body)
    elif encoding == "deflate":
        body = zlib.decompress(body)

    allowed = any(kind in content_type.lower() for kind in TEXT_TYPES)
    text = body.decode("utf-8", "replace") if allowed else ""
    if allowed and "html" in content_type.lower():
        text = to_text(text)

    meta = {"url": url, "final": final, "status": status, "content_type": content_type,
            "bytes": len(body), "fetched": time.time(), "cache_path": bin_path, "cached": False}
    with open(bin_path, "wb") as handle:
        handle.write(body if not allowed or raw else text.encode())
    with open(meta_path, "w", encoding="utf-8") as handle:
        json.dump(meta, handle)
    if not raw:
        meta["text"] = text
    return meta


def read_cache(url: str, cache_dir: str = "state/fetch") -> dict | None:
    _, meta_path = _cache_paths(cache_dir, url)
    if not os.path.exists(meta_path):
        return None
    return json.loads(open(meta_path).read())
