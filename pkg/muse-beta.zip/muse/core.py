"""Primitives with no third-party dependencies.

Keccak-256, secp256k1 (RFC 6979 deterministic ECDSA), RLP, EIP-55 checksums,
BIP-39 seed expansion and BIP-32 child key derivation.

Everything here is constant-time only where it is cheap to be; the wallet code
treats the local machine as trusted and the RPC provider as hostile.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import unicodedata
from collections.abc import Iterable, Sequence

# --------------------------------------------------------------------------
# Keccak-256 (original Keccak padding 0x01, not SHA3's 0x06)
# --------------------------------------------------------------------------

_RC = (
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A, 0x8000000080008000,
    0x000000000000808B, 0x0000000080000001, 0x8000000080008081, 0x8000000000008009,
    0x000000000000008A, 0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089, 0x8000000000008003,
    0x8000000000008002, 0x8000000000000080, 0x000000000000800A, 0x800000008000000A,
    0x8000000080008081, 0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
)

_ROT = (
    (0, 36, 3, 41, 18),
    (1, 44, 10, 45, 2),
    (62, 6, 43, 15, 61),
    (28, 55, 25, 21, 56),
    (27, 20, 39, 8, 14),
)

_MASK = (1 << 64) - 1
_RATE = 136  # bytes, 1088-bit permutation width for 256-bit output


def _rol(value: int, shift: int) -> int:
    if shift == 0:
        return value & _MASK
    return ((value << shift) | (value >> (64 - shift))) & _MASK


def _permute(state: list[int]) -> None:
    for rnd in range(24):
        c = [state[x] ^ state[x + 5] ^ state[x + 10] ^ state[x + 15] ^ state[x + 20] for x in range(5)]
        d = [c[(x - 1) % 5] ^ _rol(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                state[x + 5 * y] ^= d[x]

        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = _rol(state[x + 5 * y], _ROT[x][y])

        for y in range(5):
            for x in range(5):
                state[x + 5 * y] = b[x + 5 * y] ^ ((~b[(x + 1) % 5 + 5 * y]) & b[(x + 2) % 5 + 5 * y])

        state[0] ^= _RC[rnd]


def keccak256(data: bytes) -> bytes:
    """Keccak-256 as used by Ethereum (substrate of all hashing below)."""
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError("keccak256 expects bytes")
    buf = bytearray(data)
    buf.append(0x01)
    while len(buf) % _RATE:
        buf.append(0x00)
    buf[-1] |= 0x80

    state = [0] * 25
    for off in range(0, len(buf), _RATE):
        block = buf[off:off + _RATE]
        for i in range(_RATE // 8):
            state[i] ^= int.from_bytes(block[i * 8:i * 8 + 8], "little")
        _permute(state)

    out = bytearray()
    while len(out) < 32:
        for i in range(_RATE // 8):
            out.extend(state[i].to_bytes(8, "little"))
        if len(out) < 32:
            _permute(state)
    return bytes(out[:32])


# --------------------------------------------------------------------------
# secp256k1
# --------------------------------------------------------------------------

P = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
GX = 0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798
GY = 0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8
G = (GX, GY)

Point = tuple[int, int]


def _inv(value: int, modulus: int) -> int:
    return pow(value % modulus, modulus - 2, modulus)


def point_add(a: Point, b: Point) -> Point:
    if a is None:
        return b
    if b is None:
        return a
    x1, y1 = a
    x2, y2 = b
    if x1 == x2 and (y1 + y2) % P == 0:
        return None
    if a == b:
        lam = (3 * x1 * x1) * _inv(2 * y1, P) % P
    else:
        lam = (y2 - y1) * _inv(x2 - x1, P) % P
    x3 = (lam * lam - x1 - x2) % P
    return (x3, (lam * (x1 - x3) - y1) % P)


def point_mul(scalar: int, point: Point = G) -> Point:
    scalar %= N
    result: Point = None
    addend = point
    while scalar:
        if scalar & 1:
            result = point_add(result, addend)
        addend = point_add(addend, addend)
        scalar >>= 1
    return result


def private_to_public(priv: int) -> bytes:
    """Uncompressed 64-byte public key (x || y, no 0x04 prefix)."""
    point = point_mul(priv)
    return point[0].to_bytes(32, "big") + point[1].to_bytes(32, "big")


def compress_public(pub: bytes) -> bytes:
    """33-byte SEC1 compressed form, as BIP-32 requires for public derivation."""
    return bytes([2 + (pub[-1] & 1)]) + pub[:32]


def _rfc6979_k(priv: int, digest: bytes) -> int:
    x = priv.to_bytes(32, "big")
    h = (int.from_bytes(digest, "big") % N).to_bytes(32, "big")
    v = b"\x01" * 32
    k = b"\x00" * 32
    k = hmac.new(k, v + b"\x00" + x + h, hashlib.sha256).digest()
    v = hmac.new(k, v, hashlib.sha256).digest()
    k = hmac.new(k, v + b"\x01" + x + h, hashlib.sha256).digest()
    v = hmac.new(k, v, hashlib.sha256).digest()
    while True:
        v = hmac.new(k, v, hashlib.sha256).digest()
        candidate = int.from_bytes(v, "big")
        if 1 <= candidate < N:
            return candidate
        k = hmac.new(k, v + b"\x00", hashlib.sha256).digest()
        v = hmac.new(k, v, hashlib.sha256).digest()


def sign_digest(priv: int, digest: bytes) -> tuple[int, int, int]:
    """Deterministic low-s signature. Returns (r, s, y_parity)."""
    if len(digest) != 32:
        raise ValueError("digest must be 32 bytes")
    z = int.from_bytes(digest, "big")
    nonce = _rfc6979_k(priv, digest)
    point = point_mul(nonce)
    r = point[0] % N
    if r == 0:
        raise ValueError("degenerate nonce")
    s = (_inv(nonce, N) * (z + r * priv)) % N
    if s == 0:
        raise ValueError("degenerate signature")
    parity = point[1] & 1
    if s > N // 2:
        s = N - s
        parity ^= 1
    return r, s, parity


def verify_digest(pub: bytes, digest: bytes, r: int, s: int) -> bool:
    if not (1 <= r < N and 1 <= s < N):
        return False
    x = int.from_bytes(pub[:32], "big")
    y = int.from_bytes(pub[32:], "big")
    if (y * y - x * x * x - 7) % P:
        return False
    z = int.from_bytes(digest, "big")
    w = _inv(s, N)
    point = point_add(point_mul(z * w % N), point_mul(r * w % N, (x, y)))
    return point is not None and point[0] % N == r


# --------------------------------------------------------------------------
# RLP
# --------------------------------------------------------------------------


def _rlp_length(length: int, offset: int) -> bytes:
    if length < 56:
        return bytes([offset + length])
    encoded = length.to_bytes((length.bit_length() + 7) // 8, "big")
    return bytes([offset + 55 + len(encoded)]) + encoded


def rlp_encode(item) -> bytes:
    if isinstance(item, (bytes, bytearray)):
        payload = bytes(item)
        if len(payload) == 1 and payload[0] < 0x80:
            return payload
        return _rlp_length(len(payload), 0x80) + payload
    if isinstance(item, int):
        if item < 0:
            raise ValueError("RLP cannot encode negatives")
        return rlp_encode(b"" if item == 0 else item.to_bytes((item.bit_length() + 7) // 8, "big"))
    if isinstance(item, (list, tuple)):
        payload = b"".join(rlp_encode(part) for part in item)
        return _rlp_length(len(payload), 0xC0) + payload
    raise TypeError(f"cannot RLP-encode {type(item)!r}")


def rlp_decode(blob: bytes):
    item, pos = _rlp_decode_at(blob, 0)
    if pos != len(blob):
        raise ValueError("trailing bytes after RLP item")
    return item


def rlp_decode_at(blob: bytes, pos: int = 0):
    """Decode one item at `pos` and return `(item, next_pos)`.

    Needed for signed transactions, which are two RLP payloads back to back.
    """
    return _rlp_decode_at(blob, pos)


def _rlp_decode_at(blob: bytes, pos: int):
    if pos >= len(blob):
        raise ValueError("truncated RLP")
    prefix = blob[pos]
    if prefix < 0x80:
        return blob[pos:pos + 1], pos + 1
    if prefix <= 0xB7:
        size = prefix - 0x80
        start = pos + 1
        return blob[start:start + size], start + size
    if prefix <= 0xBF:
        size_len = prefix - 0xB7
        size = int.from_bytes(blob[pos + 1:pos + 1 + size_len], "big")
        start = pos + 1 + size_len
        return blob[start:start + size], start + size
    if prefix <= 0xF7:
        size = prefix - 0xC0
        return _rlp_decode_list(blob, pos + 1, pos + 1 + size)
    size_len = prefix - 0xF7
    size = int.from_bytes(blob[pos + 1:pos + 1 + size_len], "big")
    start = pos + 1 + size_len
    return _rlp_decode_list(blob, start, start + size)


def _rlp_decode_list(blob: bytes, start: int, end: int):
    out = []
    pos = start
    while pos < end:
        item, pos = _rlp_decode_at(blob, pos)
        out.append(item)
    if pos != end:
        raise ValueError("list length mismatch")
    return out, end


# --------------------------------------------------------------------------
# Addresses
# --------------------------------------------------------------------------


def checksum_address(address: str | bytes) -> str:
    """EIP-55 mixed-case checksum form."""
    if isinstance(address, bytes):
        raw = address.hex()
    else:
        raw = address.lower().removeprefix("0x")
    if len(raw) != 40:
        raise ValueError(f"not an address: {address!r}")
    digest = keccak256(raw.encode()).hex()
    return "0x" + "".join(c.upper() if int(digest[i], 16) >= 8 else c for i, c in enumerate(raw))


def normalize_address(address: str) -> str:
    raw = address.strip()
    if not raw.startswith(("0x", "0X")):
        raw = "0x" + raw
    if len(raw) != 42:
        raise ValueError(f"not an address: {address!r}")
    try:
        int(raw, 16)
    except ValueError:
        raise ValueError(f"not an address: {address!r}") from None
    return raw.lower()


def pubkey_to_address(pub: bytes) -> str:
    if len(pub) != 64:
        raise ValueError("expected 64-byte uncompressed public key")
    return checksum_address(keccak256(pub)[12:])


# --------------------------------------------------------------------------
# BIP-39 / BIP-32
# --------------------------------------------------------------------------

_HERE = os.path.dirname(os.path.abspath(__file__))
_WORDLIST_PATH = os.path.join(_HERE, "data", "bip39-english.txt")
_WORDLIST: list[str] | None = None
_WORDLIST_INDEX: dict | None = None

HARDENED = 0x80000000


def wordlist() -> list[str]:
    global _WORDLIST
    if _WORDLIST is None:
        with open(_WORDLIST_PATH, encoding="utf-8") as handle:
            words = [line.strip() for line in handle if line.strip()]
        if len(words) != 2048:
            raise RuntimeError("corrupt BIP-39 wordlist")
        _WORDLIST = words
    return _WORDLIST


def _index() -> dict:
    global _WORDLIST_INDEX
    if _WORDLIST_INDEX is None:
        _WORDLIST_INDEX = {word: i for i, word in enumerate(wordlist())}
    return _WORDLIST_INDEX


def mnemonic_from_entropy(entropy: bytes) -> str:
    if len(entropy) not in (16, 20, 24, 28, 32):
        raise ValueError("entropy must be 128-256 bits")
    digest = hashlib.sha256(entropy).digest()
    bits = len(entropy) * 8
    checksum_bits = bits // 32
    # Keep entropy plus the leading checksum bits only.
    stream = int.from_bytes(entropy + digest, "big") >> (256 - checksum_bits)
    total = bits + checksum_bits
    words = wordlist()
    return " ".join(words[(stream >> (total - 11 * (i + 1))) & 0x7FF] for i in range(total // 11))


def generate_mnemonic(strength: int = 128) -> str:
    if strength % 32 or not 128 <= strength <= 256:
        raise ValueError("strength must be 128..256 in steps of 32")
    return mnemonic_from_entropy(os.urandom(strength // 8))


def mnemonic_valid(mnemonic: str) -> bool:
    parts = mnemonic.strip().split()
    if len(parts) not in (12, 15, 18, 21, 24):
        return False
    index = _index()
    try:
        stream = 0
        for word in parts:
            stream = (stream << 11) | index[word]
    except KeyError:
        return False
    total = len(parts) * 11
    bits = total * 32 // 33
    checksum_bits = total - bits
    checksum = stream & ((1 << checksum_bits) - 1)
    entropy = (stream >> checksum_bits).to_bytes(bits // 8, "big")
    digest = hashlib.sha256(entropy).digest()
    expected = int.from_bytes(digest, "big") >> (256 - checksum_bits)
    return checksum == expected


def mnemonic_to_seed(mnemonic: str, passphrase: str = "") -> bytes:
    normalized = " ".join(unicodedata.normalize("NFKD", mnemonic).split())
    salt = "mnemonic" + unicodedata.normalize("NFKD", passphrase)
    return hashlib.pbkdf2_hmac("sha512", normalized.encode(), salt.encode(), 2048)


def master_key(seed: bytes) -> tuple[int, bytes]:
    digest = hmac.new(b"Bitcoin seed", seed, hashlib.sha512).digest()
    key = int.from_bytes(digest[:32], "big")
    if not 0 < key < N:
        raise ValueError("invalid master key")
    return key, digest[32:]


def _ckd_priv(key: int, chain_code: bytes, index: int) -> tuple[int, bytes]:
    if index >= 1 << 32:
        raise ValueError("index overflow")
    if index & HARDENED:
        data = b"\x00" + key.to_bytes(32, "big") + index.to_bytes(4, "big")
    else:
        data = compress_public(private_to_public(key)) + index.to_bytes(4, "big")
    digest = hmac.new(chain_code, data, hashlib.sha512).digest()
    child = (int.from_bytes(digest[:32], "big") + key) % N
    if child == 0:
        raise ValueError("degenerate child key")
    return child, digest[32:]


def parse_path(path: str) -> list[int]:
    if path in ("m", "M", ""):
        return []
    parts = path.split("/")
    if parts[0] not in ("m", "M"):
        raise ValueError("path must start with m/")
    out = []
    for part in parts[1:]:
        hardened = part.endswith(("'", "h", "H"))
        body = part[:-1] if hardened else part
        if not body.isdigit():
            raise ValueError(f"bad path segment: {part!r}")
        value = int(body)
        if value >= HARDENED:
            raise ValueError(f"segment out of range: {part!r}")
        out.append(value | HARDENED if hardened else value)
    return out


def derive_private(seed: bytes, path: str) -> int:
    key, chain = master_key(seed)
    for index in parse_path(path):
        key, chain = _ckd_priv(key, chain, index)
    return key


def derive_account(mnemonic: str, index: int, passphrase: str = "", account: int = 0) -> tuple[str, int]:
    """m/44'/60'/account'/0/index -> (checksummed address, private key)."""
    seed = mnemonic_to_seed(mnemonic, passphrase)
    priv = derive_private(seed, f"m/44'/60'/{account}'/0/{index}")
    return pubkey_to_address(private_to_public(priv)), priv


def private_from_hex(raw: str) -> int:
    text = raw.strip().lower().removeprefix("0x")
    if len(text) != 64:
        raise ValueError("private key must be 32 bytes of hex")
    value = int(text, 16)
    if not 0 < value < N:
        raise ValueError("private key out of range")
    return value


def hex0x(payload: bytes) -> str:
    return "0x" + payload.hex()


def chunk(seq: Sequence, size: int) -> Iterable:
    for i in range(0, len(seq), size):
        yield seq[i:i + size]
