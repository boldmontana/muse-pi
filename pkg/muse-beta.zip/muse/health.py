"""Readiness checks. Never raises; a check that cannot run is a `fail` with a reason."""

from __future__ import annotations

import hashlib
import os
import shutil
import sys
import time

from . import guard

MIN_FREE_MB = 256


def _row(name: str, status: str, detail: str) -> dict:
    return {"check": name, "status": status, "detail": guard.redact(detail)}


def disk_check(home: str) -> dict:
    free = shutil.disk_usage(home if os.path.isdir(home) else ".").free // (1024 * 1024)
    status = "ok" if free >= MIN_FREE_MB else "fail"
    return _row("disk", status, f"{free} MiB free (min {MIN_FREE_MB})")


def vault_check(home: str) -> dict:
    path = os.path.join(home, "vault.json")
    if not os.path.exists(path):
        return _row("vault", "warn", "absent — run `muse new`")
    mode = os.stat(path).st_mode & 0o777
    return _row("vault", "ok" if mode == 0o600 else "fail", f"mode {oct(mode)}")


def charter_check(root: str, home: str) -> dict:
    """Detect drift between the loaded charter and the one this session started with."""
    soul = os.path.join(root, "SOUL.md")
    if not os.path.exists(soul):
        return _row("charter", "warn", "SOUL.md not found")
    digest = hashlib.sha256(open(soul, "rb").read()).hexdigest()
    stamp = os.path.join(home, "charter.sha256")
    if not os.path.exists(stamp):
        open(stamp, "w").write(digest + "\n")
        return _row("charter", "ok", "pinned on first run")
    pinned = open(stamp).read().strip()
    return _row("charter", "ok" if pinned == digest else "warn",
                "matches pin" if pinned == digest else "SOUL.md changed since pin; re-pin with `muse health --repin`")


def skills_check(root: str) -> dict:
    skills = os.path.join(root, "skills")
    if not os.path.isdir(skills):
        return _row("skills", "warn", "no skills directory")
    files = []
    for base, _, names in os.walk(skills):
        files.extend(os.path.join(base, name) for name in names if name.endswith(".md"))
    return _row("skills", "ok" if files else "warn", f"{len(files)} skill files, {len(os.listdir(skills))} packs")


def python_check() -> dict:
    ok = sys.version_info >= (3, 9)
    return _row("python", "ok" if ok else "fail", sys.version.split()[0])


def scrypt_check() -> dict:
    import hashlib
    return _row("scrypt", "ok" if hasattr(hashlib, "scrypt") else "warn", "available" if hasattr(hashlib, "scrypt") else "pbkdf2 fallback")


def x_check(home: str) -> dict:
    path = os.path.join(home, "x-accounts.json")
    if not os.path.exists(path):
        return _row("x", "warn", "no accounts file")
    from . import x
    try:
        pool = x.Pool.load(path)
    except (OSError, ValueError, KeyError) as exc:
        return _row("x", "fail", f"unreadable: {exc}")
    return _row("x", "ok" if pool.accounts else "warn", f"{len(pool.accounts)} accounts")


def rpc_check(network: bool) -> list[dict]:
    if not network:
        return [_row("rpc", "info", "skipped (--fast)")]
    from . import chain as chain_mod
    out = []
    for key in ("ethereum", "base"):
        started = time.time()
        try:
            resolver = chain_mod.resolve(chain_mod.load_registry(), key)
            resolver.verify_chain_id()
            out.append(_row(f"rpc:{key}", "ok", f"{(time.time() - started) * 1000:.0f} ms"))
        except Exception as exc:  # noqa: BLE001 - health reports instead of raising
            out.append(_row(f"rpc:{key}", "fail", str(exc)))
    return out


def run_checks(root: str, home: str, network: bool = True) -> list[dict]:
    checks = [python_check(), scrypt_check(), vault_check(home), disk_check(home),
              charter_check(root, home), skills_check(root), x_check(home)]
    checks.extend(rpc_check(network))
    return checks


def summarize(checks: list[dict]) -> dict:
    counts = {"ok": 0, "warn": 0, "fail": 0, "info": 0}
    for check in checks:
        counts[check["status"]] = counts.get(check["status"], 0) + 1
    return counts


def render(checks: list[dict]) -> str:
    width = max(len(c["check"]) for c in checks) if checks else 0
    lines = [f"{c['check'].ljust(width)}  {c['status'].upper():5}  {c['detail']}" for c in checks]
    summary = summarize(checks)
    lines.append("")
    lines.append(f"ok={summary['ok']} warn={summary['warn']} fail={summary['fail']}")
    return "\n".join(lines)


def repin(root: str, home: str) -> str | None:
    soul = os.path.join(root, "SOUL.md")
    if not os.path.exists(soul):
        return None
    digest = hashlib.sha256(open(soul, "rb").read()).hexdigest()
    open(os.path.join(home, "charter.sha256"), "w").write(digest + "\n")
    return digest
