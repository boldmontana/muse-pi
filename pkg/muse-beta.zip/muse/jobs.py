"""Job handlers and the worker loop.

Handlers are plain functions `(ctx, payload) -> dict`. `ctx` carries `root` (repo) and
`home` (state dir). Anything the handler writes is recorded in memory so a later session
can find it.
"""

from __future__ import annotations

import json
import os
import time
from typing import Callable

from . import chain as chain_mod
from . import fetch as fetch_mod
from . import health, memory, pack, runner
from . import vault as vault_mod
from . import x as x_mod

Handler = Callable[[dict, dict], dict]
HANDLERS: dict[str, Handler] = {}


def handler(kind: str) -> Callable[[Handler], Handler]:
    def register(func: Handler) -> Handler:
        HANDLERS[kind] = func
        return func
    return register


def _memory(ctx: dict) -> memory.Memory:
    return memory.Memory(os.path.join(ctx["home"], "memory.db"))


@handler("health")
def job_health(ctx: dict, payload: dict) -> dict:
    checks = health.run_checks(ctx["root"], ctx["home"], network=bool(payload.get("network", True)))
    summary = health.summarize(checks)
    _memory(ctx).add("health check", health.render(checks), "artifact", "health")
    return {"summary": summary}


@handler("balances")
def job_balances(ctx: dict, payload: dict) -> dict:
    passphrase = os.environ.get("MUSE_PASSPHRASE")
    if not passphrase:
        raise RuntimeError("MUSE_PASSPHRASE is not set")
    vault = vault_mod.Vault(os.path.join(ctx["home"], "vault.json")).unlock(passphrase)
    chains = payload.get("chains") or ["base"]
    count = int(payload.get("count", 1))
    snapshot = {"taken": time.time(), "chains": {}}
    for key in chains:
        resolver = chain_mod.resolve(chain_mod.load_registry(payload.get("chains_config")), key)
        resolver.verify_chain_id()
        rows = []
        for index in range(count):
            address, _ = vault.derive(key, index)
            rows.append({"index": index, "address": address, "wei": str(resolver.balance(address))})
        snapshot["chains"][key] = rows
    target = os.path.join(ctx["home"], "snapshots", f"balances-{int(time.time())}.json")
    os.makedirs(os.path.dirname(target), exist_ok=True)
    with open(target, "w", encoding="utf-8") as handle:
        json.dump(snapshot, handle, indent=2)
    _memory(ctx).add("balance snapshot", target, "artifact", "wallet,balances", ref=target)
    return {"chains": chains, "wallets": count * len(chains), "file": target}


@handler("x_audit")
def job_x_audit(ctx: dict, payload: dict) -> dict:
    accounts_path = os.path.join(ctx["home"], "x-accounts.json")
    if not os.path.exists(accounts_path):
        raise RuntimeError("no x-accounts.json")
    pool = x_mod.Pool.load(accounts_path)
    if not pool.accounts:
        raise RuntimeError("no accounts configured")
    ledger = x_mod.Ledger(os.path.join(ctx["home"], "actions.db"))
    lines = x_mod.audit(pool, ledger)
    _memory(ctx).add("x audit", "\n".join(lines), "artifact", "x")
    return {"lines": len(lines)}


@handler("fetch")
def job_fetch(ctx: dict, payload: dict) -> dict:
    url = payload.get("url")
    if not url:
        raise RuntimeError("payload.url required")
    result = fetch_mod.fetch(url, cache_dir=os.path.join(ctx["home"], "fetch"),
                             ttl=float(payload.get("ttl", 900)))
    _memory(ctx).add(f"fetched {url}", (result.get("text") or "")[:4000], "artifact", "fetch", ref=url)
    return {"status": result["status"], "bytes": result["bytes"], "cache": result["cache_path"]}


@handler("prune")
def job_prune(ctx: dict, payload: dict) -> dict:
    removed = _memory(ctx).prune(int(payload.get("days", 30)))
    return {"notes_removed": removed}


@handler("pack")
def job_pack(ctx: dict, payload: dict) -> dict:
    version = payload.get("version", "0.0.0")
    target = payload.get("out") or os.path.join(ctx["root"], "dist", f"muse-beta-{version}.zip")
    return pack.build(ctx["root"], target, version)


@handler("noop")
def job_noop(ctx: dict, payload: dict) -> dict:
    return {"echo": payload}


def run_one(queue: runner.Queue, ctx: dict) -> dict | None:
    job = queue.claim()
    if not job:
        return None
    func = HANDLERS.get(job["kind"])
    started = time.time()
    if not func:
        state = queue.fail_final(job["id"], f"unknown job kind {job['kind']!r}")
        return {"id": job["id"], "kind": job["kind"], "state": state,
                "error": f"unknown job kind {job['kind']!r}"}
    try:
        result = func(ctx, job["payload"])
        state = queue.finish(job["id"], True, result)
        return {"id": job["id"], "kind": job["kind"], "state": state,
                "duration": round(time.time() - started, 3)}
    except Exception as exc:  # noqa: BLE001 - the queue records the failure
        state = queue.finish(job["id"], False, error=f"{type(exc).__name__}: {exc}")
        return {"id": job["id"], "kind": job["kind"], "state": state, "error": str(exc)}


def drain(queue: runner.Queue, ctx: dict, limit: int = 100, sleep: float = 0.0) -> list[dict]:
    out = []
    for _ in range(limit):
        result = run_one(queue, ctx)
        if not result:
            break
        out.append(result)
        if sleep:
            time.sleep(sleep)
    return out


def worker(queue: runner.Queue, ctx: dict, idle: float = 2.0, stop_after: int | None = None) -> None:
    handled = 0
    while True:
        result = run_one(queue, ctx)
        if not result:
            if stop_after is not None and handled >= stop_after:
                return
            time.sleep(idle)
            continue
        handled += 1
        print(json.dumps(result), flush=True)
        if stop_after is not None and handled >= stop_after:
            return
