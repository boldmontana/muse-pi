"""Searchable notes.

Findings, decisions, offsets, addresses, and "why" — the memory the charter says not to
lose. FTS5 when the SQLite build has it, `LIKE` otherwise; both return the same shape.
"""

from __future__ import annotations

import os
import re
import sqlite3
import time

KINDS = ("note", "finding", "decision", "artifact", "blocker")


class Memory:
    def __init__(self, path: str = "state/memory.db"):
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.execute("""CREATE TABLE IF NOT EXISTS notes(
            id INTEGER PRIMARY KEY, ts REAL, kind TEXT, title TEXT, body TEXT, tags TEXT, ref TEXT)""")
        self.fts = False
        try:
            self.db.execute("CREATE VIRTUAL TABLE IF NOT EXISTS notes_fts USING fts5(title, body, tags)")
            self.fts = True
        except sqlite3.OperationalError:
            self.fts = False
        self.db.commit()

    def add(self, title: str, body: str = "", kind: str = "note", tags: str | list = "", ref: str = "") -> int:
        if kind not in KINDS:
            raise ValueError(f"kind must be one of {', '.join(KINDS)}")
        title = title.strip()
        if not title:
            raise ValueError("title required")
        if isinstance(tags, (list, tuple)):
            tags = " ".join(str(tag).strip() for tag in tags if str(tag).strip())
        cursor = self.db.execute("INSERT INTO notes(ts, kind, title, body, tags, ref) VALUES(?,?,?,?,?,?)",
                                 (time.time(), kind, title, body, tags, ref))
        if self.fts:
            self.db.execute("INSERT INTO notes_fts(rowid, title, body, tags) VALUES(?,?,?,?)",
                            (cursor.lastrowid, title, body, tags))
        self.db.commit()
        return int(cursor.lastrowid)

    def search(self, query: str, limit: int = 20) -> list[dict]:
        terms = [term for term in re.split(r"\s+", query.strip()) if term]
        if not terms:
            return self.recent(limit)
        if self.fts:
            match = " ".join(f'"{term}"*' for term in terms)
            rows = self.db.execute(
                """SELECT n.id, n.ts, n.kind, n.title, n.tags, n.ref FROM notes_fts f
                   JOIN notes n ON n.id = f.rowid WHERE notes_fts MATCH ?
                   ORDER BY bm25(notes_fts) LIMIT ?""", (match, limit)).fetchall()
        else:
            clause = " AND ".join("(title LIKE ? OR body LIKE ? OR tags LIKE ?)" for _ in terms)
            flat = [f"%{term}%" for term in terms for _ in range(3)]
            rows = self.db.execute(
                f"SELECT id, ts, kind, title, tags, ref FROM notes WHERE {clause} ORDER BY ts DESC LIMIT ?",
                (*flat, limit)).fetchall()
        return [self._row(row) for row in rows]

    def recent(self, limit: int = 20, kind: str | None = None) -> list[dict]:
        if kind:
            rows = self.db.execute(
                "SELECT id, ts, kind, title, tags, ref FROM notes WHERE kind=? ORDER BY ts DESC LIMIT ?",
                (kind, limit)).fetchall()
        else:
            rows = self.db.execute(
                "SELECT id, ts, kind, title, tags, ref FROM notes ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
        return [self._row(row) for row in rows]

    def get(self, note_id: int) -> dict | None:
        row = self.db.execute("SELECT id, ts, kind, title, body, tags, ref FROM notes WHERE id=?",
                              (note_id,)).fetchone()
        if not row:
            return None
        return {"id": row[0], "ts": row[1], "kind": row[2], "title": row[3],
                "body": row[4], "tags": row[5], "ref": row[6]}

    def delete(self, note_id: int) -> bool:
        cursor = self.db.execute("DELETE FROM notes WHERE id=?", (note_id,))
        if self.fts:
            self.db.execute("DELETE FROM notes_fts WHERE rowid=?", (note_id,))
        self.db.commit()
        return cursor.rowcount > 0

    def prune(self, older_than_days: int = 30, kinds: tuple = ("note",)) -> int:
        cutoff = time.time() - older_than_days * 86400
        placeholders = ",".join("?" for _ in kinds)
        ids = [row[0] for row in self.db.execute(
            f"SELECT id FROM notes WHERE ts < ? AND kind IN ({placeholders})", (cutoff, *kinds))]
        for note_id in ids:
            self.delete(note_id)
        return len(ids)

    def stats(self) -> dict:
        rows = self.db.execute("SELECT kind, COUNT(*) FROM notes GROUP BY kind").fetchall()
        return {kind: count for kind, count in rows}

    @staticmethod
    def _row(row) -> dict:
        return {"id": row[0], "ts": row[1], "kind": row[2], "title": row[3], "tags": row[4], "ref": row[5]}
