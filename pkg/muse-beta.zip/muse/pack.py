"""Deterministic archive of the workspace.

Sorted paths, fixed timestamps, fixed compression: two packs of the same tree are byte-identical.
"""

from __future__ import annotations

import hashlib
import os
import stat
import zipfile

EXCLUDE_DIRS = {".git", ".venv", "state", "dist", "__pycache__", ".ruff_cache", ".pytest_cache", "node_modules"}
EXCLUDE_SUFFIX = (".pyc", ".pyo", ".DS_Store", ".zip")
EXCLUDE_NAMES = {"MANIFEST.sha256.txt"}  # generated per archive


def collect(root: str) -> list[str]:
    out = []
    for base, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDE_DIRS)
        for name in sorted(names):
            if name.endswith(EXCLUDE_SUFFIX) or name in EXCLUDE_NAMES:
                continue
            full = os.path.join(base, name)
            out.append(os.path.relpath(full, root))
    return sorted(out)


def build(root: str, out_path: str, version: str = "0.0.0") -> dict:
    root = os.path.abspath(root)
    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    files = collect(root)
    with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for rel in files:
            info = zipfile.ZipInfo(rel, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = (stat.S_IMODE(os.stat(os.path.join(root, rel)).st_mode) | 0o644) << 16
            with open(os.path.join(root, rel), "rb") as handle:
                archive.writestr(info, handle.read())
        lines = []
        for rel in files:
            digest = hashlib.sha256(open(os.path.join(root, rel), "rb").read()).hexdigest()
            lines.append(f"{digest}  {rel}")
        info = zipfile.ZipInfo("MANIFEST.sha256.txt", date_time=(2026, 1, 1, 0, 0, 0))
        archive.writestr(info, "\n".join(lines) + "\n")
    digest = hashlib.sha256(open(out_path, "rb").read()).hexdigest()
    with open(out_path + ".sha256", "w", encoding="utf-8") as handle:
        handle.write(f"{digest}  {os.path.basename(out_path)}\n")
    return {"path": out_path, "files": len(files), "bytes": os.path.getsize(out_path), "sha256": digest,
            "version": version}
