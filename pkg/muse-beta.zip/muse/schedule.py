"""Five-field cron parsing.

Supports `*`, `*/step`, `a-b`, `a-b/step` and comma lists, plus the three-letter month and
weekday names. No daemon: :func:`due` is polled by the worker.
"""

from __future__ import annotations

import json
import os
import time
from collections.abc import Iterable
from datetime import datetime, timedelta, timezone

MONTHS = {name: i for i, name in enumerate(
    "jan feb mar apr may jun jul aug sep oct nov dec".split(), start=1)}
DAYS = {name: i for i, name in enumerate("sun mon tue wed thu fri sat".split())}
FIELDS = (("minute", 0, 59), ("hour", 0, 23), ("day", 1, 31), ("month", 1, 12), ("weekday", 0, 6))


class CronError(ValueError):
    pass


def _value(token: str, names: dict, low: int, high: int) -> int:
    text = token.lower()
    if text in names:
        return names[text]
    try:
        value = int(text)
    except ValueError:
        raise CronError(f"bad field value {token!r}") from None
    if not low <= value <= high:
        raise CronError(f"{value} outside {low}-{high}")
    return value


def _parse_field(expr: str, low: int, high: int, names: dict) -> set[int]:
    values: set[int] = set()
    for chunk in expr.split(","):
        step = 1
        if "/" in chunk:
            chunk, _, raw_step = chunk.partition("/")
            if not raw_step.isdigit() or int(raw_step) == 0:
                raise CronError(f"bad step in {chunk!r}")
            step = int(raw_step)
        if chunk == "*":
            start, end = low, high
        elif "-" in chunk:
            left, _, right = chunk.partition("-")
            start, end = _value(left, names, low, high), _value(right, names, low, high)
            if start > end:
                raise CronError(f"reversed range {chunk!r}")
        else:
            start = end = _value(chunk, names, low, high)
        values.update(range(start, end + 1, step))
    return values


class Cron:
    def __init__(self, expression: str):
        parts = expression.split()
        if len(parts) != 5:
            raise CronError("expected 5 fields: minute hour day month weekday")
        self.expression = " ".join(parts)
        self.minute = _parse_field(parts[0], 0, 59, {})
        self.hour = _parse_field(parts[1], 0, 23, {})
        self.day = _parse_field(parts[2], 1, 31, {})
        self.month = _parse_field(parts[3], 1, 12, MONTHS)
        self.weekday = _parse_field(parts[4], 0, 6, DAYS)

    def matches(self, moment: datetime) -> bool:
        if moment.minute not in self.minute or moment.hour not in self.hour:
            return False
        if moment.month not in self.month:
            return False
        # cron semantics: day-of-month OR day-of-week when both are restricted
        day_ok = moment.day in self.day
        week_ok = (moment.isoweekday() % 7) in self.weekday
        if self.day != set(range(1, 32)) and self.weekday != set(range(7)):
            return day_ok or week_ok
        return day_ok and week_ok

    def next_after(self, moment: datetime, limit_days: int = 400) -> datetime:
        cursor = (moment + timedelta(minutes=1)).replace(second=0, microsecond=0)
        for _ in range(limit_days * 1440):
            if self.matches(cursor):
                return cursor
            cursor += timedelta(minutes=1)
        raise CronError("no occurrence within horizon")


def next_runs(expression: str, count: int = 3, start: datetime | None = None) -> list[str]:
    cron = Cron(expression)
    cursor = start or datetime.now(timezone.utc)
    out = []
    for _ in range(count):
        cursor = cron.next_after(cursor)
        out.append(cursor.isoformat())
    return out


def due(schedules: Iterable[dict], now: float | None = None) -> list[dict]:
    """Return schedules whose cron matched within the last minute."""
    moment = datetime.fromtimestamp(now or time.time(), timezone.utc)
    return [item for item in schedules if Cron(item["expression"]).matches(moment)]


class Store:
    """Cron entries that enqueue jobs. `tick` is idempotent within a minute."""

    def __init__(self, path: str = "state/schedules.db"):
        import sqlite3
        self.path = path
        os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
        self.db = sqlite3.connect(path)
        self.db.execute("""CREATE TABLE IF NOT EXISTS schedules(
            id INTEGER PRIMARY KEY, expression TEXT, kind TEXT, payload TEXT,
            enabled INTEGER DEFAULT 1, last_run REAL DEFAULT 0)""")
        self.db.commit()

    def add(self, expression: str, kind: str, payload: dict | None = None) -> int:
        Cron(expression)
        cursor = self.db.execute("INSERT INTO schedules(expression, kind, payload) VALUES(?,?,?)",
                                 (expression, kind, json.dumps(payload or {})))
        self.db.commit()
        return int(cursor.lastrowid)

    def list(self) -> list[dict]:
        rows = self.db.execute("SELECT id, expression, kind, payload, enabled, last_run FROM schedules").fetchall()
        return [{"id": r[0], "expression": r[1], "kind": r[2], "payload": json.loads(r[3]),
                 "enabled": bool(r[4]), "last_run": r[5]} for r in rows]

    def remove(self, schedule_id: int) -> bool:
        cursor = self.db.execute("DELETE FROM schedules WHERE id=?", (schedule_id,))
        self.db.commit()
        return cursor.rowcount > 0

    def tick(self, now: float | None = None) -> list[dict]:
        moment = datetime.fromtimestamp(now or time.time(), timezone.utc)
        minute_start = moment.replace(second=0, microsecond=0).timestamp()
        out = []
        for item in self.list():
            if not item["enabled"] or item["last_run"] >= minute_start:
                continue
            if Cron(item["expression"]).matches(moment):
                out.append(item)
                self.db.execute("UPDATE schedules SET last_run=? WHERE id=?", (minute_start, item["id"]))
        self.db.commit()
        return out

    def close(self) -> None:
        self.db.close()
