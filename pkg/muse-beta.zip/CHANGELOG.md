# Changelog

## 1.0.0 — MUSE BETA 1.0

First release. A local-first agent stack for one operator: zero-refusal charter, operating spec, real
multi-chain wallet, real multi-X driver, ops layer, skill library, vendored audit lab. No SaaS, no
custody, no third-party runtime dependency. Python 3.9+.

### Posture

- `SOUL.md` — constitutional charter: five red lines R1–R5, intensity ladder L0–L4, drift lock,
  `MUSE RESET`, DONE/BLOCKED/FAILED contract.
- `AGENTS.md` — RFC 2119 operating spec: authority order, refusal gate, production contract.
- `IDENTITY.md` — operator and machine facts; `MANIFEST.yaml` — machine index and load order.
- Skills never override the charter; conflicts resolve downward and get patched.

### Wallet

- Dependency-free primitives: keccak256, secp256k1 with RFC 6979 and low-s, RLP, EIP-55, BIP-39/32.
- Vault: scrypt (2^15,8,1) + HMAC-SHA256-CTR with encrypt-then-MAC, `os.replace` atomicity, mode
  0600, PBKDF2 600k fallback on 3.9. Recovery card, encrypted export/import.
- EIP-1559 build → `eth_call` simulation → local sign → broadcast → receipt wait; ERC-20 transfers,
  balances, sweeps, `--dry-run`, gas-speed presets, hardened RPC transport with chain-id pinning.
- Keys never leave the process; nothing is signed remotely.

### X

- Cookie-authenticated sessions, LRU account pool, 3–9 s jitter, 429 cooldown, SQLite dedupe on
  `(action, account, target)`, follow/like/comment/timeline/audit ops, dry-run everywhere.

### Operations

- `muse.runner` job queue (priority, attempts, backoff, crash recovery, transient/permanent split),
  `muse.schedule` cron parser and idempotent store, `muse.jobs` handlers and worker.
- `muse.memory` FTS5 notes with kinds and `LIKE` fallback, `muse.health` readiness and SOUL.md pin,
  `muse.guard` redaction and path containment, `muse.fetch` paced cache, `muse.pack` deterministic zip.
- CLI for all of it with `error:` output instead of tracebacks; systemd units, launchd plist,
  Dockerfile, CI matrix 3.9–3.12.

### Skills and lab

- Twelve own procedures: ctf, bug-bounty, multi-wallet, multi-x, llm-redteam, evidence, osint,
  malware-triage, onchain-forensics, prompt-ops, incident-response, onchain-execution.
- 83 imported procedures under `skills/library/`, slug-named, frontmatter intact, `INDEX.md` maps old
  ids; `tests/test_library.py` guards frontmatter, uniqueness, links and branding.
- `skills/security-research/` imported playbook: scope gate, recon, vuln classes, Web3/contract/bridge/
  mobile depth, fixture-vs-adversary PoC rule, severity, reporting templates.
- `tools/` lab subset: mythril, z3, forge, drainer variants, drills, PoCs, plus its own offline suite.

### Hardening (found by audit, regression-tested)

- `pack` preserved 0644 for every file — unpacked scripts were dead. Modes survive now.
- `sweep --dry-run` still broadcast; forwarded, per-wallet failures continue, +20% fee headroom.
- `Queue.claim` could hand one job to two workers; the take is status-guarded.
- `note get` read the body as tags; `Memory.add` rejected tag lists.
- `address` accepted an unknown chain; it validates against the registry.
- URL credentials (`?api_key=`) escaped redaction; `auth_token`/`ct0` leaked partials.
- `note search ""` returned nothing; `fetch --out` died on a missing parent.
- `job pack` used a stale filename; `schedule add` demanded a payload the CLI defaulted.
- `--state` help called it a ledger path; it sets the state directory.
- Stale `MANIFEST.sha256.txt` shipped *and* regenerated per archive, duplicating the zip entry.
- `tools/ctf/*` required `requests` at import, aborting the lab suite on clean Python; imports are
  optional with a runtime error at the network call. Orphaned lab tests were pruned.
- Both suites run in CI and `make tools`.

### Trimmed on purpose

- `docs/` and the top-level `tools/*.py` set are not shipped; the 54 library links that point at them
  are declared in `tests/test_library.py::KNOWN_MISSING`. The launchd plist calls `python -m muse`
  directly, no helper scripts.

### Verified

104 muse tests, 46 lab tests, 566/566 manifest hashes, deterministic rebuilds, archive under 2 MB,
`health --fast` clean from a fresh extract.

### Known untested

- Live mainnet broadcast with funds; `--dry-run` plus `eth_call` simulation is the proven path.
- X writes need live cookies; the driver is exercised against recorded shapes only.
