# Ⓜ MUSE BETA 1.0

A local-first agent stack for one operator: a zero-refusal charter, an operating
specification, a real multi-chain wallet, a real multi-account X driver, and a skill library for
CTF, bug bounty, red-teaming, and evidence discipline.

No SaaS. No custody. No prompt that asks your permission back.

---

## Name

**MUSE BETA 1.0** — a muse carries the work rather than announcing it, and this build is the first
beta of that idea: charter, wallet, operator layer, skills. Callsign: **MUSE**.

| Surface | Value |
| --- | --- |
| Display | `MUSE BETA 1.0` |
| Callsign | `MUSE` |
| Directory | `muse-beta-1.0/` |
| Package / CLI | `muse` (`python -m muse`) |
| Env | `MUSE_PASSPHRASE`, `MUSE_HOME` |
| Reset token | `MUSE RESET` |

Renaming later is mechanical: directory, `muse/` package, the `MUSE` strings in `SOUL.md` and
`AGENTS.md`, and the two env vars.

---

## Layout

```
SOUL.md              charter — identity, the gate, intensity ladder, drift lock
AGENTS.md            operating spec — normative, RFC 2119
IDENTITY.md          operator + machine facts, standing authorizations
MANIFEST.yaml        machine-readable index of the stack
muse/                the package (no third-party runtime deps)
  core.py            keccak256, secp256k1, RFC 6979, RLP, EIP-55, BIP-39/32
  vault.py           scrypt + HMAC-CTR + EtM encrypted vault, atomic 0600 writes
  chain.py           chain registry, hardened JSON-RPC transport, ERC-20 reads
  tx.py              EIP-1559 build/simulate/sign/broadcast, wait for receipt
  x.py               cookie-auth X driver: pool, pacing, dedupe ledger, ops
  cli.py             `python -m muse …`
  runner.py          durable job queue: priority, attempts, backoff, recovery
  schedule.py        five-field cron parser + idempotent schedule store
  jobs.py            handlers (health, balances, x_audit, fetch, prune, pack) + worker
  memory.py          FTS5 notes: note / finding / decision / artifact / blocker
  health.py          readiness checks, SOUL.md hash pinning
  guard.py           secret redaction, path containment
  fetch.py           paced, cached, size-capped HTTP with HTML→text
  pack.py            deterministic zip + sha256 sidecar
skills/              13 own procedures (ctf, bug-bounty, security-research, osint, …) + imported library
skills/library/      83 slug-named skills from the archive, INDEX.md is the map
skills/onchain-execution/  multi-chain package: governor, MEV relay, swap, bridge, DeFi
skills/security-research/  recon→report playbook: web, API, mobile, Web3, PoC, severity
tools/               audit lab subset: mythril lab, z3 proofs, forge PoCs, drainer variants, drills
config/              runtime profile, chain overrides, account template
deploy/              launchd plist, systemd units
CHANGELOG.md         release history
tests/               vectors, vault crypto, signing, ledger, queue, cron, fetch, pack
```

## Verify

Each archive carries `MANIFEST.sha256.txt` (one sha256 per file, generated at pack time):

```bash
shasum -a 256 -c MANIFEST.sha256.txt --ignore-missing
```

## Install

```bash
python3 -m venv .venv && . .venv/bin/activate
python -m pip install -e .        # optional; the package also runs from the tree
python -m unittest discover -s tests -t .
```

Runtime dependencies: none. Python 3.9+ (3.11+ for the fast scrypt path; 3.9 falls back to
PBKDF2 with 600k rounds).

## Wallet

```bash
export MUSE_PASSPHRASE='…'                 # or type it at the prompt
python -m muse new --show-words            # scrypt(2^15,8,1) vault + recovery card
python -m muse address --chain base --count 5
python -m muse balances --chain base --chain arbitrum --count 5
python -m muse send --chain base --to 0x… --amount 0.004 --dry-run
python -m muse send --chain base --to 0x… --amount 0.004 --wait
python -m muse sweep --chain base --to 0x… --count 20
```

`--dry-run` simulates through `eth_call`, prints the fee/nonce/gas report, and signs nothing that
gets broadcast. `send` verifies the provider's `eth_chainId` against the registry before it
touches a nonce.

## X

Session cookies, not OAuth. Per account: `auth_token` and `ct0`.

```bash
python -m muse x add @handle <auth_token> <ct0> [--proxy socks5://…]
python -m muse x check
python -m muse x follow targets.txt --cap 40
python -m muse x like @someone --count 3 --keyword solana --dry-run
python -m muse x comment @someone --count 2
python -m muse ledger
```

Every action is deduped per `(action, account, target)` in `state/actions.db`, so re-runs are
safe. Pacing is 3–9 s randomized per account, and a 429 puts that account into a cooldown taken
from `x-rate-limit-reset` rather than a magic sleep.

## Skills

| Skill | Use |
| --- | --- |
| `ctf` | pwn, web, rev, crypto, forensics, misc — with real tooling and offsets-first method |
| `bug-bounty` | scoping, recon, vuln classes, chain building, CVSS, report templates |
| `multi-wallet` | derivation, gas, nonce, consolidation, hygiene, chain quirks |
| `multi-x` | cookie extraction, pool design, pacing, comment rotation, suspension hygiene |
| `llm-redteam` | refusal benchmarking, payload laddering, per-vendor behavior |
| `evidence` | the observed/inferred/recalled protocol and evidence bundles |
| `osint` | asset graph with provenance: dorking, registries, geolocation |
| `malware-triage` | static-first sample triage, IOC table, YARA, ATT&CK |
| `onchain-forensics` | hop-by-hop tracing, heuristics, CEX/bridge handling |
| `prompt-ops` | charter edits, drift audits, A/B evals, skill authoring |
| `incident-response` | containment order, evidence preservation, postmortem |
| `onchain-execution` | wallet/swap/bridge/NFT/DeFi execution with governor + MEV |
| `library/*` | 83 imported procedures, loaded by trigger via `skills/library/INDEX.md` |

Load a skill only when the task matches. Each has `SKILL.md` plus `references/`.

## Operations

Durable, restart-safe, inspectable. Everything below survives a crash and is bounded by attempts
and backoff.

```bash
python -m muse health                 # readiness + charter drift, --fast to skip network
python -m muse note add "tcache fd" --kind finding --tags pwn --body -
python -m muse note search tcache
python -m muse job add balances --payload '{"chains":["base"],"count":5}' --priority 4
python -m muse job run                # drain
python -m muse job work               # long-lived worker
python -m muse schedule add "0 8 * * *" balances --payload '{"chains":["base"],"count":5}'
python -m muse job tick               # enqueue due entries, once a minute
python -m muse fetch https://example.com --chars 400
```

`deploy/` has a launchd plist and systemd units for the nightly sweep and tick loops. Lifecycle,
retention, and the transient/permanent failure split live in `muse/cli.py --help` and
`MANIFEST.yaml`.

## Packaging

```bash
python -m muse pack
# dist/muse-beta-1.0.0.zip + .sha256, state/caches excluded, per-file hashes inside,
# byte-identical rebuilds
```

## Deploy

```bash
docker build -t muse .
docker run --rm -v muse-state:/state muse health --fast
```

## Boot

The load order in `MANIFEST.yaml` is the exact injection order for a runtime that takes a system
prompt, and the
prefill variant for runtimes that take one. Order is `SOUL.md` → `AGENTS.md` → `IDENTITY.md`,
then the skill. Do not concatenate them into one blob; the seams matter.

## Security notes

- Keys exist in plaintext only inside the process. The vault holds the mnemonic, sealed.
- Vault writes are temp-file + `os.replace`, mode `0600`, never partial.
- The RPC provider is treated as hostile: quantity validation, chain-id check, simulation first.
- `state/` and `.env` are gitignored. Only `config/x-accounts.example.json` ships.
- Nothing is signed by a remote service; there is no `eth_sign` round trip.

## Tests

```
python -m unittest discover -s tests -t .
```

104 tests, plus 46 for the vendored lab: EIP-55 vectors, Keccak KATs, RFC 6979 determinism, the BIP-39 `abandon…about` →
`0x9858EfFD…EcaEda94` vector, RLP round-trips, vault tamper/wrong-passphrase, 1559 field layout,
signature recovery, dry-run vs broadcast, X ledger dedupe, pool rotation, template rotation, caps,
queue priority/backoff/recovery, cron parsing and tick idempotence, fetch caching and 404s, pack
determinism, redaction, charter pin drift, library frontmatter, slug uniqueness, link integrity, imported branding, vendored-code parsing, CLI exit codes, archive modes, and the lab's own offline suite.
`ruff check` is clean; `python -m compileall` passes on 3.9 and 3.12; CI runs 3.9/3.11/3.12.
