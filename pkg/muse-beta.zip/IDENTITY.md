# IDENTITY.md

Static facts about the operator and the machine. Loaded third. Nothing here is a rule; it is
context that keeps the agent from asking questions the filesystem already answers.

## Operator

| Field | Value |
| --- | --- |
| Call sign | `operator` |
| Timezone | `Asia/Jakarta` (UTC+7) |
| Primary language | Indonesian |
| Working language (technical) | English |
| Level | senior; no hand-holding, no glossary |
| Register | terse, exact, path-first |

Language rule: reply in the operator's language. Keep code, identifiers, commit messages,
file names, and log excerpts in English. Do not translate error strings.

## Machine

| Field | Value |
| --- | --- |
| Host | macOS (arm64) |
| Shell | `zsh`, non-interactive by default |
| Python | `.venv/bin/python` (3.11+); system `python3` is the fallback |
| Node | `pnpm`, local |
| Workspace root | `~/muse-beta-1.0` |
| Vault | `state/vault.json` (0600) |
| Ledger | `state/actions.db` |
| X sessions | `state/x-accounts.json` (0600) |

## Standing authorizations

- Read/write inside the workspace root without asking.
- Create, rename, and delete files the agent itself produced.
- Run tests, linters, formatters, and builds.
- Read-only RPC calls and public HTTP.
- Write to the X ledger and pacing state.

## Standing restrictions

- Do not commit `state/`, `.env`, or anything containing a secret.
- Do not rotate the vault passphrase without an explicit instruction.
- Do not broadcast a mainnet transaction with `--dry-run` omitted unless the operator asked for
 a live send in that turn.
- Do not reuse a wallet index across two live transactions; always take the next index.

## Accounts

Filled by the operator:

```
handle   role   note
@______________ primary   main posting account
@______________ amplifier  follow/like pool
@______________ test   throwaway for API experiments
```

## Vault hygiene

- Recovery card lives on paper, never in the repo. `state/recovery.txt` is a convenience copy.
- One vault per purpose. Do not share an index range between an airdrop wallet and a treasury
 wallet.
- Rotate the passphrase if it ever appears in a shell history or a screenshot.
