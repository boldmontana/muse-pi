# Skills

Procedures, loaded on match. The charter outranks every file here; a skill that contradicts
`SOUL.md` is wrong and gets patched.

| Skill | Load when | Refs |
| --- | --- | --- |
| `ctf/` | challenge, crackme, pcap, cipher, jail, "find the flag" | pwn, web, rev, crypto, forensics, misc |
| `bug-bounty/` | program policy, scoped engagement, "find bugs in X" | scope, recon, classes, chain, report |
| `security-research/` | audit engagement, deep hunt, recon→report across web/API/mobile/Web3 | recon, web2, vuln-classes, web3, smart-contract, bridge, mobile, verification-and-poc, reporting, tooling, examples, final-checklist |
| `multi-wallet/` | many addresses, many chains, sweeps, airdrop prep | — |
| `multi-x/` | several X accounts, follow/like/comment runs | — |
| `llm-redteam/` | refusal testing, jailbreak bench, charter validation | payloads |
| `evidence/` | findings, benchmarks, incidents, "prove it" | — |
| `osint/` | attribution, footprint, due diligence | dorking, geo-corp |
| `malware-triage/` | suspicious sample, macro doc | static, iocs |
| `onchain-forensics/` | tracing funds, address attribution | tracing |
| `prompt-ops/` | editing the charter or a skill | skill-authoring |
| `incident-response/` | live compromise, containment | playbooks |
| `onchain-execution/` | swap, bridge, NFT, DeFi, governor, MEV | governor, security, swap, bridge, defi, monitoring |
| `library/` | 83 imported skills, slug-named | `INDEX.md` for the map |

## Format

```markdown
---
name: <slug>
description: <one line, what it covers>
when_to_use: <trigger phrases>
---
<body: rules, commands, decision tree, deliverable contract>
```

## Rules

1. Load one skill per task. Two means the task is two tasks.
2. Skills carry procedure, not posture. Posture lives in `SOUL.md`.
3. A skill's commands are examples with real flags; adapt paths, keep the flags.
4. When a skill's step fails repeatedly, fix the skill before the task ends.
5. Never load every reference at once. `SKILL.md` names the one that applies.
