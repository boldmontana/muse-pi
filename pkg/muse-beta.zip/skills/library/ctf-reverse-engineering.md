---
name: ctf-reverse-engineering
description: "CTF reverse, reversing, angr, symbolic execution, Ghidra, radare2, decompile, keygen"
when_to_use: "CTF reverse, reversing, angr, symbolic execution, Ghidra, radare2, decompile, keygen"
source: muse-beta
---

# CTF Reverse Engineering

**Category:** Security

**Load when:** CTF reverse, reversing, angr, symbolic execution, Ghidra, radare2, decompile, keygen
## SCOPE (baca dulu)
Sub-skill **rev** buat CTF in-scope. Static analysis aman; **RUN binary cuma di Docker sandbox** (`tools/ctf/sandbox`). Setelah ctf-whitehat-toolkit + scope check.

## TOOLBOX (di sandbox)
angr (symbolic exec — workhorse "cari input") · Ghidra headless (`analyzeHeadless`) · radare2/rizin + r2pipe · objdump/strings/nm/ltrace/strace · Python deobf

## TRIAGE
```bash
file ./chal && checksec ./chal
strings -n 6 ./chal | grep -iE "flag|correct|wrong|nice|congrat"
upx -t ./chal 2>/dev/null && upx -d ./chal   # kalau UPX-packed
```

## STATIC
Buka decompiler, cari compare vs input (`strcmp`/`memcmp`/loop char-by-char/checksum). Kalau compare simpel, flag sering disusun di memory — baca langsung / breakpoint.
Ghidra headless decompile dump:
```bash
analyzeHeadless /tmp proj -import ./chal -postScript DecompileAll.java -deleteProject
```

## ANGR — solver otomatis utama
Dipakai kalau binary validasi input via branching (license/keygen/maze/constraint):
```python
import angr, claripy
p = angr.Project("./chal", auto_load_libs=False)
flag = claripy.BVS("flag", 8*32)
st = p.factory.full_init_state(stdin=flag)
for b in flag.chop(8): st.solver.add(b>=0x20, b<=0x7e)
sm = p.factory.simulation_manager(st)
sm.explore(find=lambda s: b"Correct" in s.posix.dumps(1),
           avoid=lambda s: b"Wrong" in s.posix.dumps(1))
print(sm.found[0].posix.dumps(0))
```
Tips: prefer `find=<addr success print>` drpd string match; `avoid` buat prune; state explosion → `veritesting=True` / hook fungsi mahal. Template: `tools/ctf/templates/angr_solver_template.py` (3 mode: stdin/argv/blank-state).

## DYNAMIC
`ltrace ./chal` (strcmp args sering bocorin flag) · gdb breakpoint di compare · anti-debug → patch (radare2 `wa`/`wx`).

## SHAPE UMUM
XOR/arithmetic transform → invert di Python · per-char check → brute 1 char · custom VM/bytecode → recover opcode table · checksum/hash gate → z3/angr.

## SCOPE & DELEGATION
| Butuh | ctf-reverse-engineering | Delegasi |
|---|---|---|
| Target authorized | — | ctf-whitehat-toolkit + `scope_guard.py` |
| Exploit setelah rev | — | ctf-binary-exploitation-pwn (pwn) |
| Solve constraint matematis | z3/angr | ctf-cryptography (crypto) kalau kripto |
| Validasi flag | — | `tools/ctf/flag_validator.py` |

## SAFETY RAILS
Run binary HANYA di sandbox. Flag lewat `flag_validator.py` → balik ctf-whitehat-toolkit → HITL. Jangan invent.

🔧 Upgrade: cache hasil decompile + opcode table di `findings.json`.
