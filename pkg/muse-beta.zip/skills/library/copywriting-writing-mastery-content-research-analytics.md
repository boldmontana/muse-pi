---
name: copywriting-writing-mastery-content-research-analytics
description: "Copywriting, Writing Mastery & Content Research/Analytics"
when_to_use: "Copywriting, Writing Mastery & Content Research/Analytics"
source: muse-beta
---

# Copywriting, Writing Mastery & Content Research/Analytics
# MERGED: copywriting-writing-mastery-content-research-analytics (copywriting) + copywriting-writing-mastery-content-research-analytics-merged (content research/analytics/pipeline) — July 2026

---

Frameworks copywriting yang teruji, SEO writing, storytelling, lokalisasi multibahasa. **PLUS** sisi data: riset tren/kompetitor, insight audiens, social listening, analitik performa, A/B variant, best-time-to-post, engagement handler, dan **full content pipeline** (research → draft → visual → schedule → analyze). **Opsional.** Inti penulisan + orkestrasi data konten — pasangkan content-creation-strategy-signal-amplification (creation+strategy), m20 (humanize/brand voice), m18 (visual).

---

## PART A: COPYWRITING & WRITING (original copywriting-writing-mastery-content-research-analytics)

### Copywriting frameworks (pakai yang cocok, jangan asal)

| Framework | Struktur | Kapan |
|---|---|---|
| **AIDA** | Attention → Interest → Desire → Action | iklan, landing, sales post |
| **PAS** | Problem → Agitate → Solution | pain-driven, cold audience |
| **BAB** | Before → After → Bridge | transformasi, testimonial |
| **4P** | Promise → Picture → Proof → Push | email, long-form sales |
| **CHEF** | Clear · Honest · Engaging · Fitting | filter kualitas semua copy |
| **70-20-10** | 70% value · 20% share/promo curated · 10% jualan | rasio mix konten |

```
Contoh PAS (cold):
P: "Post lo udah bagus tapi gak ada yang beli."
A: "Tiap hari scroll lewat, effort lo kebuang, kompetitor yang menang."
S: "Masalahnya bukan konten — tapi hook & CTA. Ini cara benerinnya: ..."
```

Pilih framework dari tujuan & suhu audience (cold/warm/hot), bukan kebiasaan. Satu copy = satu framework dominan.

### SEO-optimized writer

```
1. KEYWORD   → primary + secondary + long-tail (intent: info/transaksional/navigasi)
2. STRUCTURE → keyword di title, C1, paragraf pertama, 1-2 subheading, natural di body
3. ON-PAGE   → meta description (≤155 char) + alt text + internal link + slug bersih
4. READABLE  → tetap buat manusia dulu; keyword-stuffing = penalti & jelek dibaca
```

Untuk caption/blog: keyword natural, jangan korbankan keterbacaan demi mesin. E-E-A-T: tunjukin pengalaman & bukti.

### Storytelling & narrative

```
HOOK → STAKES → STRUGGLE → SHIFT → TAKEAWAY
("ini terjadi" → "kenapa penting" → "yang susah" → "titik balik" → "pelajaran buat lo")
```

Cerita > daftar fakta: spesifik (angka/nama/momen), satu emosi dominan, personal touch (sudut pandang lo). Hindari generik — detail konkret yang bikin nyangkut. Akhiri dengan satu pelajaran yang bisa dipakai pembaca.

### Multilingual & localization (termasuk RTL)

Lokalisasi ≠ translate. Adaptasi makna, idiom, referensi budaya, format (tanggal/mata uang/satuan):

```
- Idiom & humor → cari padanan budaya, jangan harfiah
- RTL (Arab/Ibrani/Farsi/Urdu) → arah teks, alignment, mirror UI, angka
- Tone per budaya → formal vs casual beda norma per bahasa/daerah
- CTA → sesuaikan ekspektasi lokal, bukan terjemahan literal
```

Indonesia: hormati gaya operator (USER.md) — `lo/gue` vs `kamu` vs daerah. Jaga istilah teknis tetap (jangan terjemahin "deploy", "swap").

### Idea → konten actionable

Idea kabur → konten lengkap: handoff **Grill-Me/To-PRD (m26)** buat pertajam, lalu tulis di sini dengan framework yang cocok. Internal-comms/LinkedIn thought-leadership → m26 (§internal-comms) + framework storytelling di atas.

---

## PART B: CONTENT RESEARCH, ANALYTICS & PIPELINE (from copywriting-writing-mastery-content-research-analytics-merged)

Sisi data & orkestrasi dari konten sosial: riset tren/kompetitor, insight audiens, social listening, analitik performa, A/B variant, best-time-to-post, engagement handler, dan **full content pipeline** (research → draft → visual → schedule → analyze). **Opsional.** Otak strategi di belakang content-creation-strategy-signal-amplification (creation+strategy).

> Jujur soal data: analitik & "best time" butuh **data nyata** dari platform/akun operator (API/export). Tanpa itu = heuristik & benchmark umum, ditandai sebagai estimasi — bukan angka palsu.

### Trend & competitor research

```
- Trending topic: cari di X/IG/LinkedIn/TikTok + Google Trends per niche & region
- Competitor teardown: format yang nempel, frekuensi, hook, gaya, gap yang bisa diisi
- Pain points: scrape komentar/forum/review → tema keluhan berulang = bahan konten
```

Sumber via web fetch operator / API. Untuk riset mendalam bersitasi → handoff m22. Output: daftar peluang konten ter-ranking by relevansi × momentum.

### Audience insight & social listening

```python
# analisis komentar/engagement → tema + sentimen (real data dari export/API operator)
from content import analyze_comments
insight = analyze_comments(comments)   # → {themes, sentiment, questions, objections, quotes}
```

Real-time listening: pantau keyword/brand/kompetitor di sosial → peluang (pertanyaan belum terjawab, tren naik, krisis). Sambung alert (m4/daily-assistant-briefing-alerts-2). Pertanyaan audiens = ide konten + objection buat di-address.

### Performance analyzer

```python
from content import analyze_performance
report = analyze_performance(posts)    # butuh metrik real: impressions, engagement, CTR, saves
# → top/bottom performer, pola (format/jam/hook yang menang), rekomendasi konkret
```

Tanpa data real → kasih kerangka apa yang harus diukur, jangan ngarang angka. Pola menang → reinforce; yang flat → drop. Kaitkan ke self-improving loop (self-audit-system-refinement-self-improvement-merged): pola kebukti → instinct konten.

### A/B testing & best-time

```python
from content import ab_variants, best_time
variants = ab_variants("caption asli", n=3, vary=["hook","cta","length"])  # 1 variabel/uji
slots = best_time(audience_tz="Asia/Jakarta", history=post_history)         # data > tebakan
```

A/B: ubah **satu** elemen per uji (hook ATAU CTA, jangan dua) — biar tau mana yang ngefek (prinsip sama agentic-eval-self-critique-2 eval). Best-time dari data audiens sendiri > benchmark generik; tandai kalau cuma benchmark.

### Engagement response handler

```
- Draft balasan komentar (match brand voice m20) — POSITIF cepat, KRITIK hati-hati
- Eskalasi: keluhan serius / legal / krisis → flag ke operator, JANGAN auto-reply
- Human-in-the-loop: draft dulu → approval → kirim (jangan auto-post balasan sensitif)
```

### Full content pipeline (orkestrasi)

```
RESEARCH (copywriting-writing-mastery-content-research-analytics §B) → DRAFT (copywriting-writing-mastery-content-research-analytics §A + content-creation-strategy-signal-amplification) → HUMANIZE (m20) → VISUAL (m18) →
SCHEDULE (m4/m17 cron) → PUBLISH (cross-platform, R9 gate) → ANALYZE (copywriting-writing-mastery-content-research-analytics §B) → loop balik
```

```python
from content import repurpose
pieces = repurpose(long_form_text, into=["x_thread","ig_carousel","reels_script","linkedin_post"])
# 1 long-form → banyak platform, tiap format di-adapt (bukan copy-paste)
```

- **Cross-platform publisher**: adapt (content-creation-strategy-signal-amplification §platform-adapter) lalu publish ke banyak platform via API (m6).
- **Human-in-the-loop**: generate draft → minta approval operator → refine. Default buat outward content.
- **Scheduled agent**: konten rutin via cron (m4/m17). Publish = aksi outward → R9 gate.
- **Self-improving loop**: performa (§B perf-analyzer) → pelajaran (self-audit-system-refinement-self-improvement-merged) → strategi konten makin tajam.
- **Multi-agent**: riset / tulis / desain bisa di-split jadi lane swarm (m17) — executor yang publish, bukan lane riset.

---

## Combo Chain

```
content-creation-strategy-signal-amplification (creation+strategy) → copywriting-writing-mastery-content-research-analytics (copy+research) → m20 (humanize) → m18 (visual) → m6/m4/m17 (schedule/publish) + m22 (deep research) + self-audit-system-refinement-self-improvement-merged/agentic-eval-self-critique-2 (improve/eval)
```

## Catatan

- Framework = kerangka, bukan borgol. Bagus = CHEF lolos (clear/honest/engaging/fitting).
- Selalu humanize (m20) + cek brand (m25) sebelum publish.
- Analitik butuh data real — tanpa itu, heuristik bertanda "estimasi".
- Publish & auto-reply = outward → human-in-the-loop / R9 gate. Jangan auto-reply hal sensitif.

**Load when:** Copywriting, Writing Mastery & Content Research/Analytics
