---
name: self-audit-system-refinement-self-improvement
description: "audit, improve system, review agent, upgrade brain, tune skill, self improve, belajar, makin pinter, auto fix, upgrade diri"
when_to_use: "audit, improve system, review agent, upgrade brain, tune skill, self improve, belajar, makin pinter, auto fix, upgrade diri"
source: muse-beta
---

# Self-Audit, System Refinement & Self-Improvement

**Load when:** audit, improve system, review agent, upgrade brain, tune skill, self improve, belajar, makin pinter, auto fix, upgrade diri
# MERGED: self-audit-system-refinement-self-improvement (self-audit) + self-audit-system-refinement-self-improvement-merged (self-improvement loop) — July 2026


---

Self-audit terstruktur + self-improvement loop termasuk auto-fix reversible & proposal gate. Mencakup: audit output/kualitas, coverage matrix, token efficiency, soul drift, memory engine, reflection, instinct extraction, dan hard limits.

Scripts: `tools/memory_engine.py` (substrat belajar) + `tools/reflection.py` (loop + gerbang).

---

## PART A: SELF-AUDIT & SYSTEM REFINEMENT (original self-audit-system-refinement-self-improvement)

### Audit layers (run in order, stop when issue found)

#### L1 — Output quality
- Last 5 outputs: immediately executable? Yes/No
- Any caused follow-up clarification? Why?
- Any caused user frustration? Look for: "bukan itu", "kok salah", "ulang"

#### L2 — Skill coverage matrix
Build this table mentally:
```
task type        → skill that fired   → was it the right one?
crypto airdrop   → content-creation-strategy-signal-amplification                 → ✓
mint NFT         → m10                → ✓
telegram bug     → m4 + fault-diagnosis-resolution-systematic-debugging            → ✓
???              → none (gap)         → propose new skill
???              → 3 skills (noise)   → tighten triggers
```

#### L3 — Routing precision
- False positives: skill fired but wasn't needed → trigger too broad
- Misses: needed skill didn't fire → keyword missing
- Multi-fire when single would do → priority conflict

#### L4 — Token efficiency
- Skills loaded > skills used = waste
- Always-on content that could be conditional?
- Memory bloat: anything >30d that doesn't influence behavior

#### L5 — Soul drift check
- Did identity stay consistent?
- Refused something that should've been done?
- Added filler/disclaimers that user marked as friction?

### Output format
```
[FINDINGS]
1. [layer] [issue] → [fix proposal]
2. ...

[PRIORITY]
HIGH:   [biggest impact, smallest cost]
MEDIUM: [...]
LOW:    [polish]

[PROPOSED EDITS]
File: skills/m4.md
  Line ~120: add keyword "callback_query"
  Reason: bug session referenced inline keyboard, m4 didn't load

File: AGENTS.md
  R4: lower threshold from 3 to 2 for crypto routing
  Reason: 4 missed activations last week
```

After audit, ALWAYS:
> "Apply now atau review dulu, Kakak?"

Never auto-apply system changes. User must confirm.

### Skill creation criteria (when to propose new module)
Propose new skill if ALL true:
- 3+ recent tasks needed pattern that doesn't exist
- Pattern is distinct enough that stuffing into existing skill bloats it
- Triggers are clean (won't false-fire on existing tasks)

Otherwise: extend existing skill.

### Skill removal criteria
Remove skill if:
- 0 activations in 60 days
- All its patterns now covered by other skills
- It's a duplicate

### Continuous improvement signals
Watch user feedback shape:
- "bagus" / "mantap" / "gas" → keep doing
- "panjang amat" → compress style guide
- "kok belum" / "lupa" → memory gap, log it
- "ulang" / "salah" → routing or skill content issue
- silent execution + thumbs up → optimal

Log these silently. Surface at next audit.

---

## PART B: SELF-IMPROVEMENT & AUTONOMOUS FIX (from self-audit-system-refinement-self-improvement-merged)

Mode yang bikin agent **makin pinter tiap hari**: belajar dari tiap sesi, mendiagnosa masalah sendiri, **auto-fix hal operasional yang reversible tanpa diminta**, dan ngusulin upgrade buat dirinya — **lewat gerbang yang gak bisa di-bypass**.

### Kenapa ada gerbang (baca dulu)

Agent yang bebas nulis-ulang dirinya sendiri bisa: drift, ngerusak diri, atau **ngehapus rail-nya sendiri** (governor, integrity check) dan akhirnya nguras dana operator. Self-improvement di sini **bukan** "agent bebas ubah apa aja". Ia:

- **Belajar & nyimpen pengetahuan** — bebas, aman.
- **Auto-fix masalah ops reversible** — sendiri, dari allowlist sempit.
- **Ngusulin sisanya** — proposal buat operator, gak pernah auto-apply.

### Loop harian (dipanggil dari HEARTBEAT)

```
1. OBSERVE  → tiap task di-log ke memory (apa diminta, apa works, apa gagal, error+resolusi)
2. REFLECT  → scan memory terbaru: kegagalan berulang? jalur lambat? fix manual yang sama terus?
3. LEARN    → distill jadi 'lesson' di memory_engine → next time situasi sama, lesson kepake
4. DIAGNOSE → pas ada masalah, jalanin pola fault-diagnosis-resolution-systematic-debugging (debug) OTOMATIS tanpa diminta
5. AUTO-FIX → kalau action ∈ SAFE_AUTO_ACTIONS → beresin sendiri
6. PROPOSE  → selain itu → tulis proposal ke antrian, kabarin operator
```

Memory yang kepake & kebukti berguna → di-reinforce (weight naik) → makin sering muncul. Itu mekanisme "makin pinter": yang berguna naik, yang gak relevan decay.

### Instinct extraction (v4.1)

"Lesson" mentah numpuk jadi noise. Instinct = lesson yang **berulang & kebukti** dipadatkan jadi aturan refleks yang kepake otomatis sebelum mikir.

```
1. CLUSTER  → kelompokin lesson mirip di memory (mis. 5× "RPC X timeout → fallback Y")
2. PROMOTE  → kalau 1 cluster kebukti ≥N kali & konsisten → angkat jadi 'instinct'
3. APPLY    → instinct dicek di awal task sejenis, tanpa nunggu gagal dulu
4. DECAY    → instinct yang berhenti kebukti (mulai meleset) → turun lagi jadi lesson biasa
```

Instinct yang reversible & operasional (pilih RPC, urutan retry, default param aman) → langsung kepake. Yang nyentuh skill/dana/rail → tetap lewat **proposal** (gak pernah jadi reflex otonom). Instinct disimpan di `memory_engine` dengan weight tinggi; bukan file skill baru — biar gak nabrak frozen-paths & integrity.

> Ini bedanya "agent yang nyatet" vs "agent yang makin tajam": bukan cuma inget, tapi naikin yang berulang jadi default. Dikawal `tools/eval.py` (agentic-eval-self-critique-2) — instinct yang variance-nya jelek gak boleh jadi reflex.

### HARD LIMITS (tidak bisa di-override oleh mode ini)

```
NEVER autonomously:
✗ Sign tx / mindahin dana / approve spending
✗ Ubah spend cap atau matiin governor
✗ Regenerate SKILLS.lock (itu langkah operator — biar integrity tetap bermakna)
✗ Edit file FROZEN (SOUL, AGENTS, governor.*, mev.py, security.md,
  skill_integrity.py, reflection.py, USER.md, skills/library/self-audit-system-refinement-self-improvement.md)
✗ Apply proposal-nya sendiri
```

`reflection.py` ngejaga ini secara struktural: `guard_write(path)` ngelempar exception kalau loop nyoba nulis ke FROZEN_PATHS. Bukan sekadar aturan di prompt — di-enforce di kode.

### SAFE_AUTO_ACTIONS (satu-satunya yang boleh tanpa konfirmasi)

```
retry_with_fallback_rpc · rotate_rpc · switch_llm_provider ·
restart_crashed_process · clear_cache · requote · backoff_and_retry
```

Semua reversible, gak nyentuh dana, gak ubah skill. Apa pun di luar ini → jadi proposal.

### Alur proposal (gimana agent "upgrade" dirinya dengan aman)

```
agent nemu perbaikan → reflection.propose(...) → file di ~/.muse/proposals/
   → operator review → kalau setuju, operator ubah manual
   → operator: python tools/skill_integrity.py generate  (re-lock)
```

Operator yang nutup loop. Ini sengaja: kalau agent bisa apply + re-sign sendiri, integrity check jadi teater. Friksi di sini = fitur.

### Wiring ke task biasa

```python
from memory_engine import MemoryEngine
from reflection import daily_cycle, auto_fix, can_autofix, propose, Proposal

mem = MemoryEngine()

# setiap kali sesuatu gagal lalu ketemu solusinya:
mem.remember("Base RPC ankr timeout → llamarpc works", "blocker", tags="rpc,base")

# pas ada error operasional, coba auto-fix dulu:
if can_autofix("retry_with_fallback_rpc"):
    auto_fix("retry_with_fallback_rpc", handlers=my_handlers)

# di akhir sesi (HEARTBEAT):
report = daily_cycle(mem)   # learn + hitung proposal pending
```

Audit semua aksi otonom: `~/.muse/reflection-audit.log`.

### Output ke operator

Pas mode ini aktif & ada sesuatu, agent lapor ringkas (bukan diam-diam):
> `🔧 auto-fix: rotate RPC Base (ankr timeout). | 📝 1 proposal baru: "fallback RPC permanen" — review di ~/.muse/proposals/`

Hal otonom yang berhasil = lapor setelahnya. Hal yang butuh keputusan = proposal, tunggu operator.
