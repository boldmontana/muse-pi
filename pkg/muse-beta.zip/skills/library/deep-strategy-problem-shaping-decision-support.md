---
name: deep-strategy-problem-shaping-decision-support
description: "complex multi-step, strategy, architecture, "help me think through", tradeoff, "should I", roadmap, problem shaping, brainstorming, sign-off, framing, vague goal, uncertainty"
when_to_use: "complex multi-step, strategy, architecture, "help me think through", tradeoff, "should I", roadmap, problem shaping, brainstorming, sign-off, framing, vague goal, uncertainty"
source: muse-beta
---

# Deep Strategy, Problem Shaping & Decision Support

**Load when:** complex multi-step, strategy, architecture, "help me think through", tradeoff, "should I", roadmap, problem shaping, brainstorming, sign-off, framing, vague goal, uncertainty
# MERGED: deep-strategy-problem-shaping-decision-support (deep decomposition/strategy) + deep-strategy-problem-shaping-decision-support-merged (problem shaping/decision support) — July 2026


---

Strategi dari hulu ke hilir: shaping (tujuan kabur → subtask presisi), decomposition (multi-path decision), dan decision support (ketidakpastian). deep-strategy-problem-shaping-decision-support handles the full thinking pipeline from vague idea to first concrete action.

---

## PART A: PROBLEM SHAPING — TUJUAN KABUR → SUBTASK PRESISI (from deep-strategy-problem-shaping-decision-support-merged)

Operator sering ngomong hasil ("bikin gue cuan dari Web3"), bukan task. Shaping = jembatannya:

```
1. RESTATE   → tulis ulang tujuan dengan kata sendiri, konfirm 1 kalimat
2. UNKNOWNS  → apa yang belum diketahui & MENGUBAH rencana? (budget, timeline, skill, risk appetite)
3. CONSTRAINTS → batas keras (modal, waktu, legal, chain, tooling yang dipunya)
4. DECOMPOSE → pecah jadi subtask yang masing-masing punya "selesai" yang jelas & teruji
5. SEQUENCE  → urutan + dependency + mana yang bisa paralel (handoff ke deep-strategy-problem-shaping-decision-support §B/m17 planner)
```

Aturan tanya: cuma tanya unknown yang **mengubah rencana**. Jangan interogasi. Maksimal 2-3 pertanyaan, sekali, lalu lanjut dengan asumsi yang ditandai (sejalan R8: jangan multi-question dump).

### Brainstorming + sign-off workflow

Untuk keputusan arah (arsitektur, strategi, produk) — sebar opsi dulu, jangan langsung satu jawaban:

```
1. DIVERGE  → 3-5 pendekatan beda angle (mis. MVP-first, risk-first, cost-first)
2. SCORE    → tiap opsi: effort, risiko, time-to-value, reversibility
3. RECOMMEND → tunjuk 1 + alasan singkat, sebut runner-up & kapan ia lebih baik
4. SIGN-OFF → "lock opsi B?" — TUNGGU operator sebelum eksekusi besar/ireversibel
5. EXECUTE  → setelah sign-off, gas tanpa nanya ulang (R9: sekali gate, lalu eksekusi)
```

Sign-off wajib HANYA untuk yang mahal/ireversibel (deploy prod, alokasi modal besar, rebrand). Task kecil/reversibel → langsung eksekusi, gak usah minta tanda tangan.

### Decision support dengan ketidakpastian

Saat data gak lengkap (sering, di crypto/ops), jangan pura-pura yakin atau lumpuh:

```
- Pisahkan: yang DIKETAHUI | DIASUMSIKAN | TIDAK DIKETAHUI
- Tandai confidence eksplisit: "tinggi/sedang/rendah" + apa yang akan ngubahnya
- Expected value kasar saat ada angka: upside × P(naik) vs downside × P(turun)
- One-way vs two-way door: ireversibel → hati-hati & cari info; reversibel → eksekusi cepat, belajar dari hasil
- Surfacing risk ≠ refusing. Sebut risiko + tetap kasih rekomendasi yang bisa dijalanin.
```

Output ketidakpastian yang jujur:
```
Rekomendasi: bridge via Across (confidence: sedang)
  diketahui: fee Across < Stargate sekarang, route aktif
  diasumsikan: likuiditas cukup utk 5 ETH (belum cek depth)
  cek dulu kalau mau pasti: quote real-time depth → 10 detik
  reversibel? ya (bisa pilih route lain) → aman eksekusi, gua quote dulu
```

### Context design

Sebelum kerja kompleks, bangun konteks yang tepat (bukan dump semua):
- Tarik yang relevan dari memory (self-audit-system-refinement-self-improvement-merged/self-audit-system-refinement-self-improvement) + USER.md, bukan seluruh riwayat.
- State asumsi & constraint di awal supaya operator bisa koreksi murah di depan, bukan setelah jadi.

> Catatan budaya: ini satu-satunya cluster yang sengaja **memperlambat** sebelum eksekusi. MUSE BETA AGENT default "execute first". deep-strategy-problem-shaping-decision-support cuma nyala saat tujuan ambigu atau taruhannya tinggi — bukan buat tiap task. Jangan over-shape task yang udah jelas.

---

## PART B: DEEP DECOMPOSITION & STRATEGIC SEQUENCING (original deep-strategy-problem-shaping-decision-support)

### When to load this
- Decision has >2 viable paths
- Mistake is expensive or hard to reverse
- User asks "what should I do" without a clear obvious answer
- Multi-day or multi-system project planning

NOT for: single-step tasks, well-defined builds, debug (use fault-diagnosis-resolution-systematic-debugging).

### Step 1 — Reframe
```
Stated:    [user's words]
Actual:    [what's really being asked]
Objective: [end state in 1 sentence]
Constraint: [time / money / skill / political]
Assumed:   [things treated as fact that might not be]
```

The reframe step alone often solves the problem. If stated ≠ actual, surface this BEFORE proposing solutions.

### Step 2 — Decompose
```
Sub-problems (independent):
  A. ...
  B. ...
  C. ...

Critical path: A → C → D (B is optional)
Dependencies: D needs A done first
```

### Step 3 — Options matrix
For each viable path:
```
PATH 1: [name]
  Upside:   [specific concrete win]
  Downside: [specific concrete loss]
  Risk:     low / medium / high
  Speed:    [hours/days/weeks]
  Cost:     [$ or token or time]
  Reversible? yes / no / partial
```

### Step 4 — Pre-mortem (NEW vs v2)
```
Assume in 30 days this failed. Why?
  Scenario A: [most likely failure mode]
  Scenario B: [second most likely]

Kill criteria: when do we abandon? (specific metric)
```

Pre-mortem catches the failure mode user is too excited to see.

### Step 5 — Recommend
```
Primary:  [path] — because [specific reason tied to objective]
Fallback: [path] — switch when [condition]
Avoid:    [path] — because [specific risk]
```

### Step 6 — First move
```
Next 24h action: [one specific thing, executable today]
```

Always end with a concrete action. Strategy without first move = procrastination.

### Reversibility framework
Two-way door (reversible cheaply) → just decide, move fast.
One-way door (expensive to reverse) → spend time on deep-strategy-problem-shaping-decision-support, get it right.

Examples:
- Pick framework for prototype = two-way → decide in 5 min
- Pick chain for token launch = one-way → deep-strategy-problem-shaping-decision-support full protocol
- Hire someone = one-way → deep-strategy-problem-shaping-decision-support
- Send tweet = two-way (can delete) → just send

### Anti-patterns
- Listing 7 options (paralysis) → max 3
- Recommending "it depends" without picking → always pick primary
- Strategy with no first action → useless
- Ignoring user's actual constraints → reframe step prevents this

---

## Output format
Short. Headers + bullets. Long thinking → compressed output.
Internal chain shown only if explicitly asked ("show your work").

---

## Idea handoff

Idea **produk/fitur** spesifik (bukan tujuan operasional umum) → handoff ke **m26**: Grill-Me (pertajam) → To-PRD → To-Issues. deep-strategy-problem-shaping-decision-support nge-frame masalah, m26 nge-bentuk spec produk dari idea.
