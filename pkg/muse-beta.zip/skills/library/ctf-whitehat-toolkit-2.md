---
name: ctf-whitehat-toolkit-2
description: "CTF, capture the flag, whitehat, bug bounty, decode flag, crypto challenge, caesar, xor cipher, hash identify, reverse, forensics challenge, HTB, THM, CTFd, writeup"
when_to_use: "CTF, capture the flag, whitehat, bug bounty, decode flag, crypto challenge, caesar, xor cipher, hash identify, reverse, forensics challenge, HTB, THM, CTFd, writeup"
source: muse-beta
---

# CTF / Whitehat Toolkit

**Load when:** CTF, capture the flag, whitehat, bug bounty, decode flag, crypto challenge, caesar, xor cipher, hash identify, reverse, forensics challenge, HTB, THM, CTFd, writeup
---

## SCOPE & ETIKA (baca dulu — non-negotiable)
ctf-whitehat-toolkit-2 buat **CTF legal & bug-bounty in-scope**: platform latihan (HackTheBox/TryHackMe/CTFd), kompetisi resmi, atau target yang operator punya **izin tertulis**. Tujuannya dapet reward/skill secara whitehat.
- ✅ Boleh: analisis pasif, decode, klasik-crypto, identifikasi, recon target sendiri/in-scope.
- ❌ TIDAK: nyerang sistem tanpa izin, akses data orang lain, jual exploit. Kalau target gak jelas in-scope → tanya operator dulu (R9 gate), jangan asumsi.
Tool inti di sini **stdlib-only & pasif** (encoding/analisis). Eksploitasi aktif (web/pwn) = manual operator + izin.

## TOOL (v4.2, net-new)
`tools/ctf.py` — toolkit serbaguna:
- `find_flags(text)` — ekstrak pola `NAME{...}`.
- `triage(desc)` — tebak kategori (web/pwn/crypto/reverse/forensics/osint) dari deskripsi soal → arahin tooling.
- `try_decode(data)` — kupas multi-layer: base64 / hex / rot13 / url / binary / ascii-decimal, diurut by printability.
- `caesar_bruteforce(text)` — 26 shift sekaligus.
- `xor_single_byte(bytes)` — brute 1-byte XOR, rank by englishness.
- `xor_repeating(data, key)` — repeating-key/Vigenere XOR (enc==dec).
- `identify_hash(h)` — tebak tipe (MD5/SHA-1/256/512, bcrypt, argon2) dari panjang/charset.

## ALUR STANDAR (per kategori)
```python
from ctf import triage, try_decode, find_flags, caesar_bruteforce, xor_single_byte, identify_hash

# 0. Triage: soal ini kategori apa?
triage("RSA modulus nonce encrypt")        # → [('crypto', 4)]

# 1. CRYPTO/MISC — kupas encoding berlapis
for a in try_decode(blob)[:3]:
    print(a.method, a.value)                # cari yang printable & ada flag{...}
find_flags(decoded)

# 2. Classic cipher
caesar_bruteforce(ciphertext)               # baca shift yang masuk akal
xor_single_byte(ct_bytes)                   # top-5 kandidat key

# 3. Hash
identify_hash("5f4dcc3b5aa765d61d8327deb882cf99")   # → ['MD5','NTLM']
```
Recon checklist per kategori:
- **web**: cek header/cookie/JWT, params (IDOR/LFI/SQLi), source map, robots.txt — pakai m11 + httpx, izin in-scope only.
- **pwn/reverse**: `strings`, decompile (manual, host), cari fungsi cek-flag.
- **forensics**: metadata/exif, `binwalk`/carve, pcap (wireshark), stego.
- **crypto**: encoding chain → classic → modern (RSA small-e/common-modulus, AES-ECB cut-paste) — math manual.

## ORCHESTRATOR + SWARM (v4.2, `tools/ctf/`)
ctf-whitehat-toolkit-2 = **router CTF**. Buat soal nyata (bukan cuma decode), ctf-whitehat-toolkit-2 triage → cek scope → dispatch ke sub-skill kategori → validasi flag → writeup. Sub-skill kategori:

| Sinyal soal | Sub-skill |
|---|---|
| URL / web app / HTTP service | **ctf-web-exploitation-2** (ctf-web) |
| ELF/PE + remote `nc host port` | **ctf-binary-exploitation-pwn-2** (ctf-pwn) |
| ELF/PE, "what does it do", no overflow | **ctf-reverse-engineering-2** (ctf-rev) |
| ciphertext / key / `.pem` / math / encoding | **ctf-cryptography-2** (ctf-crypto) |
| `.pcap` / memory dump / image / zip / "hidden" | **ctf-forensics-stego-2** (ctf-forensics) |
| LLM/AI target, jailbreak, prompt injection, Gandalf/Lakera | **ctf-prompt-injection-llm-red-teaming** (ctf-prompt-injection) |
| gak jelas | ctf-forensics-stego-2 file-id dulu → re-triage |

**Full-auto runtime** (`tools/ctf/`) — poll CTFd, race N model per soal di sandbox Docker, first valid flag wins, HITL/consensus gate sebelum submit:
```bash
cd tools/ctf
cp .env.example .env && cp scope.example.json scope.json   # set host authorized
docker build -f sandbox/Dockerfile.sandbox -t ctf-sandbox .
python3 run.py            # poll/solve loop
python3 run.py status     # state per soal
python3 run.py approve    # submit flag yang antri HITL (aksi operator)
```
Helper kunci: `tools/ctf/scope_guard.py` (allowlist — whitehat line, deny menang), `tools/ctf/flag_validator.py` (full-match + anti-placeholder, anti-halusinasi flag), `tools/ctf/rsa_attacks.py` (RSA offline). Detail: `tools/ctf/README.md`.

## SCOPE & DELEGATION
| Butuh | ctf-whitehat-toolkit-2 | Delegasi |
|---|---|---|
| Kategori & arah serang | `triage()` | — |
| Decode/crypto klasik/hash-id | `ctf.py` | — |
| Web / pwn / rev / crypto / forensics dalam | dispatch | ctf-web-exploitation-2 / ctf-binary-exploitation-pwn-2 / ctf-reverse-engineering-2 / ctf-cryptography-2 / ctf-forensics-stego-2 |
| LLM red-team / prompt injection (Gandalf) | dispatch | ctf-prompt-injection-llm-red-teaming (`tools/ctf/gandalf_solver.py`) |
| Full-auto solve banyak soal | — | `tools/ctf/run.py` (coordinator + swarm) |
| Konfirmasi target authorized | — | `tools/ctf/scope_guard.py` |
| Validasi flag (anti-halusinasi) | — | `tools/ctf/flag_validator.py` |
| Audit kerentanan target | recon checklist | m11 (audit/exploit review) |
| HTTP recon in-scope | — | m6 (httpx) + m11 |
| Otomasi banyak soal/round | — | m12/m30 (batch, rate-limit) |
| Writeup/report reward | — | m8 (PDF) / m26 (spec) |

## SAFETY RAILS
- Izin = syarat. Out-of-scope/target asing → R9 gate ("⚠️ target ini in-scope & ada izin? Lanjut? y/n"), default tahan.
- Jangan simpan/lecehkan data sensitif yang kebuka saat challenge.
- `secret_tripwire` (v4.2) tetap aktif di output — flag boleh tampil, tapi key/secret nyata yang gak relevan tetap di-redact.

## QUICKSTART
```bash
python3 tools/ctf.py                # demo decode + triage + hash-id
python3 tools/tests/run_tests.sh    # test_ctf hijau (offline)
```
🔧 Upgrade: combo m8 buat auto-generate writeup PDF tiap flag ketemu.
