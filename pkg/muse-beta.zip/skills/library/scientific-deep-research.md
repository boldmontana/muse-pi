---
name: scientific-deep-research
description: "deep research, AI-Q, tooluniverse, hipotesis, citations, riset ilmiah, eksperimen"
when_to_use: "deep research, AI-Q, tooluniverse, hipotesis, citations, riset ilmiah, eksperimen"
source: muse-beta
---

# Scientific & Deep Research

**Category:** Human-Centered

**Load when:** deep research, AI-Q, tooluniverse, hipotesis, citations, riset ilmiah, eksperimen
Riset mendalam berbasis bukti: kirim task ke server riset, dapat report + sitasi; rangkai tool ilmiah (ToolUniverse-style); generate hipotesis & desain eksperimen. **Opsional, read/produce-only.** Tool: `tools/research_q.py`.

> Catatan privasi: `research_q` **mengirim task ke server eksternal**. Jangan sertakan secret/PII/strategi rahasia di prompt riset. Untuk topik sensitif → mode lokal (cascade LLM via `model_registry`).

| Capability | Cara | Output |
|---|---|---|
| Deep research (AI-Q style) | dispatch ke research server → poll → report | report + citations |
| Scientific tool workflows | rangkai tool (search → fetch → analyze → verify) | hasil terstruktur |
| Hypothesis & experiment design | generate hipotesis testable + rancang uji | rencana eksperimen |

---

## 1. Deep research (AI-Q pattern)

Kirim pertanyaan → server riset fan-out (search → fetch → verifikasi adversarial → sintesis) → report bersitasi. Bukan jawaban satu-shot; ada jejak sumber.

```python
from research_q import deep_research
job = deep_research("dampak EIP-4844 ke biaya L2 rollup 2024-2026", depth="thorough")
print(job.report)        # markdown + [1][2] citations
print(job.sources)       # list URL + klaim yang didukung
```

Kalau host punya skill harness `deep-research` (Claude/Cursor) → route ke situ. Kalau tidak → `research_q` jalan via `model_registry` + web fetch operator. **Setiap klaim penting wajib punya sitasi**; tanpa sumber → tandai "unverified", jangan dijual sebagai fakta (sejalan self-critique agentic-eval-self-critique).

## 2. Scientific tool workflows (ToolUniverse-style)

Riset ilmiah = kombinasi banyak tool kecil, bukan satu model. Rangkai jadi pipeline:

```
QUERY → [literature search] → [fetch papers] → [extract method/result]
      → [cross-check claims] → [statistik/replikasi cek] → [synthesize + cite]
```

Pola: tiap langkah satu tool dengan output terstruktur, di-chain. Untuk domain spesifik (bio/kimia/material) sambungkan ke API/DB publik (PubMed, arXiv, Semantic Scholar, PubChem) — keyless atau free-tier. Verifikasi silang ≥2 sumber sebelum nyimpulin.

## 3. Hypothesis generation & experimental design

```
1. OBSERVASI  → apa yang diketahui? anomali/gap apa?
2. HYPOTHESIS → pernyataan testable + falsifiable (bukan "X mungkin bagus")
3. PREDICT    → kalau H benar, kita harus lihat Y di kondisi Z
4. DESIGN     → variabel kontrol vs uji, sample size, metrik, baseline, ablation
5. ANALYZE    → uji statistik yang cocok + threshold signifikansi DITENTUKAN DI DEPAN
```

Hipotesis harus falsifiable — kalau gak ada hasil yang bisa membantahnya, itu bukan hipotesis. Beda dari systematic-debug-auto-debug (hypothesis buat *debug* sistem); scientific-deep-research = hipotesis *riset/ilmiah*. Untuk eksperimen pada strategi/agent sendiri → pakai variance testing agentic-eval-self-critique sebagai alat ukurnya.

## 4. Scientific domain libraries & discovery

Untuk sains terapan, **jangan reimplementasi** — dispatch ke library/tool domain yang sudah ada & tervalidasi. Agent = orkestrator + verifikator, bukan sumber kebenaran biomedis.

| Domain | Tool/library matang (contoh) |
|---|---|
| Cancer genomics / RNA velocity | `scanpy`, `scvelo`, `anndata` |
| Drug-target binding / docking | `RDKit`, `AutoDock Vina`, `DiffDock` |
| Molecular dynamics | `OpenMM`, `GROMACS` |
| Geospatial science | `geopandas`, `rasterio`, `xarray` |
| Time-series forecasting | `statsmodels`, `prophet`, `darts` |

Pola: agent pilih tool yang tepat, siapin input, jalanin, **verifikasi hasil** (sanity check + sitasi metode), bukan ngarang angka. Library 100+ scientific = dispatch target, bukan klaim built-in.

### Hugging Science / Hub discovery
Auto-discover dataset & model: cari di Hugging Face Hub by task/domain (keyless untuk publik).
```python
# pip install huggingface_hub
from huggingface_hub import HfApi
api = HfApi()
models = api.list_models(search="protein structure", limit=10)
ds = api.list_datasets(search="single cell rna", limit=10)
```
Pilih by relevansi + lisensi + popularitas/maintained. Sambung ke pipeline analisis.

### Multi-step scientific pipeline
```
literature review (scientific-deep-research §1) → discovery model/dataset (HF) → experiment simulation
→ data analysis (library domain) → paper drafting (product-spec-workflows To-PRD style + copywriting-writing-mastery writing + file-artifact-production export)
```

### K-Dense / BYOK (local co-scientist)
Mode lokal "bring your own key": jalanin co-scientist di mesin sendiri pakai key operator via `model_registry` (inference-systems-ai-builder `add model`). Data sensitif gak keluar — sama prinsip privasi `research_q` `local_only=True`.

---

## Catatan
- Report bersitasi > opini tanpa sumber. Tanpa sumber → "unverified".
- Sains: dispatch ke library tervalidasi + verifikasi; jangan ngarang hasil biomedis.
- Privasi: `research_q` kirim ke server eksternal — sanitize dulu.
- Combo: scientific-deep-research + agentic-eval-self-critique (eval bukti) + problem-shaping-decision-support (framing pertanyaan) + file-artifact-production (export report PDF/DOCX).
