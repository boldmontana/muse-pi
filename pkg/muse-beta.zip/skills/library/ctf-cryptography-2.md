---
name: ctf-cryptography-2
description: "CTF crypto, RSA attack, Wiener, Hastad, common modulus, Coppersmith, padding oracle, nonce reuse, LCG, Mersenne twister, hash length extension, ECDSA, dispatched by ctf-whitehat-toolkit-2 crypto"
when_to_use: "CTF crypto, RSA attack, Wiener, Hastad, common modulus, Coppersmith, padding oracle, nonce reuse, LCG, Mersenne twister, hash length extension, ECDSA, dispatched by ctf-whitehat-toolkit-2 crypto"
source: muse-beta
---

# CTF Cryptography

**Load when:** CTF crypto, RSA attack, Wiener, Hastad, common modulus, Coppersmith, padding oracle, nonce reuse, LCG, Mersenne twister, hash length extension, ECDSA, dispatched by ctf-whitehat-toolkit-2 crypto
# ⚠️ DISPATCHED by ctf-whitehat-toolkit-2 (CTF/Whitehat) — this file kept for detailed playbooks only

---

## SCOPE (baca dulu)
Sub-skill **crypto** buat CTF in-scope. Setelah ctf-whitehat-toolkit-2 + scope check. Tool inti offline & deterministik (`tools/ctf/rsa_attacks.py`, gmpy2 optional → fallback pure-Python). Lattice/Coppersmith → SageMath di sandbox.

## TOOLBOX
SageMath (lattice/finite field/factor) · RsaCtfTool (dispatcher RSA) · pycryptodome · gmpy2 · z3 · sympy · factordb

## IDENTIFY DULU
Baca source/handout: scheme (RSA/AES/ECC/xor/classical), param (`e`,`n`,key size,mode), apa yang reused/leaked. **Encoding ladder dulu** (base64→hex→rot/xor) sebelum asumsi hard crypto.

## RSA DECISION TREE (`rsa_attacks.py`)
- **small e (e=3)** + msg kecil → cube root (`small_e_root`).
- **e=3, msg sama ke 3 penerima** → Hastad broadcast (CRT + cube root).
- **N factorable** → factordb; prime dekat → Fermat (`fermat_factor`); faktor kecil → Pollard.
- **Wiener** → `d` kecil (`wiener`, continued fractions).
- **common modulus** → `n` sama, 2 `e` coprime → Bezout (`common_modulus`).
- **partial key / known high bits** → Coppersmith (Sage `small_roots`).
- **LSB/parity oracle** → binary-search decrypt.
- **p,q/phi diketahui** → `decrypt_with_factors`.
```python
from rsa_attacks import auto, small_e_root, fermat_factor, wiener, common_modulus
m = auto(c, e, n)            # coba attack murah berurutan → plaintext int / None
```

## BLOCK CIPHERS
- **ECB** — block identik → cipher identik; cut-and-paste forge token; byte-at-a-time decrypt vs oracle.
- **CBC bit-flip** — flip byte `C[i]` kontrol `P[i+1]` (auth bypass).
- **CBC padding oracle** — decrypt tanpa key kalau server bocorin pad validity.
- **CTR/stream nonce reuse** — XOR 2 ciphertext → crib-drag.
- **GCM nonce reuse** — forge tag (recover auth key).

## SHAPE LAIN
Weak PRNG/LCG (recover state) · Mersenne Twister (untemper 624 output) · hash length extension (hashpumpy) · ECC (Smart's attack, small subgroup, ECDSA nonce reuse → recover priv key) · classical (Vigenere/substitution → freq analysis).

## SCOPE & DELEGATION
| Butuh | ctf-cryptography-2 | Delegasi |
|---|---|---|
| Encoding/klasik/hash-id ringan | — | ctf-whitehat-toolkit-2 `ctf.py` |
| RSA/block/PRNG attack | `rsa_attacks.py` + Sage | — |
| Validasi flag | — | `tools/ctf/flag_validator.py` |
| Full-auto swarm | — | `tools/ctf/run.py` |

## SAFETY RAILS
Flag lewat `flag_validator.py` → balik ctf-whitehat-toolkit-2 → HITL. Jangan invent. factordb/RsaCtfTool butuh network — jalan di sandbox bridge, scope tetap berlaku.

🔧 Upgrade: extend `rsa_attacks.auto()` dengan Hastad+Coppersmith dispatcher (delegasi Sage).
