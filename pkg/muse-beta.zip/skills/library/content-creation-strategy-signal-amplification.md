---
name: content-creation-strategy-signal-amplification
description: "Content Creation, Strategy & Signal Amplification"
when_to_use: "Content Creation, Strategy & Signal Amplification"
source: muse-beta
---

# Content Creation, Strategy & Signal Amplification
# MERGED: content-creation-strategy-signal-amplification (creation) + content-creation-strategy-signal-amplification-merged (strategy/social media) — July 2026

---

## Operator Profile

Engagement architect. Scroll-stopping signals that convert. Platform-fluent. Bias toward conversion over reach. This skill now covers both content CREATION and STRATEGY — from raw output to full content system.

---

## PART A: CONTENT CREATION (original content-creation-strategy-signal-amplification)

### Interrupt Pattern Library

```
Gap:        "What [audience] doesn't know about [domain]..."
Reframe:    "Stop [accepted behavior]. Here's what works."
Proof:      "I did [outcome] in [window] using this:"
Method:     "How to [goal] without [friction]"
Index:      "[N] reasons [audience] fails at [goal]"
Arc:        "[Time ago] I was [state]. Today: [contrast]."
Position:   "Unpopular opinion: [defensible contrarian claim]"
Alert:      "If you're doing [behavior], stop. Here's why:"
Lossfear:   "[Audience] losing [thing] because of [unseen cause]"
Validate:   "[Specific number] of [audience] confirmed: [insight]"
```

### Delivery Frameworks

```
AIDA:    Interrupt → Qualify → Desire → Directive
PAS:     Specify Pain → Amplify → Resolve
STORY:   Baseline → Tension → Block → Resolution → Yield
PASTOR:  Problem → Amplify → Story → Transform → Offer → Response
4Ps:     Picture → Promise → Proof → Push
```

### Format Specifications

#### Short-form video (60–90s — TikTok, Reels, Shorts)

```
0–3s:    interrupt signal (hook + visual change)
3–15s:   qualification / context
15–50s:  core value delivery (numbered if 3+ points)
50–60s:  engagement directive (comment / follow / save)
```

#### Twitter/X thread (CT-style, crypto-aware)

```
Tweet 1: Interrupt (no thread emoji on tweet 1, controversial works)
Tweet 2–8: One proof point each (max 280 chars, keep punchy)
Tweet 9: Synthesis / "tl;dr"
Tweet 10: Directive (RT + follow + bookmark)
```

#### Long-form video (2–10 min)

```
0–30s:    interrupt → problem → "stick around for X"
30s–80%:  resolution + proof
80–90%:   validation (testimonial / data / case)
90–100%:  directive (subscribe + link)
```

#### Carousel (IG / LinkedIn)

```
Slide 1: Title + hook
Slide 2: Pain point
Slides 3–7: Method (one per slide)
Slide 8: Recap
Slide 9: CTA (save + share)
```

### Indonesian Voice Patterns (CT / kripto / casual)

```
- Pakai "lo/gue" untuk CT vibe, "kalian" untuk audience yang lebih luas
- Slank kripto: gas, cuan, sultan, FOMO, ngegas, langsung gas, bagi-bagi, sat-set
- Hindari: hari yang cerah, semoga membantu, salam hangat (formal banget)
- Pakai "btw", "ngomong-ngomong", "fyi" untuk transition
- Pertanyaan retoris di akhir: "Lo udah join belum?" / "Mau ikutan?"
```

### Airdrop Campaign Template (Kakak-style format)

```
New Airdrops : [Name Project]
🏷 Reward : [Reward Total / Estimate]
🪂 Register :
➖ Join Telegram
➖ Follow Twitter & Retweet
➖ Submit BSC Address
➖ Complete Another Task
➖ Done

📖 Details : [Add Details Simple]
```

Adjust per project: tasks bisa Discord, on-chain interaction, quiz, referral chain.

### Crypto Content Patterns (proven hooks)

#### Alpha sharing
```
🚨 ALPHA — [Project Name]
Backer: [VC names]
Stage: [testnet / mainnet / TGE soon]
Why interesting: [1 line, specific]
How to join: [step]
Risk: [be honest — testnet farming, time investment]
```

#### Project shutdown / scam alert
```
[Project] just rugged.
What happened: [1 line]
Red flags missed:
• [flag 1]
• [flag 2]
• [flag 3]
Lesson: [pattern to spot next time]
```

#### Sarcastic CT post
```
[Crypto behavior].
[Same person]: [contradictory outcome].
[Punchline].
```

#### Tutorial / how-to
```
[N] step guide: [outcome] in [time]

1. [action] ← [why it matters]
2. [action] ← [why]
3. [action] ← [why]

[CTA: bookmark / RT / DM for help]
```

### Output Templates (generic)

#### Launch signal
```
🔥 [IDENTIFIER] is live.
Built for: [specific friction]
✅ [outcome 1]  ✅ [outcome 2]  ✅ [outcome 3]
Entry price: [X]  (changes [date])
Access: [link / DM "[trigger word]"]
```

#### Education signal
```
[N] things [audience] miss about [domain]:

1️⃣ [specific]
2️⃣ [specific]
3️⃣ [specific]

Save for later 👇
Follow for daily [topic].
```

### Distribution Multiplier (atomic content)

```
1 long-form video  → 5 threads + 10 carousel slides + 3 short scripts + 1 newsletter
1 thread           → 1 video script + 5 IG quotes + 1 LinkedIn post
1 livestream       → transcript → article + clips → shorts + quotes → tweets
```

### Algorithm Heuristics (current as of late 2025/early 2026)

```
Twitter/X:    Replies > RT > Like. Bookmark = strong signal. Reply guy farms win.
TikTok:       Watch-time > engagement. First 3s critical. Trends + niche overlap.
Instagram:    Carousels > Reels for save rate. Reels for reach.
YouTube:      CTR × watch-time = ranking. Front-load value.
Telegram:     Channel growth via cross-promo + reaction emoji buttons.
LinkedIn:     Polarizing-but-defensible take > anything bland.
```

---

## PART B: CONTENT STRATEGY & SOCIAL MEDIA (from content-creation-strategy-signal-amplification-merged)

Mesin konten sosial end-to-end: strategi (pillar/audience/positioning), kalender, adaptasi per-platform, hook scroll-stopper, caption+hashtag, dan script thread/carousel/reels. **Opsional, non-dana.** Tool: `tools/content.py`.

> Beda dari Part A: Part A = voice Indonesia/crypto-twitter + template airdrop. Part B = strategi & produksi sosial umum lintas platform. Combo keduanya buat konten crypto-ID.

### Content strategy builder

Sebelum produksi, tentuin fondasi (sekali, simpan di vault daily-assistant-ii-watchdog-vault-multimodal-triage, reuse):

```
PILLARS    → 3-5 tema inti (mis. edukasi · behind-scenes · proof · opini · CTA). Rasio 70-20-10.
AUDIENCE   → siapa, masalah apa, di platform mana, bahasa apa
POSITIONING→ 1 kalimat: "buat [audience] yang [masalah], gua [solusi unik]"
TONE       → ambil dari brand voice (m20) / USER.md
GOAL        → awareness | trust | leads | sales — beda goal, beda format
```

Output = "content OS" yang nyetir semua keputusan berikutnya. Tanpa ini, konten jadi random.

### Content calendar generator

```python
from content import calendar
plan = calendar(pillars=["edukasi","proof","opini"], days=30, per_week=5,
                platforms=["x","linkedin","ig"])
# → list {date, pillar, platform, format, topic_slot} — isi topik via LLM/ide (copywriting-writing-mastery-content-research-analytics-merged)
```

Distribusi pillar merata + variasi format, hindari spam 1 jenis. Mingguan/bulanan. Sambung cron (m4/m17) buat auto-publish.

### Platform-specific adapter

Satu pesan, beda baju per platform — JANGAN copy-paste identik:

| Platform | Format menang | Panjang | Nada |
|---|---|---|---|
| **X/Twitter** | thread, 1-liner punchy | pendek, hook di tweet 1 | cepat, opini |
| **LinkedIn** | thought leadership, story | medium, baris pendek | profesional-personal |
| **Instagram** | carousel, visual-first | caption medium + hook | visual, relatable |
| **TikTok/Reels** | script video pendek | 15-60s, hook 3 detik pertama | energetik, native |

```python
from content import adapt
variants = adapt("inti pesan lo", platforms=["x","linkedin","ig","tiktok"])
```

### Viral hook & scroll-stopper

Hook = 80% performa. Stop scroll dalam 3 detik / baris pertama:

```
POLA HOOK:
- Kontras   : "Semua orang bilang X. Mereka salah."
- Angka      : "3 kesalahan yang bikin lo rugi..."
- Pertanyaan : "Kenapa post lo gak ada yang liat?"
- Stakes     : "Gua kehilangan $5k sebelum sadar ini"
- Curiosity gap: "Ini yang gak ada yang kasih tau soal..."
```

Hook harus relevan ke isi (clickbait yang gak nepatin = kill trust). CTA jelas di akhir: satu aksi, bukan lima.

### Caption + hashtag optimizer

```python
from content import caption, hashtags
cap = caption("topik", platform="ig", hook_style="curiosity", cta="follow")
tags = hashtags("topik", platform="ig", mix=("broad","niche","branded"))  # campur jangkauan
```

Hashtag: campur broad (jangkauan) + niche (relevan) + branded (milik lo). Riset trending → copywriting-writing-mastery-content-research-analytics-merged. Jangan spam 30 tag generik.

### Thread / carousel / reels writer

```python
from content import thread, carousel, reels_script
thread("topik", n=7)              # X/LinkedIn: hook → poin → CTA, tiap tweet berdiri sendiri
carousel("topik", slides=8)        # IG: 1 ide/slide, slide 1 = hook, terakhir = CTA
reels_script("topik", seconds=30)  # script + timing + voiceover + on-screen text
```

Repurposing 1 long-form → multi-format → copywriting-writing-mastery-content-research-analytics-merged pipeline.

---

## Combo Chain

```
content-creation-strategy-signal-amplification (creation+strategy) → copywriting-writing-mastery-content-research-analytics (copy frameworks) → m20 (humanize) → m18 (visual) → copywriting-writing-mastery-content-research-analytics-merged (research/analytics) → m4/m17 (schedule)
```

## Constraints

- Minimum 3 interrupt variations when generating hooks
- Always specify platform AND format AND length
- Every output includes engagement directive — no exceptions
- Indonesian content: avoid Google-translate phrasing, use natural slang
- Crypto content: include risk note when shilling ("DYOR", "high risk", or stronger)
- Konten = artefak, gak ada gate. Publish ke platform = aksi outward → kalau via agent, R9 gate sekali.
- Humanize sebelum publish (m20) biar gak "bau AI". Visual → m18. Frameworks copy → copywriting-writing-mastery-content-research-analytics.

**Load when:** Content Creation, Strategy & Signal Amplification
