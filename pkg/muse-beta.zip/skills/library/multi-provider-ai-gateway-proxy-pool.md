---
name: multi-provider-ai-gateway-proxy-pool
description: "proxy, gateway, Cloudflare, Workers AI, model pool, load balancer, account rotation, neuron, cf-proxy, LLM routing, multi-provider, AI gateway, model fallback, free LLM, Workers AI gateway, reverse proxy AI"
when_to_use: "proxy, gateway, Cloudflare, Workers AI, model pool, load balancer, account rotation, neuron, cf-proxy, LLM routing, multi-provider, AI gateway, model fallback, free LLM, Workers AI gateway, reverse proxy AI"
source: muse-beta
---

# Multi-Provider AI Gateway & Proxy Pool

**Category:** Infrastructure & AI Gateway

**Load when:** proxy, gateway, Cloudflare, Workers AI, model pool, load balancer, account rotation, neuron, cf-proxy, LLM routing, multi-provider, AI gateway, model fallback, free LLM, Workers AI gateway, reverse proxy AI
---

## Overview

multi-provider-ai-gateway-proxy-pool builds, deploys, and manages a **multi-provider AI gateway** — an OpenAI-compatible reverse proxy that pools accounts across Cloudflare Workers AI, OpenRouter, and any compatible LLM provider. Unlike cf-proxy (single-provider CF Workers), this is a **sovereign multi-provider mesh** that:

1. **Pools ALL free-tier AI providers** — not just Cloudflare. Knows every free LLM endpoint.
2. **Account rotation + neuron/budget tracking** per provider with proactive skip
3. **Intelligent model routing** — picks best provider for each model based on cost/speed/availability
4. **Built-in fallback chain** — if CF hits 429, auto-routes to next provider
5. **React dashboard** — pool health, neuron usage, cost tracking, request logs
6. **Zero-cost operation** — designed to run on free tiers only, maximizing $0 spend
7. **Drop-in OpenAI SDK compatible** — any code using OpenAI SDK works by changing base_url
8. **Integrated with MUSE BETA AGENT** — feeds into inference-systems-ai-builder (Inference Systems) provider cascade

### Why This Matters

```
Problem:  Free AI APIs have per-account rate limits (CF: 10k neurons/day, 
          OpenRouter: variable, Groq: RPM limits). One account = limited throughput.
          
Solution: Pool N accounts per provider, rotate automatically, track budgets.
          Multi-provider means even if Cloudflare is down, traffic auto-routes.
          
Result:   Virtually unlimited free AI inference for bots, agents, and apps.
          Zero API costs. Full OpenAI SDK compatibility.
```

---

## Architecture

```
                    ┌─────────────────────────────────┐
                    │      MUSE BETA AGENT (multi-provider-ai-gateway-proxy-pool)        │
                    │   Multi-Provider AI Gateway      │
                    └─────────────┬───────────────────┘
                                  │
                    ┌─────────────┼───────────────┐
                    │             │               │
              ┌─────▼────┐  ┌────▼─────┐  ┌─────▼─────┐
              │CF Workers│  │OpenRouter│  │  Groq     │
              │  Pool    │  │  (free)  │  │  (free)   │
              │ N accts  │  │ API key  │  │ API key   │
              └──────────┘  └──────────┘  └───────────┘
                    │             │               │
                    └─────────────┼───────────────┘
                                  │
                    ┌─────────────▼───────────────────┐
                    │     OpenAI-Compatible Endpoint   │
                    │     POST /v1/chat/completions     │
                    │     GET  /v1/models               │
                    │     POST /v1/embeddings            │
                    └───────────────────────────────────┘
```

---

## Provider Pool Matrix

| Provider | Free Tier | Rate Limit | Models Available | Neuron/Budget |
|----------|-----------|------------|------------------|---------------|
| **Cloudflare Workers AI** | ✅ 10k neurons/day | 300 req/min | 20+ (llama, deepseek, mistral, gemma) | Neurons tracked per account |
| **OpenRouter (free models)** | ✅ Free models | Varies | 50+ free models | Token-based tracking |
| **Groq Cloud** | ✅ Free tier | 30 req/min | llama, mixtral, gemma | RPM tracking |
| **Together AI** | ✅ $1 credit | 60 req/min | Various open models | Token-based |
| **HuggingFace Inference** | ✅ Free tier | Rate-limited | Thousands of models | Request-based |
| **Cohere** | ✅ Trial API | 100 req/min | Command, Embed | Request-based |

---

## Step-by-Step Workflow

### Phase 1: Setup Gateway (15 min)

```bash
# 1. Clone and install
git clone https://github.com/your-org/muse-gateway.git
cd muse-gateway
npm install
npm run build  # Builds React dashboard

# 2. Configure providers
cp .env.example .env
# Edit .env with your accounts:
```

**.env structure:**
```env
# Server
GATEWAY_PORT=8750
GATEWAY_HOST=0.0.0.0
GATEWAY_API_KEY=sk-your-auth-key  # Optional auth

# Cloudflare Workers AI (can have multiple accounts)
CF_ACCOUNTS='[{"token":"cfut_xxx1","id":"acct1"},{"token":"cfut_xxx2","id":"acct2"}]'

# OpenRouter
OPENROUTER_API_KEY=sk-or-v1-xxx

# Groq
GROQ_API_KEY=gsk_xxx

# Together AI
TOGETHER_API_KEY=xxx

# Provider config
CF_COOLDOWN_429=90           # Seconds to skip after 429
MAX_RETRIES=5                # Max provider hops per request
NEURON_LIMIT=10000           # Daily neuron cap per CF account
LOG_LEVEL=INFO
```

### Phase 2: Account Pool Management

The gateway manages account pools per provider:

```
Cloudflare Account Pool:
┌──────────┬─────────┬──────────┬──────────────┐
│ Account  │ Status  │ Neurons  │ Requests     │
├──────────┼─────────┼──────────┼──────────────┤
│ acct-1   │ active  │ 7,234    │ 1,245        │
│ acct-2   │ cooldown│ 10,000   │ 2,100        │
│ acct-3   │ active  │ 2,156    │ 432          │
│ acct-4   │ active  │ 5,891    │ 987          │
└──────────┴─────────┴──────────┴──────────────┘
```

**Auto-rotation logic:**
1. Pick account with lowest neuron usage (or round-robin if all equal)
2. If account returns 429 → cooldown for `CF_COOLDOWN_429` seconds
3. If account hits 10,000 neurons → skip until 00:00 UTC
4. If all CF accounts exhausted → fallback to next provider
5. Reservation system: deduct estimated neurons BEFORE request, refund on failure

### Phase 3: Intelligent Model Routing

Instead of hardcoding models, the gateway:
1. Fetches live model lists from ALL providers
2. Builds a unified model catalog
3. Routes requests to the best provider for each model

**Routing priority:**
```
Model: llama-3.3-70b-instruct
├── 1st try: Cloudflare Workers AI (free, fast, 0 cost)
├── 2nd try: Groq (free tier, fast, RPM limit)
├── 3rd try: OpenRouter (free models, variable speed)
├── 4th try: Together AI ($1 credit)
└── Fallback: Return 503 if all providers exhausted
```

**Model resolution (like cf-proxy but multi-provider):**
```
Input: "llama-3.2-1b-instruct"
├── CF: @cf/meta/llama-3.2-1b-instruct
├── OpenRouter: meta-llama/llama-3.2-1b-instruct
├── Groq: llama-3.2-1b-instruct
└── Together: meta-llama/Llama-3.2-1B-Instruct
```

### Phase 4: Neuron Budget Tracking

Cloudflare uses "neurons" as currency (1 neuron ≈ 1 inference unit). The gateway estimates:

```javascript
neurons = prompt_tokens × RATE_IN + completion_tokens × RATE_OUT

// Rates from CF pricing page (lib/neurons.js)
const RATES = {
  "@cf/meta/llama-3.3-70b":  { in: 0.10, out: 0.25 },
  "@cf/deepseek-ai/deepseek": { in: 0.05, out: 0.10 },
  "@cf/microsoft/phi-4":      { in: 0.02, out: 0.05 },
  // ... all models
};
```

**Proactive skip:** If estimated neurons > remaining, skip account BEFORE request.

### Phase 5: OpenAI-Compatible API

```bash
# Chat completions (identical to OpenAI SDK)
curl http://localhost:8750/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk-your-auth-key" \
  -d '{
    "model": "llama-3.3-70b-instruct",
    "messages": [{"role":"user","content":"Hello!"}],
    "stream": true
  }'

# List available models (merged from all providers)
curl http://localhost:8750/v1/models

# Embeddings (routed to best provider)
curl http://localhost:8750/v1/embeddings \
  -H "Content-Type: application/json" \
  -d '{"model":"bge-base-en-v1.5","input":"Hello world"}'

# Health check (pool stats)
curl http://localhost:8750/health
```

### Phase 6: React Dashboard

Built-in dashboard at `http://localhost:8750`:

```
Tabs:
├── Overview — Total capacity, active providers, request throughput
├── Accounts — Per-provider, per-account status with neuron bars
├── Models — Unified model catalog, search, filter by provider
├── Routing — Live routing decisions, fallback chains
├── Logs — Request log with expandable payloads (like cf-proxy)
├── Cost — Estimated cost savings vs paid APIs ($0 target)
└── Config — Provider management, add/remove accounts
```

### Phase 7: MUSE BETA AGENT Integration

The gateway integrates with inference-systems-ai-builder (Inference Systems):

```python
# tools/model_registry.py — add gateway as provider
from model_registry import ModelRegistry

reg = ModelRegistry()
reg.add_provider("gateway", {
    "base_url": "http://localhost:8750/v1",
    "api_key": "sk-your-auth-key",
    "models": "auto",  # Fetched from /v1/models
    "priority": 0,     # Highest priority (free tier)
    "cost_per_1k": 0,  # Free
})

# Now all LLM calls cascade through gateway first
response = reg.call_with_cascade(messages)
# Tries: gateway → anthropic → openrouter → deepseek → groq
```

---

## Tools Reference

### New tools for this skill:

| Tool | Purpose | Location |
|------|---------|----------|
| `gateway_manager.py` | Deploy, configure, restart the AI gateway | `tools/gateway_manager.py` |
| `account_pooler.py` | Import accounts from sources, manage pools | `tools/account_pooler.py` |
| `model_resolver.py` | Resolve model names across providers | `tools/model_resolver.py` |
| `neuron_tracker.py` | Track and estimate neuron usage | `tools/neuron_tracker.py` |

### Existing tools used:

- `infrastructure-deployment` — VPS deployment (nginx reverse proxy, systemd service)
- `protocol-binding-service-bridge` — API integration (OpenAI SDK compatibility layer)
- `inference-systems-ai-builder` — Inference Systems (provider cascade integration)
- `batch-parallel-operations` — Batch operations (load testing, parallel requests)
- `daily-assistant-ii-watchdog-vault-triage` — Watchdog (auto-restart if gateway crashes)
- `power-pack-planner-swarm-automation` — Dashboard (custom monitoring widgets)
- `enterprise-defensive-ops` — Enterprise/defensive (rate limiting, auth, DDoS protection)

---

## Deployment Configurations

### Minimal (single VPS, personal use):
```yaml
server: Ubuntu 22.04, 2GB RAM
providers: CF Workers (2-3 accounts)
proxy: none (direct)
auth: API key optional
dashboard: localhost only
```

### Team (shared VPS, 5-10 users):
```yaml
server: Ubuntu 22.04, 4GB RAM
providers: CF Workers (5-10 accounts) + OpenRouter + Groq
proxy: nginx reverse proxy + Let's Encrypt
auth: API key required
dashboard: VPN or authenticated
monitoring: systemd service + watchdog
```

### Production (dedicated, 50+ users):
```yaml
server: 2x VPS (active + standby), 8GB RAM each
providers: All 6 providers, pooled
proxy: nginx + Cloudflare DNS + Let's Encrypt
auth: API key + rate limiting per key
dashboard: Public or authenticated
monitoring: Prometheus + Grafana
backup: DB replication, config sync
```

---

## Safety Rails

1. **No key exposure** — API keys never logged, dashboard shows masked keys
2. **Rate limit protection** — Gateway-level rate limiting prevents abuse
3. **Account isolation** — One account hitting 429 doesn't affect others
4. **Fallback guarantee** — At least 2 providers configured or refuse to start
5. **Usage alerts** — Notify if pool drops below 20% capacity
6. **Auto-suspend** — If all providers exhausted, return clear error (not silent failure)
7. **Request logging** — All requests logged (in-memory ring buffer, 500 entries)
8. **Neuron estimation** — Conservative estimates (over-estimate to avoid overrun)

---

## cf-proxy vs multi-provider-ai-gateway-proxy-pool Gateway — Key Differences

| Feature | cf-proxy | multi-provider-ai-gateway-proxy-pool Gateway |
|---------|----------|--------------|
| Providers | Cloudflare only | CF + OpenRouter + Groq + Together + HF + Cohere |
| Model routing | Single provider | Multi-provider with fallback chain |
| Account import | 9router DB only | Multiple sources (JSON, CSV, DB, manual) |
| Neuron tracking | CF neurons only | Provider-agnostic budget tracking |
| MUSE BETA AGENT | Not integrated | Full inference-systems-ai-builder/model_registry integration |
| Dashboard | Basic (Accounts/Models/Logs) | Extended (Routing/Cost/Config tabs) |
| Deployment | Manual npm | PM2/systemd/Docker with auto-restart |
| Auth | Bearer token | Bearer + per-key rate limiting + IP allowlist |
| Auto-scaling | No | Load-aware account rotation |
| Cost tracking | Neurons only | Estimated $ savings vs paid APIs |
| Provider health | Basic 429 handling | Health checks, latency tracking, provider scoring |

---

## Quick Start for MUSE BETA AGENT

```bash
# Deploy from MUSE BETA AGENT
# multi-provider-ai-gateway-proxy-pool auto-handles: clone, configure, deploy, integrate

# 1. Deploy gateway
python3 tools/gateway_manager.py deploy \
  --providers cf,openrouter,groq \
  --cf-accounts cf_accounts.json \
  --port 8750

# 2. Add to model registry
python3 tools/model_registry.py add-provider gateway \
  --base-url http://localhost:8750/v1 \
  --api-key sk-your-key \
  --priority 0

# 3. Verify
curl http://localhost:8750/health
# {"providers":{"cf":{"total":3,"available":3},"openrouter":{"available":true},"groq":{"available":true}}}

# 4. Use in any code
# Just change base_url — everything else is identical to OpenAI
from openai import OpenAI
client = OpenAI(base_url="http://localhost:8750/v1", api_key="sk-your-key")
response = client.chat.completions.create(
    model="llama-3.3-70b-instruct",
    messages=[{"role":"user","content":"Hello!"}]
)
```

---

## Monitoring Commands

```
# Pool health
GET /health → {"providers":{...},"total_capacity":...,"active_requests":...}

# Account status per provider
GET /api/accounts?provider=cf → [{account, status, neurons_used, neurons_remaining, requests_today}]

# Unified model list
GET /api/models?provider=all → [{name, providers, capabilities, added}]

# Cost estimation
GET /api/cost → {"estimated_monthly_savings":"$1,247","requests_today":15234,"average_cost_per_request":"$0.00"}

# Request log
GET /api/logs?limit=50 → [{timestamp, model, provider, account, tokens, duration, status}]
```

---

## Troubleshooting

| Issue | Cause | Fix |
|-------|-------|-----|
| All accounts 429 | Rate limit spike | Increase cooldown, add more accounts |
| Model not found | Model not available on any provider | Check `/v1/models` for available models |
| Gateway crashes | Memory leak | Check logs, increase VPS RAM, add swap |
| High latency | Faraway CF datacenter | Use provider closer to VPS region |
| Auth failures | Wrong API key | Check `.env` or `GATEWAY_API_KEY` |
| Zero accounts | Import failed | Check import source, verify tokens valid |
