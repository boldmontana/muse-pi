---
name: fault-diagnosis-resolution-systematic-debugging
description: "error, bug, not working, failed, debug, stack trace, "kenapa", "kok gagal", systematic debug, RCA, root cause, hypothesis, intermittent, reproduce"
when_to_use: "error, bug, not working, failed, debug, stack trace, "kenapa", "kok gagal", systematic debug, RCA, root cause, hypothesis, intermittent, reproduce"
source: muse-beta
---

# Fault Diagnosis, Resolution & Systematic Debugging

**Load when:** error, bug, not working, failed, debug, stack trace, "kenapa", "kok gagal", systematic debug, RCA, root cause, hypothesis, intermittent, reproduce
# MERGED: fault-diagnosis-resolution-systematic-debugging (fault diagnosis) + fault-diagnosis-resolution-systematic-debugging-merged (systematic debug/auto-debug loop) — July 2026


---

Diagnosis terstruktur + debugging sistematis termasuk auto-debug hypothesis loop. fault-diagnosis-resolution-systematic-debugging = pustaka pola error (cepat, lookup) + metode 4-fase buat bug aneh/intermittent.

---

## PART A: FAST DIAGNOSIS (original fault-diagnosis-resolution-systematic-debugging)

### Protocol — Diagnose BEFORE prescribing

#### Step 1 — Gather (request everything in ONE message)
```
- Exact exception text (full traceback, not paraphrased)
- Last action taken before fault
- Environment: OS, runtime version, package versions
- Last known working state
- What you've already tried
```

If user gave partial info, ask for all missing pieces in ONE message. Never "try X and report back" without diagnosis.

#### Step 2 — Classify
```
syntax       → malformed code
runtime      → valid syntax, execution failure (null ref, undef, type)
logic        → runs clean, wrong output
environment  → missing env var, wrong version, permission, path
network      → timeout, DNS, port, firewall, proxy
dependency   → missing module, version conflict, peer dep
auth         → 401/403, expired token, wrong scope
rate-limit   → 429, quota exceeded
config       → wrong value (NOT missing — value present but wrong)
```

The "config wrong value" class is high-priority: Kakak's history shows runtime `streaming` config caused duplicate Telegram responses. Always check this class for daemon/agent bugs.

#### Step 3 — Diagnose
```
Root cause: [specific line / config key / package]
Mechanism:  [one sentence why this causes the symptom]
Confidence: high / medium / low
```

If low confidence — ask for one more piece of evidence, don't guess.

#### Step 4 — Resolve
```bash
# Exact command(s), no placeholders
```
Show real values, not `<your_token>`. Use Kakak's actual paths if known (`/root/.muse/...`).

#### Step 5 — Verify
```bash
# Single command that proves it works
```

#### Step 6 — Harden
```
# Config delta or test to prevent recurrence
```

### Common error patterns library

#### Node / JS
- `Cannot find module` → missing install OR wrong cwd OR ES/CJS mismatch
- `MODULE_NOT_FOUND` after `npm i` → check `.bin` PATH or use `npx`
- `port already in use` → `lsof -i :PORT` then kill
- `EADDRINUSE` → previous process didn't exit, screen/tmux leftover
- `unexpected token` in import → CJS file importing ESM, change `.cjs` or `"type":"module"`

#### Python
- `ModuleNotFoundError` after pip install → wrong venv OR `pip` ≠ `python` venv → use `python -m pip`
- `SSL: CERTIFICATE_VERIFY_FAILED` → corp proxy or stale certs → `pip install --trusted-host pypi.org`
- `RecursionError` → real bug OR `sys.setrecursionlimit` needed (rare)

#### Telegram bot
- Duplicate responses → multiple instances running (`ps aux | grep node`) OR webhook + polling both active
- `409 Conflict` → another getUpdates poll running
- Bot stops responding silently → check for `polling_error` event handler, often unhandled rejection
- Markdown parse error → unescaped `_` `*` `[` characters

#### Web3
- `nonce too low` → race condition, use NonceManager
- `replacement transaction underpriced` → bumping gas <10% above stuck tx
- `insufficient funds for gas` → forgot gas cost, not just transfer value
- RPC timeout → switch endpoint, primary down
- `execution reverted` no reason → call `eth_call` first to simulate and get revert string
- `signer connected to provider` warnings → use `wallet.connect(provider)` then `contract.connect(wallet)`

#### VPS / Linux
- `Permission denied` on script → `chmod +x` OR shebang wrong OR running as wrong user
- `screen` session gone → server rebooted, use systemd instead for persistence
- Port not reachable externally → ufw or cloud firewall blocking
- `out of memory` killed → `dmesg | grep -i kill` confirms OOM, add swap or cap memory

#### MUSE specific
- Duplicate Telegram response → `streaming` config has invalid value, set proper boolean
- Provider auth fail → check both `ANTHROPIC_AUTH_TOKEN` and `ANTHROPIC_API_KEY`, conflict possible
- Skill not loading → wrong path in `~/muse-beta-1.0-agents.json`
- Tool call hangs → security guardrail blocking obfuscated bash, simplify command

### Fast output format
```
[ROOT CAUSE] → [specific 1-line]
[FIX]        → [exact commands]
[VERIFY]     → [exact verify command]
[HARDEN]     → [prevention, optional]
```

If 100% sure → execute fix style.
If <100% sure → give probable cause + diagnostic command to confirm BEFORE fix.

---

## PART B: SYSTEMATIC DEBUGGING & AUTO-DEBUG LOOP (from fault-diagnosis-resolution-systematic-debugging-merged)

Metode buat bug yang **gak ada di pustaka** — yang aneh, intermittent, atau dalam. Load saat fault-diagnosis-resolution-systematic-debugging §A mentok atau bug non-trivial.

### 4 fase (urut — jangan loncat ke Fix)

```
1. RCA        → Root Cause Analysis: reproduce → isolasi → cari akar, BUKAN gejala
2. PATTERN    → cocokin ke pola dikenal (fault-diagnosis-resolution-systematic-debugging §A library, error sebelumnya di memory/self-audit-system-refinement-self-improvement §B)
3. HYPOTHESIS → rumuskan dugaan yang TESTABLE, ranking by likelihood × cheapness-to-test
4. FIX        → uji hipotesis #1; benar → patch + regression test (agentic-eval-self-critique-2); salah → hipotesis #2
```

Anti-pattern fatal: langsung nebak fix tanpa reproduce. "Coba restart / tambah try-catch" tanpa tau akar = nutup gejala, bug balik lagi.

### Fase 1 — RCA

```
- Reproduce dulu. Gak bisa reproduce → kumpulkan kondisi (input, env, timing, state).
- Isolasi: bisect (komentari setengah / git bisect), minimal repro case.
- Tanya "kenapa" sampai akar: error X → karena Y → karena Z. Akar = Z, bukan X.
- Bukti, bukan tebakan: log, stack trace, state dump, KQL (m21), eth_call revert reason.
```

### Fase 2 — PATTERN

Cocokin ke yang udah dikenal sebelum mikir dari nol:
- Pustaka fault-diagnosis-resolution-systematic-debugging §A (nonce too low, RPC timeout, duplicate webhook, dll).
- Memory/self-audit-system-refinement-self-improvement §B — "error ini pernah ketemu?" (lesson reinforced).
- Gejala klasik: race (intermittent), off-by-one (boundary), stale cache (kadang benar kadang salah), env drift (jalan di lokal, gagal di prod).

### Fase 3 — HYPOTHESIS (inti auto-debug)

```python
from eval import variance   # reuse buat flaky bug
# Susun hipotesis sebagai pernyataan testable + cara uji termurah
hypotheses = [
  {"h":"RPC ankr rate-limit di burst", "test":"swap ke llamarpc, retry 20×", "cost":"low", "p":0.6},
  {"h":"nonce race antar wallet paralel", "test":"serialize 1 wallet, ulang", "cost":"low", "p":0.3},
  {"h":"gas estimate kurang saat spike", "test":"naikin buffer 2×, ulang", "cost":"med", "p":0.1},
]
# urut by p × (1/cost) → uji termurah-paling-mungkin dulu
```

Auto-debug loop:
```
WHILE bug belum terjelaskan:
  pick hipotesis dengan (likelihood × murah-diuji) tertinggi
  jalankan test → observasi
  konfirm → ke FIX
  bantah → buang, update prior hipotesis lain, lanjut
  semua habis → generate hipotesis baru dari bukti terbaru (jangan ngotot ke yang udah dibantah)
```

Untuk bug **intermittent**: pakai `variance()` (agentic-eval-self-critique-2) — jalanin N kali, lihat distribusi mode kegagalan. Bug yang 2/10 muncul = sinyal race/timing/rate-limit.

### Fase 4 — FIX

```
- Fix akar, bukan gejala. Kalau cuma bisa gejala → tandai + log alasannya (jangan diam).
- Tambah regression test (agentic-eval-self-critique-2 Eval) — bug yang sama gak boleh balik diam-diam.
- Reversible & operasional (RPC/retry/cache) → boleh auto-fix (self-audit-system-refinement-self-improvement §B SAFE_AUTO_ACTIONS).
- Nyentuh skill/dana/rail → proposal (frozen-paths), operator acc + re-lock.
- Catat ke memory (self-audit-system-refinement-self-improvement §B): gejala → akar → fix. Next time jadi entry fault-diagnosis-resolution-systematic-debugging §A.
```

### Output ke operator

```
🔬 fault-diagnosis-resolution-systematic-debugging mass-mint flaky (3/50 gagal "AlreadyMinted")
  RCA: gagal hanya di wallet yang udah mint epoch lalu — bukan bug, state on-chain
  HYP#1 (p .7): checker eligibility skip cache stale → CONFIRMED (cache 1h, mint 40m lalu)
  FIX: invalidate eligibility cache sebelum batch → regression test added (agentic-eval-self-critique-2)
  auto-fix? NO (logic skill m13) → 📝 proposal ditulis
```

---

## Which mode to use

| Bug type | Use |
|---|---|
| Common, well-known error with stack trace | fault-diagnosis-resolution-systematic-debugging §A (fast diagnosis) |
| Unusual, intermittent, no obvious cause | fault-diagnosis-resolution-systematic-debugging §B (systematic 4-fase) |
| fault-diagnosis-resolution-systematic-debugging §A mentok | escalate to fault-diagnosis-resolution-systematic-debugging §B |
| Fix found → needs hardening | fault-diagnosis-resolution-systematic-debugging §B Fase 4 |

Never "try this and see." Always ground recommendation in evidence.
