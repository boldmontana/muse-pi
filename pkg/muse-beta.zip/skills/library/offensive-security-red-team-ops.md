---
name: offensive-security-red-team-ops
description: "red team, pentest, offensive, exploit dev, post-exploit, C2, payload, phishing campaign, adversary"
when_to_use: "red team, pentest, offensive, exploit dev, post-exploit, C2, payload, phishing campaign, adversary"
source: muse-beta
---

# Offensive Security & Red-Team Ops

**Category:** Security

**Load when:** red team, pentest, offensive, exploit dev, post-exploit, C2, payload, phishing campaign, adversary
## ⛔ HARD RAIL — AUTHORIZED TARGETS ONLY

```
ABSOLUTE REQUIREMENT:
  - ALL operations require pre-authorized target scope
  - Target must be: owned by operator, OR explicitly authorized in writing
  - "Authorized" = written permission (email, signed doc, chat log) from target owner
  - NO EXCEPTIONS. Not even for "research" or "educational purposes."
  - Unauthorized targeting = skill refuses to execute, logs attempt, alerts operator

SCOPE DOCUMENT REQUIRED (before any offensive-security-red-team-ops operation):
  - target_identifier (IP, domain, contract address, wallet)
  - authorization_proof (permission document, ownership verification)
  - scope_limits (what's in-scope, what's out-of-scope)
  - timeframe (start/end for time-boxed engagements)
  - point_of_contact (for vulnerability disclosure)

Without valid scope document: offensive-security-red-team-ops refuses ALL execution.
This is not a suggestion. This is a hard rail. Period.
```

---

## TRIGGER KEYWORDS

### HIGH WEIGHT (3pt)
exploit, exploit development, red team, red-team, penetration testing,
C2, command and control, payload, payload generation, post-exploitation,
OPSEC, operational security, phishing, phishing infrastructure,
MITRE ATT&CK, ATT&CK mapping, offensive security

### MEDIUM WEIGHT (2pt)
vulnerability research, bug bounty, whitehat, shellcode, reverse shell,
privilege escalation, lateral movement, persistence, exfiltration,
reconnaissance, scanning, enumeration, metasploit, cobalt strike,
initial access, defense evasion, credential dumping

### LOW WEIGHT (1pt)
fuzzing, fuzzer, buffer overflow, ROP chain, shellcode generation,
domain fronting, redirector, payload obfuscation, AV evasion,
EDR bypass, living off the land, LOLBAS, misconfiguration scan

---

## OVERVIEW

offensive-security-red-team-ops is the offensive security and red-team operations module for MUSE BETA AGENT.
It covers the full exploit development lifecycle, C2 infrastructure patterns,
post-exploitation techniques, payload generation, OPSEC best practices,
MITRE ATT&CK mapping, red-team infrastructure deployment, and phishing
framework construction.

offensive-security-red-team-ops operates under the **HARD RAIL**: every operation requires explicit,
verifiable, pre-authorized target scope. This is non-negotiable.

---

## EXPLOIT DEVELOPMENT LIFECYCLE

### Phase 1 — Reconnaissance (MITRE TA0043)
```
Active Techniques:
  - Port scanning (nmap, masscan, rustscan)
  - Service enumeration (version detection, banner grabbing)
  - Web technology fingerprinting (Wappalyzer, WhatWeb, BuiltWith)
  - Subdomain enumeration (subfinder, amass, certificate transparency)
  - DNS enumeration (dnsrecon, zone transfer attempts)
  - Cloud asset discovery (cloud_enum, ScoutSuite)
  - API endpoint discovery (feroxbuster, ffuf, dirsearch)

Passive Techniques:
  - WHOIS lookup (historical + current)
  - Shodan / Censys / ZoomEye queries
  - GitHub dorking (secrets, configs, internal paths)
  - Wayback Machine (historical endpoints)
  - Social media OSINT (employee roles, tech stack hints)
  - Job posting analysis (revealed tech stack)
  - SSL certificate transparency logs

Output: Target profile document (attack surface map)
```

### Phase 2 — Vulnerability Discovery (MITRE TA0042)
```
Automated Scanning:
  - Web: Nuclei, Burp Suite (authenticated), ZAP, Nikto
  - Network: OpenVAS, Nessus (if licensed), NSE scripts
  - Cloud: Prowler, ScoutSuite, cloudsplaining
  - Container: Trivy, kube-hunter, kube-bench
  - Code: Semgrep, CodeQL, SonarQube (SAST)
  - Dependency: Snyk, OWASP Dependency Check (SCA)
  - API: Postman collection fuzzing, Swagger endpoint analysis

Manual Testing:
  - Business logic flaws (workflow bypass, race conditions)
  - Authentication/Authorization (JWT manipulation, IDOR, privilege escalation)
  - Input validation (SQLi, XSS, SSTI, SSRF, XXE, command injection)
  - Deserialization (Java, PHP, Python pickle, Node.js)
  - Cryptographic weaknesses (weak ciphers, hardcoded keys, padding oracle)

Chaining:
  - Low severity × N → high severity exploitation path
  - Document chain: vuln A enables vuln B enables full compromise
```

### Phase 3 — Exploit Development
```
Proof of Concept:
  1. Reproduce vulnerability in isolated test environment
  2. Develop minimal PoC (proves impact, minimal payload)
  3. Test against target (within scope only)
  4. Document: preconditions, steps, impact, remediation

Weaponization:
  1. Add reliability (retry logic, fallback methods)
  2. Add stealth (traffic obfuscation, timing randomization)
  3. Add persistence hooks (if within scope)
  4. Package as standalone script (Python/Bash/PowerShell)
  5. Test against multiple target configurations

Types of Exploits:
  - Web: SQLi → RCE, SSRF → metadata exfil, SSTI → shell, XXE → LFI
  - Network: Buffer overflow, format string, logic bypass
  - Binary: ROP chains, ret2libc, heap exploitation, format string
  - Crypto: Padding oracle, nonce reuse, weak random, hash length extension
  - Cloud: AssumeRole chaining, metadata exfil, storage misconfiguration
  - Container: Escape via socket mount, cap_sys_admin, cgroup breakout
  - Active Directory: Kerberoasting, AS-REP roasting, DCSync, NTLM relay
```

### Phase 4 — Delivery & Execution (MITRE TA0002)
```
Delivery Vectors:
  - Phishing email (spear, whaling, credential harvesting)
  - Watering hole attack
  - Malicious document (macro, DDE, OLE, formula injection)
  - USB drop (Rubber Ducky, Bash Bunny)
  - Supply chain compromise (dependency confusion, typosquatting)
  - Drive-by download (browser exploit, malvertising)
  - Physical access (explicit authorization required)

Payload Types:
  - Staged: small dropper → fetch full payload
  - Stageless: self-contained, larger on disk
  - Reflective: in-memory only, no disk footprint
  - Fileless: registry, WMI, scheduled task persistence

Initial Access Techniques:
  - Valid accounts (password spray, credential stuffing)
  - External remote services (RDP, SSH, VPN exploitation)
  - Public-facing application exploit (CVE exploitation)
  - Trusted relationship abuse (partner VPN, cloud federation)
```

### Phase 5 — Post-Exploitation
```
Objectives (scope-dependent):
  - Persistence (MITRE TA0003)
  - Privilege Escalation (MITRE TA0004)
  - Defense Evasion (MITRE TA0005)
  - Credential Access (MITRE TA0006)
  - Discovery (MITRE TA0007)
  - Lateral Movement (MITRE TA0008)
  - Collection (MITRE TA0009)
  - Exfiltration (MITRE TA0010)
  - Impact Assessment (MITRE TA0040)

Persistence Methods:
  - Scheduled tasks / cron jobs
  - Registry Run keys (Windows)
  - Systemd services / init scripts (Linux)
  - Web shells (PHP, JSP, ASPX)
  - SSH authorized keys
  - Cloud: IAM role, access key, federation backdoor
  - WMI event subscription
  - DLL side-loading / hijacking

Privilege Escalation:
  - Linux: SUDO misconfigurations, SUID binaries, capabilities, dirty pipe
  - Windows: UAC bypass, token manipulation, service permissions, PrintSpoofer
  - Cloud: IAM privilege escalation paths, AssumeRole chaining
  - Container: Docker socket access, privileged containers, host mounts
```

---

## C2 (COMMAND & CONTROL) PATTERNS

### C2 Architectures
```
1. DIRECT (simplest, most detectable)
   implant ↔ C2 server (TCP/HTTP/HTTPS/DNS)
   Use: lab testing, short engagements
   Tools: Metasploit, Empire, Covenant, Sliver

2. REDIRECTOR CHAIN (medium stealth)
   implant → redirector1 → redirector2 → C2 server
   Use: longer engagements, production red teams
   Tools: Apache/Nginx reverse proxy, Socat, SSH tunnels, Cloudflare CDN

3. PEER-TO-PEER (high stealth)
   implants communicate with each other, one egress point
   Use: air-gapped network bridging, long-term persistence
   Tools: custom P2P protocol, SMB named pipes, internal DNS

4. DOMAIN FRONTING (high stealth, high complexity)
   implant → CDN (Cloudflare/Fastly/AWS CloudFront) → C2
   Use: bypassing network monitoring, blocked C2 domains
   Tools: Cobalt Strike Malleable C2, custom fronting profiles

5. SOCIAL MEDIA / CLOUD C2 (emerging pattern)
   implant ↔ Twitter/Discord/GitHub/GDrive/Notion → C2 operator
   Use: blending into normal traffic, hard to block
   Tools: custom API-based channels, dead drop resolvers
```

### C2 Communication Profiles
```
HTTPS (most common):
  - Mimics legitimate web traffic (e.g., GET /api/status HTTP/1.1)
  - Domain fronting compatible
  - TLS certificate generation (Let's Encrypt automation)
  - Malleable C2 profiles (Cobalt Strike)

DNS:
  - TXT/MX/CNAME record tunneling
  - Low bandwidth (sufficient for commands, not file exfil)
  - Bypasses most firewalls (DNS often unfiltered)
  - Detection: unusual DNS query patterns, large TXT records

HTTP/3 (QUIC):
  - Emerging, less inspected by security tools
  - Bypasses HTTP/2-specific inspection
  - Limited tool support (custom required)

WebSocket:
  - Long-lived, bidirectional
  - Blends with modern web apps
  - Harder to detect than polling-based HTTP C2

ICMP:
  - ICMP tunneling (ptunnel, icmpsh)
  - Very low bandwidth, highly suspicious if monitored
  - Use: last-resort when all TCP/UDP blocked
```

### C2 Infrastructure Deployment
```
Automated deployment pipeline:
  1. Terraform/Pulumi: provision VPS, DNS, CDN
  2. Ansible: configure redirectors, deploy C2 framework
  3. Certbot: auto-TLS with Let's Encrypt
  4. Docker: containerized C2 + redirectors
  5. Monitoring: uptime, bandwidth, implant check-in rate

Provider rotation:
  - DigitalOcean, Vultr, Linode, AWS Lightsail, Azure, GCP
  - Rotate every N days (configurable)
  - Pre-warm redirector domains (age domains before use)

Hardening:
  - C2 server: IP whitelist (only redirector IPs can reach)
  - Redirectors: DDoS protection, CDN
  - Logs: minimal retention, encrypted at rest
  - Kill-switch: auto-destroy on detection signal
```

---

## PAYLOAD GENERATION

### Payload Pipeline
```
INPUT: target profile (OS, arch, AV/EDR, network egress)
  ↓
SELECT: payload type (staged/stageless, language)
  ↓
GENERATE: shellcode/payload from template
  ↓
OBFUSCATE: encode, encrypt, pack
  ↓
TEST: against local detection (Defender, ClamAV, YARA)
  ↓
DELIVER: execute on target (within scope)

Supported Payload Types:
  - Windows: .exe, .dll, .ps1, .vbs, .hta, .msi, .lnk
  - Linux: ELF binary, .so shared object, .py, .sh, .pl
  - macOS: Mach-O, .app bundle, .pkg, .scpt (AppleScript)
  - Cross-platform: Python, Go, Rust, JavaScript (Node.js)
  - Web: PHP webshell, JSP, ASPX, CFM
  - Mobile: Android APK (if scope includes mobile)
```

### Obfuscation & Evasion Techniques
```
Code-Level:
  - String encryption (XOR, AES, RC4)
  - Control flow flattening
  - Dead code insertion
  - API hashing (resolve at runtime, not import table)
  - Syscall stubs (direct syscalls, bypass userland hooks)
  - Reflective DLL injection (no LoadLibrary)
  - Process hollowing / process doppelganging
  - ETW patching (disable Event Tracing for Windows)

Binary-Level:
  - Packer/compressor (UPX → custom packer)
  - Entry point obfuscation
  - Import address table (IAT) camouflage
  - Section manipulation
  - Code signing (stolen/valid certificates — operator risk)
  - Binary padding

Network-Level:
  - Traffic mimicry (HTTPS to CDN endpoints)
  - Chunked transfer encoding
  - Base64/hex encoding
  - Custom encryption (avoid standard TLS fingerprints)
  - Jitter (random sleep between beacons)
  - Domain rotation (DGA — Domain Generation Algorithm)

Testing Pipeline:
  1. VirusTotal (private upload) — scan score
  2. AntiScan.Me — detection rate
  3. Local VM: Defender + common AV
  4. YARA scanning against known rules
  5. EDR simulation (if EDR profile available)
```

---

## OPSEC (OPERATIONAL SECURITY)

### Pre-Engagement OPSEC
```
Identity:
  - Use burner infrastructure (no personal accounts)
  - VPN/proxy chain for all recon traffic
  - No personal devices on engagement network
  - Separate browser profile for engagement research

Infrastructure:
  - Domain privacy (WHOIS guard)
  - CDN fronting (hide origin server)
  - No cross-contamination between engagements
  - Separate email, domains, VPS per engagement
  - Payment: crypto for infra, no personal cards

Credentials:
  - No password reuse across engagements
  - Password manager per engagement
  - No operator personally identifiable information (PII) in payloads
```

### During-Engagement OPSEC
```
Network:
  - Rate limit scanning (avoid IDS triggers)
  - Randomize timing (jitter between requests)
  - Respect robots.txt (optional, depends on scope)
  - Use target's own IP ranges when possible (cloud metadata)

Artifacts:
  - Clean up payloads after use
  - Remove persistence mechanisms on engagement end
  - Log all changes for rollback
  - Securely delete all collected data post-engagement

Communication:
  - Separate comms channel from target's infrastructure
  - Encrypted channels for team communication (Signal, Matrix)
  - No discussion of engagement on personal devices/channels
```

### Post-Engagement OPSEC
```
Data Handling:
  - Encrypt all collected data at rest
  - Delete raw data after report delivery (unless retention specified)
  - Secure report delivery (encrypted, authenticated)
  - Report redacted of unnecessary operator-specific details

Cleanup:
  - Destroy engagement VPS/domains
  - Rotate any compromised credentials (target-side)
  - Remove backdoors, accounts, persistence
  - Verify cleanup with target administrator

Retention:
  - Report: retained per agreement (typically 1 year)
  - Raw data: deleted within 30 days
  - Logs: minimal retention for legal protection only
```

---

## MITRE ATT&CK MAPPING

### Tactics Covered by offensive-security-red-team-ops
```
TA0043 — Reconnaissance
  T1595: Active Scanning
  T1592: Gather Victim Host Information
  T1590: Gather Victim Network Information
  T1589: Gather Victim Identity Information

TA0001 — Initial Access
  T1190: Exploit Public-Facing Application
  T1566: Phishing
  T1078: Valid Accounts
  T1199: Trusted Relationship

TA0002 — Execution
  T1059: Command and Scripting Interpreter
  T1203: Exploitation for Client Execution
  T1204: User Execution
  T1053: Scheduled Task/Job

TA0003 — Persistence
  T1543: Create or Modify System Process
  T1547: Boot or Logon Autostart Execution
  T1546: Event Triggered Execution
  T1505: Server Software Component (Web Shell)
  T1098: Account Manipulation

TA0004 — Privilege Escalation
  T1068: Exploitation for Privilege Escalation
  T1134: Access Token Manipulation
  T1548: Abuse Elevation Control Mechanism

TA0005 — Defense Evasion
  T1027: Obfuscated Files or Information
  T1055: Process Injection
  T1070: Indicator Removal
  T1562: Impair Defenses
  T1550: Use Alternate Authentication Material

TA0006 — Credential Access
  T1003: OS Credential Dumping
  T1555: Credentials from Password Stores
  T1110: Brute Force
  T1558: Steal or Forge Kerberos Tickets

TA0007 — Discovery
  T1082: System Information Discovery
  T1083: File and Directory Discovery
  T1046: Network Service Discovery
  T1069: Permission Groups Discovery

TA0008 — Lateral Movement
  T1021: Remote Services
  T1550: Use Alternate Authentication Material
  T1210: Exploitation of Remote Services

TA0009 — Collection
  T1005: Data from Local System
  T1114: Email Collection
  T1074: Data Staged

TA0010 — Exfiltration
  T1041: Exfiltration Over C2 Channel
  T1048: Exfiltration Over Alternative Protocol

TA0040 — Impact
  T1490: Inhibit System Recovery
  T1485: Data Destruction (ONLY for authorized destructive testing)
```

### Automated ATT&CK Annotation
```
After every offensive-security-red-team-ops operation:
  1. Auto-tag actions with MITRE technique IDs
  2. Generate coverage heatmap (techniques used vs available)
  3. Gap analysis (techniques NOT tested → blind spots)
  4. Report-ready ATT&CK matrix in PDF/HTML

Command: /offensive-security-red-team-ops attck report [engagement_id]
Output: Complete ATT&CK Navigator JSON layer + PDF visualization
```

---

## RED-TEAM INFRASTRUCTURE

### Automated Infrastructure Deployment
```
Terraform Blueprint:
  - C2 server (small VPS, hardened)
  - N redirectors (CDN-fronted, geographically distributed)
  - Phishing server (GoPhish/Evilginx container)
  - Log aggregation server (ELK/Graylog, encrypted)
  - Build server (payload generation, isolated from C2)
  - Team VPN server (WireGuard, operator access only)

Deploy command: /offensive-security-red-team-ops infra deploy [blueprint_name]
Tear-down: /offensive-security-red-team-ops infra destroy [engagement_id]
```

### Infrastructure Components
```
Component          | Tool Options                          | Purpose
───────────────────|───────────────────────────────────────|────────────────────
C2 Framework       | Sliver, Havoc, Mythic, Covenant       | Implant management
Phishing           | GoPhish, Evilginx, EvilGophish        | Campaign management
Redirectors        | Nginx, Apache, Socat, HAProxy         | Traffic obfuscation
CDN Fronting       | Cloudflare, Fastly, AWS CloudFront    | Domain masking
Payload Gen        | Docker container with build tools     | Isolated compilation
Logging            | Elasticsearch, Graylog, Loki          | Centralized logs
Team VPN           | WireGuard, Nebula, Tailscale          | Secure team access
Collaboration      | VECTR, Ghostwriter, Dradis            | Engagement tracking
```

---

## PHISHING FRAMEWORKS

### Phishing Campaign Automation
```
1. Template Engine
   - HTML email templates (responsive, realistic)
   - Landing page clones (login portals, SSO pages)
   - Document templates (invoice, HR, IT notifications)

2. Target Management
   - CSV import (email, name, role, department)
   - Group segmentation (by department, seniority, tech-savviness)
   - Staggered sending (avoid spam detection, appear organic)

3. Payload Integration
   - Attachment: malicious doc, ISO, ZIP with shortcut
   - Link: credential harvesting, drive-by download, MFA relay
   - QR code phishing (quishing)
   - SMS phishing (smishing) — if scope includes
   - Voice phishing (vishing) landing page — if scope includes

4. Campaign Tracking
   - Email opened (tracking pixel — privacy consideration)
   - Link clicked (timestamp, IP, user-agent)
   - Credential submitted (username, password, MFA code)
   - Payload executed (implant check-in)
   - Success rate per template / per segment

5. MFA Bypass (if within scope)
   - Evilginx-style transparent proxy (session cookie capture)
   - MFA fatigue / push notification bombing
   - SIM swap awareness (out of scope, flag to target)

6. Post-Phishing
   - Auto-generate report: delivery rate, open rate, click rate, credential rate
   - Recommendations: awareness training targets, technical controls
```

### Phishing Safety Rails
```
- Sending domain: spoof-proofed (SPF/DKIM/DMARC properly configured)
- Recipient consent: explicit authorization from target organization
- NO real credential storage: credentials captured → encrypted → auto-deleted after report
- NO production impact: link to test/staging portal, not production login
- Landing page: clearly labeled as "security test" after credential entry
- Campaign kill-switch: instant takedown if any issue reported
```

---

## VULNERABILITY DISCLOSURE WORKFLOW

```
1. DISCOVER: vulnerability found during authorized engagement
2. DOCUMENT: full write-up with reproduction steps, impact, remediation
3. ENCRYPT: report encrypted with target's PGP key
4. DELIVER: to point-of-contact via agreed channel
5. TIMELINE:
   - Day 0:     Report delivered
   - Day 7:     Follow-up if no response
   - Day 14:    Escalate to secondary contact
   - Day 30:    Final notice before disclosure (if coordinated disclosure agreed)
6. RETEST: verify fix after target confirms remediation
7. CLOSE: document lessons learned, update detection rules
```

---

## TOOLS USED

| Tool | Purpose |
|------|---------|
| nmap, masscan, rustscan | Port scanning |
| Burp Suite, ZAP | Web application testing |
| Metasploit, Sliver, Havoc | C2 + exploitation |
| GoPhish, Evilginx | Phishing campaigns |
| Nuclei, Semgrep | Automated vulnerability scanning |
| Terraform, Ansible | Infrastructure deployment |
| WireGuard | Secure team communication |
| Docker | Isolated build environments |
| PostgreSQL | Engagement tracking, vulnerability database |
| ELK/Graylog | Centralized logging |
| Shodan, Censys API | Passive reconnaissance |
| enterprise-defensive-ops (Enterprise Defense) | Defensive counterpoint — pair for blue/red exercises |
| team-orchestration-multi-user-ops (Team Ops) | Multi-operator red team coordination |

---

## SAFETY RAILS

1. ⛔ **HARD RAIL — AUTHORIZED TARGETS ONLY** (see top of document)
2. **Scope enforcement**: Every action validated against scope document before execution
3. **No destructive testing without explicit authorization** (even within scope)
4. **Data handling**: All collected data encrypted at rest + in transit
5. **Cleanup mandatory**: All persistence/backdoors removed post-engagement
6. **Audit trail**: Every offensive action logged with timestamp + justification
7. **OpSec enforcement**: Separate infra per engagement, no cross-contamination
8. **Kill-switch**: Every implant has kill command; master kill-switch per engagement
9. **No production impact**: Phishing uses test/staging replicas, not production
10. **Legal compliance**: Operator is responsible for ensuring jurisdiction legality
11. **Third-party impact**: Flag if attack path traverses third-party infrastructure
12. **Persistent logging**: All offensive-security-red-team-ops activity logged immutably for legal protection

---

## DELEGATION INFO

```
offensive-security-red-team-ops sub-agents:
  - Recon scanner: long-running periodic recon (subdomain, port, vuln scan)
  - Phishing campaign manager: template + target list → campaign execution
  - Exploit validator: isolated sandbox for PoC testing
  - ATT&CK annotator: auto-tags operations with MITRE techniques
  - Report generator: compiles findings into structured report

Cross-skill delegation:
  - Vulnerability found in web app → delegate CTF-style exploitation to ctf-web-exploitation (web CTF)
  - Binary exploit needed → delegate to ctf-binary-exploitation-pwn (pwn CTF)
  - Cryptographic weakness → delegate to ctf-cryptography (crypto CTF)
  - Forensics investigation → delegate to ctf-forensics-stego (forensics CTF)
  - Bug bounty program discovered → delegate to ctf-whitehat-toolkit (CTF/bug bounty)
  - AI/LLM system testing → delegate to ctf-prompt-injection-llm-red-team (CTF prompt injection)
```

---

## ENGAGEMENT LIFECYCLE COMMANDS

```
/offensive-security-red-team-ops scope create [file]          → create new scope document
/offensive-security-red-team-ops scope validate               → verify scope is valid
/offensive-security-red-team-ops recon start                  → begin reconnaissance phase
/offensive-security-red-team-ops recon report                 → reconnaissance findings
/offensive-security-red-team-ops vuln scan [type]             → run vulnerability scan
/offensive-security-red-team-ops exploit dev [vuln_id]        → develop exploit for vulnerability
/offensive-security-red-team-ops payload gen [target_profile] → generate payload
/offensive-security-red-team-ops c2 deploy [blueprint]        → deploy C2 infrastructure
/offensive-security-red-team-ops phish campaign [template] [targets] → launch phishing campaign
/offensive-security-red-team-ops post [implant_id] [action]   → post-exploitation action
/offensive-security-red-team-ops cleanup [engagement_id]      → remove all artifacts
/offensive-security-red-team-ops report [engagement_id]       → generate final report
/offensive-security-red-team-ops attck report [engagement_id] → MITRE ATT&CK coverage report
/offensive-security-red-team-ops infra deploy [blueprint]     → deploy red-team infrastructure
/offensive-security-red-team-ops infra destroy [engagement_id] → tear down all infrastructure
/offensive-security-red-team-ops kill switch [engagement_id]  → emergency kill all implants
```

---

## CONFIGURATION REFERENCE

```yaml
offensive_security:
  hard_rail:
    require_scope_document: true  # CANNOT BE DISABLED
    scope_validation: strict      # strict | lenient (NOT recommended)
    unauthorized_attempt_action: "log_and_refuse"  # CANNOT BE CHANGED
    audit_log_retention_days: 365
  
  recon:
    max_scan_rate: 1000           # packets/second max
    respect_robots_txt: true
    passive_only_by_default: true
    shodan_api_key: "${SHODAN_API_KEY}"
  
  exploitation:
    exploit_sandbox: "docker"     # docker | vm | isolated
    max_concurrent_exploits: 5
    require_simulation_first: true
    auto_cleanup_on_completion: true
  
  c2:
    frameworks: ["sliver", "havoc", "mythic"]
    default_c2_profile: "https_malleable"
    domain_fronting_providers: ["cloudflare"]
    redirector_count: 3
    implant_kill_switch_timeout_hours: 72
  
  phishing:
    max_emails_per_hour: 50
    require_landing_page_notice: true
    no_credential_storage: true
    campaign_safety_check: true
  
  cleanup:
    verify_with_target_admin: true
    auto_cleanup_timer_hours: 168  # 7 days
    cleanup_checklist:
      - remove_persistence
      - remove_accounts
      - remove_backdoors
      - wipe_collected_data
      - verify_cleanup
```

---

## VERSION

1.0.0 — 2026-07-08 — Initial release for MUSE BETA AGENT
