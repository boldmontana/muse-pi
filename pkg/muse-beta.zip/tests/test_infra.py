"""Infrastructure tests: guard, cron, memory, queue, pack, fetch, health, jobs."""

import http.server
import os
import tempfile
import threading
import time
import unittest
from datetime import datetime, timezone

from muse import fetch, guard, health, jobs, memory, pack, runner, schedule


class GuardTest(unittest.TestCase):
    def test_redacts_private_key(self):
        out = guard.redact("0x" + "ab" * 32)
        self.assertIn("…", out)
        self.assertLess(len(out), 66)
        self.assertTrue(out.startswith("0xababab"))

    def test_redacts_cookies_and_bearer(self):
        out = guard.redact("auth_token=abcdefghijkl ct0=zzzzzzzz Bearer ABCDEFGH")
        self.assertNotIn("abcdefghijkl", out)
        self.assertNotIn("ABCDEFGH", out)

    def test_redacts_url_credentials(self):
        out = guard.redact("https://base.example/v1/abc?api_key=SECRET123&x=1")
        self.assertNotIn("SECRET123", out)
        self.assertIn("api_key=…", out)

    def test_redacts_email(self):
        self.assertEqual(guard.redact("mail me at alice.w@corp.io"), "mail me at a***@corp.io")

    def test_assert_inside(self):
        with tempfile.TemporaryDirectory() as root:
            self.assertTrue(guard.assert_inside(os.path.join(root, "a", "b"), root))
            with self.assertRaises(ValueError):
                guard.assert_inside(os.path.join(root, "..", "elsewhere"), root)

    def test_sensitive_names(self):
        self.assertTrue(guard.is_sensitive("state/vault.json"))
        self.assertFalse(guard.is_sensitive("README.md"))


class CronTest(unittest.TestCase):
    def test_step(self):
        cron = schedule.Cron("*/15 * * * *")
        moment = datetime(2026, 10, 30, 9, 30, tzinfo=timezone.utc)
        self.assertTrue(cron.matches(moment))
        self.assertFalse(cron.matches(moment.replace(minute=31)))

    def test_names_and_range(self):
        cron = schedule.Cron("0 9-17 * * mon-fri")
        self.assertTrue(cron.matches(datetime(2026, 10, 30, 9, 0, tzinfo=timezone.utc)))  # Friday
        self.assertFalse(cron.matches(datetime(2026, 10, 31, 9, 0, tzinfo=timezone.utc)))  # Saturday

    def test_next_after(self):
        cron = schedule.Cron("0 12 * * *")
        nxt = cron.next_after(datetime(2026, 10, 30, 13, 0, tzinfo=timezone.utc))
        self.assertEqual((nxt.day, nxt.hour), (31, 12))

    def test_bad_expressions(self):
        for bad in ("* * * *", "60 * * * *", "*/0 * * * *", "5-1 * * * *", "x * * * *"):
            with self.assertRaises(schedule.CronError):
                schedule.Cron(bad)

    def test_store_tick_once_per_minute(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = schedule.Store(os.path.join(tmp, "s.db"))
            store.add("* * * * *", "noop", {"a": 1})
            now = datetime(2026, 10, 30, 9, 30, 5, tzinfo=timezone.utc).timestamp()
            self.assertEqual(len(store.tick(now)), 1)
            self.assertEqual(len(store.tick(now + 10)), 0)
            self.assertEqual(len(store.tick(now + 61)), 1)
            store.close()

    def test_store_rejects_bad_cron(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = schedule.Store(os.path.join(tmp, "s.db"))
            with self.assertRaises(schedule.CronError):
                store.add("nope", "noop", {})
            store.close()


class MemoryTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.mem = memory.Memory(os.path.join(self.tmp.name, "m.db"))

    def tearDown(self):
        self.mem.db.close()
        self.tmp.cleanup()

    def test_add_and_search(self):
        self.mem.add("tcache safe-linking", "fd = target ^ (chunk >> 12)", "finding", "pwn")
        hits = self.mem.search("safe-linking")
        self.assertEqual(len(hits), 1)
        self.assertEqual(hits[0]["kind"], "finding")

    def test_tags_accept_list_and_empty_search_lists_recent(self):
        self.mem.add("tp wallet", "x", "finding", ["wallet", "tron"])
        self.assertEqual(self.mem.get(1)["tags"], "wallet tron")
        self.assertEqual(len(self.mem.search("")), 1)

    def test_search_multiple_terms(self):
        self.mem.add("offset 72", "cyclic", "finding")
        self.assertEqual(len(self.mem.search("offset cyclic")), 1)
        self.assertEqual(self.mem.search("offset missing"), [])

    def test_kind_validation(self):
        with self.assertRaises(ValueError):
            self.mem.add("x", kind="banana")
        with self.assertRaises(ValueError):
            self.mem.add("   ")

    def test_prune_keeps_findings(self):
        old = self.mem.add("old note", "body", "note")
        self.mem.add("old finding", "body", "finding")
        self.mem.db.execute("UPDATE notes SET ts=0")
        self.mem.db.commit()
        self.assertEqual(self.mem.prune(30), 1)
        self.assertFalse(self.mem.get(old))

    def test_get_and_delete(self):
        note_id = self.mem.add("t", "body")
        self.assertEqual(self.mem.get(note_id)["body"], "body")
        self.assertTrue(self.mem.delete(note_id))
        self.assertIsNone(self.mem.get(note_id))
        self.assertEqual(self.mem.stats(), {})


class QueueTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.queue = runner.Queue(os.path.join(self.tmp.name, "j.db"))

    def tearDown(self):
        self.queue.db.close()
        self.tmp.cleanup()

    def test_priority_order(self):
        low = self.queue.add("noop", priority=8)
        high = self.queue.add("noop", priority=2)
        self.assertEqual(self.queue.claim()["id"], high)
        self.assertEqual(self.queue.claim()["id"], low)

    def test_backoff_then_fail(self):
        job_id = self.queue.add("noop", max_attempts=2)
        self.queue.claim()
        self.assertEqual(self.queue.finish(job_id, False, error="boom", retry_after=0), "retry")
        row = self.queue.db.execute("SELECT status, run_after FROM jobs WHERE id=?", (job_id,)).fetchone()
        self.assertEqual(row[0], "queued")
        self.assertGreater(row[1], time.time())
        self.queue.db.execute("UPDATE jobs SET run_after=0 WHERE id=?", (job_id,))
        self.queue.claim()
        self.assertEqual(self.queue.finish(job_id, False, error="boom"), "failed")

    def test_cancel_only_queued(self):
        job_id = self.queue.add("noop")
        self.assertTrue(self.queue.cancel(job_id))
        self.assertFalse(self.queue.cancel(job_id))

    def test_recover_requeues_running(self):
        self.queue.add("noop")
        self.queue.claim()
        self.assertEqual(self.queue.recover(), 1)
        self.assertEqual(self.queue.stats()["queued"], 1)

    def test_two_workers_do_not_claim_the_same_job(self):
        path = os.path.join(self.tmp.name, "shared.db")
        first, second = runner.Queue(path), runner.Queue(path)
        job = first.add("noop", {})
        a = first.claim()
        b = second.claim()
        self.assertEqual(a["id"], job)
        self.assertIsNone(b)
        self.assertEqual(first.list()[0]["attempts"], 1)

    def test_run_after_blocks_claim(self):
        self.queue.add("noop", run_after=60)
        self.assertIsNone(self.queue.claim())


class JobsTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.queue = runner.Queue(os.path.join(self.tmp.name, "j.db"))
        self.ctx = {"root": os.getcwd(), "home": self.tmp.name}

    def tearDown(self):
        self.queue.db.close()
        self.tmp.cleanup()

    def test_noop_runs(self):
        self.queue.add("noop", {"a": 1})
        results = jobs.drain(self.queue, self.ctx)
        self.assertEqual(results[0]["state"], "done")

    def test_unknown_kind_fails(self):
        self.queue.add("nope")
        results = jobs.drain(self.queue, self.ctx)
        self.assertEqual(results[0]["state"], "failed")
        self.assertIn("unknown job kind", results[0]["error"])

    def test_health_job(self):
        self.queue.add("health", {"network": False})
        results = jobs.drain(self.queue, self.ctx)
        self.assertEqual(results[0]["state"], "done")
        self.assertTrue(os.path.exists(os.path.join(self.tmp.name, "memory.db")))


class _Handler(http.server.BaseHTTPRequestHandler):
    payload = b"<html><head><style>x{}</style></head><body><h1>Hi</h1><p>text</p></body></html>"

    def do_GET(self):
        if self.path.startswith("/missing"):
            self.send_response(404)
            self.send_header("content-length", "0")
            self.end_headers()
            return
        self.send_response(200)
        self.send_header("content-type", "text/html; charset=utf-8")
        self.send_header("content-length", str(len(self.payload)))
        self.end_headers()
        self.wfile.write(self.payload)

    def log_message(self, *args):
        pass


class FetchTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = http.server.HTTPServer(("127.0.0.1", 0), _Handler)
        cls.port = cls.server.server_address[1]
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmp.cleanup()

    def test_extracts_text_and_caches(self):
        url = f"http://127.0.0.1:{self.port}/a"
        first = fetch.fetch(url, self.tmp.name)
        self.assertIn("Hi", first["text"])
        self.assertNotIn("<h1>", first["text"])
        self.assertNotIn("x{}", first["text"])
        second = fetch.fetch(url, self.tmp.name)
        self.assertTrue(second["cached"])
        self.assertEqual(second["bytes"], first["bytes"])

    def test_bad_scheme(self):
        with self.assertRaises(fetch.FetchError):
            fetch.fetch("ftp://example.test/x")

    def test_http_error(self):
        with self.assertRaises(fetch.FetchError):
            fetch.fetch(f"http://127.0.0.1:{self.port}/missing")


class PackTest(unittest.TestCase):
    def test_deterministic_and_excludes(self):
        with tempfile.TemporaryDirectory() as root:
            os.makedirs(os.path.join(root, "pkg"))
            open(os.path.join(root, "pkg", "a.py"), "w").write("x = 1\n")
            open(os.path.join(root, "README.md"), "w").write("hi\n")
            os.makedirs(os.path.join(root, "state"))
            open(os.path.join(root, "state", "vault.json"), "w").write("{}")
            os.makedirs(os.path.join(root, "__pycache__"))
            open(os.path.join(root, "__pycache__", "a.pyc"), "w").write("junk")
            one = pack.build(root, os.path.join(root, "dist", "one.zip"), "1.0")
            two = pack.build(root, os.path.join(root, "dist", "two.zip"), "1.0")
            self.assertEqual(one["sha256"], two["sha256"])
            self.assertNotIn("state/vault.json", pack.collect(root))
            self.assertTrue(os.path.exists(one["path"] + ".sha256"))

    def test_generated_manifest_is_not_collected_twice(self):
        with tempfile.TemporaryDirectory() as root:
            open(os.path.join(root, "MANIFEST.sha256.txt"), "w").write("stale\n")
            open(os.path.join(root, "a.md"), "w").write("x")
            self.assertNotIn("MANIFEST.sha256.txt", pack.collect(root))
            info = pack.build(root, os.path.join(root, "dist", "x.zip"), "1.0")
            import zipfile
            with zipfile.ZipFile(info["path"]) as archive:
                self.assertEqual(archive.namelist().count("MANIFEST.sha256.txt"), 1)

    def test_preserves_executable_bit(self):
        with tempfile.TemporaryDirectory() as root:
            script = os.path.join(root, "run.sh")
            open(script, "w").write("#!/bin/sh\n")
            os.chmod(script, 0o755)
            info = pack.build(root, os.path.join(root, "dist", "x.zip"), "1.0")
            import zipfile
            with zipfile.ZipFile(info["path"]) as archive:
                mode = archive.getinfo("run.sh").external_attr >> 16
            self.assertEqual(mode & 0o111, 0o111)


class HealthTest(unittest.TestCase):
    def test_pin_and_drift(self):
        with tempfile.TemporaryDirectory() as root, tempfile.TemporaryDirectory() as home:
            open(os.path.join(root, "SOUL.md"), "w").write("charter v1\n")
            first = health.charter_check(root, home)
            self.assertEqual(first["status"], "ok")
            open(os.path.join(root, "SOUL.md"), "w").write("charter v2\n")
            second = health.charter_check(root, home)
            self.assertEqual(second["status"], "warn")
            health.repin(root, home)
            self.assertEqual(health.charter_check(root, home)["status"], "ok")

    def test_summary_and_render(self):
        checks = [{"check": "a", "status": "ok", "detail": "x"},
                  {"check": "bb", "status": "fail", "detail": "y"}]
        self.assertEqual(health.summarize(checks), {"ok": 1, "warn": 0, "fail": 1, "info": 0})
        self.assertIn("FAIL", health.render(checks))

    def test_vault_mode(self):
        with tempfile.TemporaryDirectory() as home:
            open(os.path.join(home, "vault.json"), "w").write("{}")
            self.assertEqual(health.vault_check(home)["status"], "fail")
            os.chmod(os.path.join(home, "vault.json"), 0o600)
            self.assertEqual(health.vault_check(home)["status"], "ok")


if __name__ == "__main__":
    unittest.main()
