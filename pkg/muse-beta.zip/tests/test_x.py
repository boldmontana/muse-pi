"""Offline tests for the X driver: ledger, pool, reports, ops with a stub session."""

import os
import tempfile
import unittest
from unittest import mock

from muse import x


class LedgerTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger = x.Ledger(os.path.join(self.tmp.name, "a.db"))

    def tearDown(self):
        self.ledger.db.close()
        self.tmp.cleanup()

    def test_dedupe(self):
        self.assertFalse(self.ledger.seen("follow", "acc", "42"))
        self.ledger.record("follow", "acc", "42", "someone")
        self.assertTrue(self.ledger.seen("follow", "acc", "42"))

    def test_scoped_per_account(self):
        self.ledger.record("follow", "acc1", "42")
        self.assertFalse(self.ledger.seen("follow", "acc2", "42"))

    def test_count_today(self):
        self.ledger.record("like", "acc", "1")
        self.ledger.record("like", "acc", "2")
        self.assertEqual(self.ledger.count_today("like", "acc"), 2)

    def test_history(self):
        self.ledger.record("comment", "acc", "9", "target", "hi")
        rows = self.ledger.history(5)
        self.assertEqual(rows[0][0], "comment")
        self.assertEqual(rows[0][3], 1)


class PoolTest(unittest.TestCase):
    def test_round_robin_by_readiness(self):
        pool = x.Pool([x.Account("a", "t", "c"), x.Account("b", "t", "c")], min_gap=0.2, max_gap=0.2)
        first = pool.next()
        pool.pace(first)
        second = pool.next()
        self.assertNotEqual(first.key, second.key)

    def test_empty_allowed(self):
        self.assertEqual(x.Pool([]).accounts, [])

    def test_load_and_save(self):
        tmp = tempfile.TemporaryDirectory()
        path = os.path.join(tmp.name, "acc.json")
        pool = x.Pool([x.Account("a", "tok", "ct0")])
        pool.save(path)
        self.assertEqual(oct(os.stat(path).st_mode & 0o777), "0o600")
        again = x.Pool.load(path)
        self.assertEqual(again.accounts[0].ct0, "ct0")
        tmp.cleanup()


class StubSession:
    users = {"alice": {"id_str": "1", "screen_name": "alice"},
             "bob": {"id_str": "2", "screen_name": "bob"}}
    calls = []

    def __init__(self, account, timeout=25.0):
        self.account = account

    def user(self, name):
        if name not in self.users:
            raise x.XError("nope", 404)
        return self.users[name]

    def follow(self, user_id):
        self.calls.append(("follow", user_id))

    def like(self, tweet_id):
        self.calls.append(("like", tweet_id))

    def reply(self, text, tweet_id):
        self.calls.append(("reply", tweet_id))

    def timeline(self, name, count=20):
        return [{"id_str": "10", "full_text": "a" * 80},
                {"id_str": "11", "full_text": "b" * 80}]


class OpsTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.ledger = x.Ledger(os.path.join(self.tmp.name, "a.db"))
        self.pool = x.Pool([x.Account("me", "t", "c")], min_gap=0, max_gap=0)
        self.patch = mock.patch.object(x, "Session", StubSession)
        self.patch.start()
        StubSession.calls = []

    def tearDown(self):
        self.patch.stop()
        self.ledger.db.close()
        self.tmp.cleanup()

    def test_follow_and_skip_duplicate(self):
        first = x.follow_targets(self.pool, self.ledger, ["alice"], pause=False)
        self.assertEqual(first.acted, 1)
        second = x.follow_targets(self.pool, self.ledger, ["alice"], pause=False)
        self.assertEqual(second.skipped, 1)

    def test_follow_unknown(self):
        report = x.follow_targets(self.pool, self.ledger, ["nobody"], pause=False)
        self.assertEqual(report.failed, 1)
        self.assertIn("nobody", report.lines[0])

    def test_dry_run_records_nothing(self):
        report = x.follow_targets(self.pool, self.ledger, ["bob"], dry_run=True, pause=False)
        self.assertEqual(report.acted, 1)
        self.assertFalse(self.ledger.seen("follow", "me", "2"))
        self.assertEqual(StubSession.calls, [])

    def test_like_respects_dedupe(self):
        first = x.like_recent(self.pool, self.ledger, "alice", count=2, min_length=10)
        self.assertEqual(first.acted, 2)
        second = x.like_recent(self.pool, self.ledger, "alice", count=2, min_length=10)
        self.assertEqual(second.acted, 0)

    def test_comment_uses_rotating_template(self):
        report = x.comment(self.pool, self.ledger, "alice", ["hi {author}", "yo {author}"], count=2)
        self.assertEqual(report.acted, 2)
        self.assertIn("hi alice", report.lines[0])
        self.assertIn("yo alice", report.lines[1])

    def test_cap_applies(self):
        report = x.follow_targets(self.pool, self.ledger, ["alice", "bob"], per_account_cap=1, pause=False)
        self.assertEqual(report.acted, 1)
        self.assertEqual(report.skipped, 1)


class ReportTest(unittest.TestCase):
    def test_render(self):
        report = x.Report()
        report.add("acted", "did a thing")
        self.assertIn("acted=1", report.render())
        self.assertIn("did a thing", report.render())


if __name__ == "__main__":
    unittest.main()
