"""The vendored lab must at least parse."""

import os
import py_compile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ROOTS = ("tools", os.path.join("skills", "onchain-execution"))


class CompileTest(unittest.TestCase):
    def test_every_python_file_parses(self):
        bad = []
        for root in ROOTS:
            for dirpath, dirs, files in os.walk(os.path.join(ROOT, root)):
                dirs[:] = [d for d in dirs if d not in {"__pycache__", ".git"}]
                for name in files:
                    if name.endswith(".py"):
                        path = os.path.join(dirpath, name)
                        try:
                            py_compile.compile(path, doraise=True, cfile="/tmp/muse_compile.pyc")
                        except Exception as error:
                            bad.append(f"{path}: {error}")
        self.assertEqual(bad, [])
