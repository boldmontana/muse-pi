"""Structure and link integrity for the imported library."""

import os
import re
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
LIB = os.path.join(ROOT, "skills", "library")
PKG = os.path.join(ROOT, "skills", "onchain-execution")
RESEARCH = os.path.join(ROOT, "skills", "security-research")
DOCS = os.path.join(ROOT, "docs", "muse")
TOOLS = os.path.join(ROOT, "tools")

KNOWN_MISSING = {
    "DrainerEvolusi", "DrainerFull", "DrainerFull.t", "GitDorker", "account_pooler",
    "alerts", "alpha_radar", "api_harvester", "automation",
    "backtest", "briefing", "claim_watcher", "community_intel",
    "content", "contract_watch", "ctf", "dashboard",
    "desktop_control", "eligibility", "eval", "exit_planner",
    "explain", "farm_roi", "gateway_manager", "guide_studio",
    "hids", "hook_lab", "humanizer", "mcp_builder",
    "memory_engine", "model_registry", "model_resolver", "multimodal",
    "neuron_tracker", "planner", "prd", "reflection",
    "repurpose", "research_q", "revenue_engine", "rugcheck",
    "scam_sentinel", "scene_prep", "skill_forge", "skill_integrity",
    "skill_market", "swarm", "sybil_audit", "team_auth",
    "triage", "unlock_engine", "vault", "video_pipeline",
    "voice", "watchdog",
}
# Referenced by the library, trimmed from the shipped archive to hold the size budget.
SLUG = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")
LINK = re.compile(r"(skills/library/[\w-]+\.md|skills/onchain-execution/[\w./-]+|tools/[\w./-]+\.(?:py|md|sol|sh))")


def library_files():
    return sorted(n for n in os.listdir(LIB) if n.endswith(".md") and n != "INDEX.md")


class LibraryTest(unittest.TestCase):
    def test_has_files(self):
        self.assertGreater(len(library_files()), 70)

    def test_frontmatter_and_slug(self):
        for name in library_files():
            with open(os.path.join(LIB, name), encoding="utf-8") as handle:
                text = handle.read()
            self.assertTrue(text.startswith("---\n"), name)
            head = text.split("---", 2)[1]
            fields = dict(
                line.split(":", 1) for line in head.strip().splitlines() if ":" in line
            )
            for key in ("name", "description", "when_to_use", "source"):
                self.assertIn(key, fields, name)
            slug = name[:-3]
            self.assertEqual(fields["name"].strip(), slug)
            self.assertRegex(slug, SLUG)
            self.assertIn("**Load when:**", text, name)
            self.assertNotRegex(slug, r"^(m|sk|x)\d+$")

    def test_slugs_unique(self):
        names = [n[:-3] for n in library_files()]
        self.assertEqual(len(names), len(set(names)))

    def test_index_complete(self):
        with open(os.path.join(LIB, "INDEX.md"), encoding="utf-8") as handle:
            index = handle.read()
        for name in library_files():
            self.assertIn(f"]({name})", index, name)


class BrandingTest(unittest.TestCase):
    def test_no_muse_left(self):
        for base in [p for p in (LIB, PKG, RESEARCH, DOCS) if os.path.isdir(p)]:
            for dirpath, _, files in os.walk(base):
                for name in files:
                    if not name.endswith((".md", ".py", ".toml", ".txt")):
                        continue
                    with open(os.path.join(dirpath, name), encoding="utf-8") as handle:
                        text = handle.read()
                    clean = re.sub(r"(collections/v7|execute/buy/v7)", "", text)
                    for banned in ("SUPERAGENT", "IRONCLAW", "SUPREME", "V7", "v7", "Hermes", "hermes"):
                        self.assertNotIn(banned, clean, f"{name}: {banned}")

    def test_research_package(self):
        with open(os.path.join(RESEARCH, "SKILL.md"), encoding="utf-8") as handle:
            text = handle.read()
        self.assertIn("name: security-research", text)
        for part in ("references/recon.md", "references/verification-and-poc.md", "templates/report.md"):
            self.assertTrue(os.path.exists(os.path.join(RESEARCH, part)), part)

    def test_onchain_package(self):
        skill = os.path.join(PKG, "SKILL.md")
        self.assertTrue(os.path.exists(skill))
        with open(skill, encoding="utf-8") as handle:
            self.assertIn("name: onchain-execution", handle.read())
        for part in ("references", "scripts/governor.py", "scripts/mev.py"):
            self.assertTrue(os.path.exists(os.path.join(PKG, part)), part)

    def test_archived_docs(self):
        if not os.path.isdir(DOCS):
            self.skipTest("docs trimmed from this build")
        self.assertEqual(len([n for n in os.listdir(DOCS) if n.endswith(".md")]), 18)


class LinkTest(unittest.TestCase):
    def test_library_links_resolve(self):
        for base in [p for p in (LIB, PKG, RESEARCH, DOCS) if os.path.isdir(p)]:
            for dirpath, _, files in os.walk(base):
                for name in files:
                    if not name.endswith(".md"):
                        continue
                    path = os.path.join(dirpath, name)
                    with open(path, encoding="utf-8") as handle:
                        text = handle.read()
                    for match in LINK.finditer(text):
                        target = match.group(1).rstrip(".,)`")
                        if target.endswith("/*.md"):
                            target = os.path.dirname(target)
                        base = os.path.basename(target)
                        if base.rsplit(".", 1)[0] in KNOWN_MISSING and target.startswith("tools/"):
                            continue
                        resolved = os.path.join(ROOT, target)
                        self.assertTrue(
                            os.path.exists(resolved), f"{name}: {target}"
                        )

    def test_missing_tools_are_declared(self):
        absent = set()
        for base in [p for p in (DOCS, LIB, PKG, RESEARCH) if os.path.isdir(p)]:
            for dirpath, _, files in os.walk(base):
                for name in files:
                    if not name.endswith(".md"):
                        continue
                    with open(os.path.join(dirpath, name), encoding="utf-8") as handle:
                        for match in re.finditer(r"tools/([\w-]+)\.py", handle.read()):
                            if not os.path.exists(os.path.join(TOOLS, match.group(1) + ".py")):
                                absent.add(match.group(1))
        self.assertLessEqual(absent, KNOWN_MISSING)
