"""Command surface: exit codes, validation, and path handling."""

import http.server
import os
import subprocess
import sys
import tempfile
import threading
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run(*args, home=None, stdin=None):
    env = dict(os.environ, MUSE_PASSPHRASE="test-passphrase")
    env.pop("MUSE_HOME", None)
    return subprocess.run(
        [sys.executable, "-m", "muse", "--state", home or ".", *args],
        cwd=ROOT, env=env, capture_output=True, text=True, input=stdin, timeout=120)


class SweepTest(unittest.TestCase):
    def test_dry_run_is_forwarded(self):
        import argparse
        from unittest import mock

        from muse import cli, tx

        calls = []

        class FakeVault:
            def derive(self, chain, index):
                return "0x" + "11" * 20, 1

        class FakeChain:
            symbol = "ETH"

            def format(self, wei):
                return str(wei)

            def balance(self, address):
                return 10 ** 18

            def verify_chain_id(self):
                return 1

        args = argparse.Namespace(chain="base", count=1, to="0x" + "22" * 20, speed="normal",
                                  dry_run=True, yes=True)
        with mock.patch.object(cli, "_open_vault", return_value=FakeVault()), \
                mock.patch.object(cli, "_resolve", return_value=FakeChain()), \
                mock.patch.object(tx, "_fees", return_value=(1, 2)), \
                mock.patch.object(tx, "prepare_and_send", side_effect=lambda *a, **k: calls.append(k) or {}):
            self.assertEqual(cli.cmd_sweep(args), 0)
        self.assertEqual(len(calls), 1)
        self.assertTrue(calls[0]["dry_run"])


class CliTest(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.home = self.tmp.name
        self.assertEqual(run("new", home=self.home).returncode, 0)

    def tearDown(self):
        self.tmp.cleanup()

    def test_help(self):
        result = run("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("balances", result.stdout)

    def test_address_rejects_unknown_chain(self):
        result = run("address", "--chain", "nope", home=self.home)
        self.assertEqual(result.returncode, 2)
        self.assertIn("unknown chain", result.stderr)

    def test_address_derives(self):
        result = run("address", "--chain", "base", "--count", "2", home=self.home)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.count("0x"), 2)

    def test_note_add_and_empty_search(self):
        self.assertEqual(run("note", "add", "tcache", "--tags", "pwn", home=self.home).returncode, 0)
        empty = run("note", "search", "", home=self.home)
        self.assertEqual(empty.returncode, 0)
        self.assertIn("tcache", empty.stdout)

    def test_note_body_from_stdin(self):
        result = run("note", "add", "title", home=self.home, stdin="piped body")
        self.assertEqual(result.returncode, 0)
        listing = run("note", "search", "title", home=self.home)
        self.assertIn("title", listing.stdout)

    def test_fetch_creates_output_directory(self):
        class Handler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                self.send_response(200)
                self.send_header("content-type", "text/plain")
                self.end_headers()
                self.wfile.write(b"hello")

            def log_message(self, *args):
                pass

        server = http.server.HTTPServer(("127.0.0.1", 0), Handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        target = os.path.join(self.home, "deep", "page.txt")
        result = run("fetch", f"http://127.0.0.1:{server.server_port}/", "--out", target, home=self.home)
        server.shutdown()
        self.assertEqual(result.returncode, 0)
        with open(target) as handle:
            self.assertEqual(handle.read(), "hello")

    def test_pack_creates_output_directory(self):
        result = run("pack", "--out", os.path.join(self.home, "out", "x.zip"), home=self.home)
        self.assertEqual(result.returncode, 0)
        self.assertTrue(os.path.exists(os.path.join(self.home, "out", "x.zip")))
