"""Known-answer tests for the dependency-free primitives."""

import unittest

from muse import core


class KeccakTest(unittest.TestCase):
    def test_empty(self):
        self.assertEqual(
            core.keccak256(b"").hex(),
            "c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470",
        )

    def test_abc(self):
        self.assertEqual(
            core.keccak256(b"abc").hex(),
            "4e03657aea45a94fc7d47ba826c8d667c0d1e6e33a64a036ec44f58fa12d6c45",
        )

    def test_multiblock(self):
        self.assertEqual(len(core.keccak256(b"a" * 1000)), 32)

    def test_rejects_text(self):
        with self.assertRaises(TypeError):
            core.keccak256("abc")  # type: ignore[arg-type]


class SecpTest(unittest.TestCase):
    def test_known_pubkey(self):
        priv = 1
        self.assertEqual(core.private_to_public(priv).hex().upper(),
                         "79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798"
                         "483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8")

    def test_sign_verify_roundtrip(self):
        priv = 0x4C0883A69102937D6231471B5DBB98431BBE7C13A0B5C1C2AD1A9C8F1C0A7D31
        digest = core.keccak256(b"muse-beta-1.0")
        r, s, parity = core.sign_digest(priv, digest)
        self.assertLessEqual(s, core.N // 2)
        self.assertTrue(core.verify_digest(core.private_to_public(priv), digest, r, s))
        other = core.keccak256(b"muse-beta-1.0!")
        self.assertFalse(core.verify_digest(core.private_to_public(priv), other, r, s))

    def test_deterministic(self):
        priv = 0xDEADBEEF
        digest = core.keccak256(b"determinism")
        self.assertEqual(core.sign_digest(priv, digest), core.sign_digest(priv, digest))

    def test_parity_recovers_public_key(self):
        priv = 0x1234567890ABCDEF
        digest = core.keccak256(b"parity")
        r, s, parity = core.sign_digest(priv, digest)
        self.assertIn(parity, (0, 1))


class AddressTest(unittest.TestCase):
    def test_eip55_vector(self):
        raw = "0x5aaeb6053f3e94c9b9a09f33669435e7ef1beaed"
        self.assertEqual(core.checksum_address(raw), "0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed")

    def test_eip55_allcaps_vector(self):
        raw = "0xfb6916095ca1df60bb79ce92ce3ea74c37c5d359"
        self.assertEqual(core.checksum_address(raw), "0xfB6916095ca1df60bB79Ce92cE3Ea74c37c5d359")

    def test_normalize(self):
        self.assertEqual(core.normalize_address("5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed"),
                         "0x5aaeb6053f3e94c9b9a09f33669435e7ef1beaed")

    def test_bad_address(self):
        for bad in ("", "0x123", "0x" + "zz" * 20):
            with self.assertRaises(ValueError):
                core.normalize_address(bad)


class RlpTest(unittest.TestCase):
    def test_vectors(self):
        self.assertEqual(core.rlp_encode(b"dog").hex(), "83646f67")
        self.assertEqual(core.rlp_encode(0).hex(), "80")
        self.assertEqual(core.rlp_encode([b"cat", b"dog"]).hex(), "c88363617483646f67")

    def test_roundtrip(self):
        value = [b"a", [b"b", b"c"], b"d" * 60]
        self.assertEqual(core.rlp_decode(core.rlp_encode(value)), value)


class BipTest(unittest.TestCase):
    MUSENIC = "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about"

    def test_mnemonic_validation(self):
        self.assertTrue(core.mnemonic_valid(self.MUSENIC))
        self.assertFalse(core.mnemonic_valid("abandon " * 11 + "abandonn"))

    def test_generate_roundtrip(self):
        phrase = core.generate_mnemonic(128)
        self.assertEqual(len(phrase.split()), 12)
        self.assertTrue(core.mnemonic_valid(phrase))

    def test_known_derivation(self):
        address, priv = core.derive_account(self.MUSENIC, 0)
        self.assertEqual(address, "0x9858EfFD232B4033E47d90003D41EC34EcaEda94")
        self.assertEqual(core.private_to_public(priv).hex()[:8], core.private_to_public(priv).hex()[:8])

    def test_index_changes_address(self):
        first, _ = core.derive_account(self.MUSENIC, 0)
        second, _ = core.derive_account(self.MUSENIC, 1)
        self.assertNotEqual(first, second)

    def test_passphrase_changes_address(self):
        plain, _ = core.derive_account(self.MUSENIC, 0)
        salted, _ = core.derive_account(self.MUSENIC, 0, passphrase="muse")
        self.assertNotEqual(plain, salted)

    def test_bad_path(self):
        with self.assertRaises(ValueError):
            core.derive_private(b"\x01" * 64, "44'/60'")

    def test_private_from_hex(self):
        self.assertEqual(core.private_from_hex("0x" + "01" * 32), int("01" * 32, 16))


if __name__ == "__main__":
    unittest.main()
