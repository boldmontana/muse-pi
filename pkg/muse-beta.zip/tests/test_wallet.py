"""Vault, signing and ledger tests. No network required."""

import os
import tempfile
import unittest

from muse import core, tx, vault


class VaultTest(unittest.TestCase):
    MUSENIC = "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about"

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "vault.json")

    def tearDown(self):
        self.tmp.cleanup()

    def test_roundtrip_and_mode(self):
        made = vault.Vault.create(self.path, "correct horse", self.MUSENIC)
        self.assertEqual(oct(os.stat(self.path).st_mode & 0o777), "0o600")
        opened = vault.Vault(self.path).unlock("correct horse")
        self.assertEqual(opened.data["mnemonic"], self.MUSENIC)
        self.assertEqual(made.data["mnemonic"], self.MUSENIC)

    def test_wrong_passphrase(self):
        vault.Vault.create(self.path, "correct horse", self.MUSENIC)
        with self.assertRaises(ValueError):
            vault.Vault(self.path).unlock("battery staple")

    def test_tamper_detected(self):
        vault.Vault.create(self.path, "correct horse", self.MUSENIC)
        with open(self.path, "r+", encoding="utf-8") as handle:
            blob = handle.read().replace('"version": 1', '"version": 1')
            handle.seek(0)
            handle.write(blob)
        with open(self.path, "r+", encoding="utf-8") as handle:
            text = handle.read()
            marker = text.index('"tag"')
            handle.seek(marker + 8)
            handle.write("0" * 8)
            handle.truncate()
        with self.assertRaises(ValueError):
            vault.Vault(self.path).unlock("correct horse")

    def test_plaintext_absent(self):
        vault.Vault.create(self.path, "correct horse", self.MUSENIC)
        with open(self.path, encoding="utf-8") as handle:
            raw = handle.read()
        self.assertNotIn("abandon", raw)

    def test_short_passphrase_rejected(self):
        with self.assertRaises(ValueError):
            vault.Vault.create(self.path, "short", self.MUSENIC)

    def test_bad_mnemonic_rejected(self):
        with self.assertRaises(ValueError):
            vault.Vault.create(self.path, "correct horse", "abandon " * 12)

    def test_index_bumps(self):
        held = vault.Vault.create(self.path, "correct horse", self.MUSENIC)
        first, _ = held.derive("ethereum")
        second, _ = held.derive("ethereum")
        self.assertNotEqual(first, second)
        self.assertEqual(held.next_index("ethereum"), 2)

    def test_derive_known_vector(self):
        held = vault.Vault.create(self.path, "correct horse", self.MUSENIC)
        address, priv = held.derive("base", 0)
        self.assertEqual(address, "0x9858EfFD232B4033E47d90003D41EC34EcaEda94")
        self.assertEqual(core.private_to_public(priv)[:1].hex(), core.private_to_public(priv)[:1].hex())


class StubChain:
    """Minimal Chain stand-in for offline signing tests."""

    key = "stub"
    chain_id = 8453
    symbol = "ETH"
    decimals = 18
    explorer = "https://example.test"

    def __init__(self, balance=10 ** 19):
        self._balance = balance
        self.broadcast = []

    def normalize(self, address):
        return core.normalize_address(address)

    def balance(self, address):
        return self._balance

    def nonce(self, address):
        return 7

    def priority_fee(self):
        return 1_000_000

    def base_fee(self):
        return 20_000_000

    def gas_price(self):
        return 21_000_000

    def estimate_gas(self, trace):
        return 21000

    def call(self, method, params=None, **kwargs):
        return "0x"

    def send_raw(self, raw):
        self.broadcast.append(raw)
        return "0x" + core.keccak256(raw).hex()

    def format(self, wei, decimals=None):
        return f"{wei / 10 ** (decimals or self.decimals):.6f}"

    def explorer_tx(self, tx_hash):
        return f"{self.explorer}/tx/{tx_hash}"

    def receipt(self, tx_hash):
        return None

    @staticmethod
    def to_int(value):
        return int(value, 16) if isinstance(value, str) else int(value)


class TxTest(unittest.TestCase):
    MUSENIC = "abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about"

    def setUp(self):
        self.address, self.priv = core.derive_account(self.MUSENIC, 0)
        self.chain = StubChain()

    def test_eip1559_shape(self):
        fields = tx.build_1559(self.chain, 3, self.address, 10 ** 15, "0x", 21000, 1, 2)
        raw = tx.sign_1559(fields, self.priv)
        self.assertEqual(raw[0], 0x02)
        _, after = core.rlp_decode_at(raw, 1)
        decoded, _ = core.rlp_decode_at(raw, after)
        self.assertEqual(decoded[0], (8453).to_bytes(2, "big"))  # chain id
        self.assertEqual(len(decoded), 12)

    def test_signature_recovers(self):
        fields = tx.build_1559(self.chain, 0, self.address, 1, "0x", 21000, 1, 2)
        raw = tx.sign_1559(fields, self.priv)
        _, after = core.rlp_decode_at(raw, 1)
        decoded, _ = core.rlp_decode_at(raw, after)
        digest = core.keccak256(b"\x02" + core.rlp_encode(fields))
        r = int.from_bytes(decoded[-2], "big")
        s = int.from_bytes(decoded[-1], "big")
        self.assertTrue(core.verify_digest(core.private_to_public(self.priv), digest, r, s))

    def test_dry_run_does_not_broadcast(self):
        report = tx.prepare_and_send(self.chain, self.address, self.priv, self.address, 10 ** 15, dry_run=True)
        self.assertFalse(report["broadcast"])
        self.assertEqual(self.chain.broadcast, [])
        self.assertIn("tx_hash", report)

    def test_broadcast(self):
        report = tx.prepare_and_send(self.chain, self.address, self.priv, self.address, 10 ** 15)
        self.assertTrue(report["broadcast"])
        self.assertEqual(len(self.chain.broadcast), 1)

    def test_insufficient_funds(self):
        poor = StubChain(balance=1)
        with self.assertRaises(RuntimeError):
            tx.prepare_and_send(poor, self.address, self.priv, self.address, 10 ** 15)

    def test_erc20_data(self):
        data = tx.erc20_transfer_data(self.address, 5)
        self.assertTrue(data.startswith("0xa9059cbb"))
        self.assertEqual(len(data), 2 + 8 + 64 + 64)


class AmountTest(unittest.TestCase):
    def test_parse_and_format(self):
        chain = StubChain()
        self.assertEqual(chain.format(1_500_000_000_000_000_000), "1.500000")
        parsed = core  # keep flake quiet
        self.assertEqual(parsed.hex0x(b"\x01"), "0x01")


if __name__ == "__main__":
    unittest.main()
